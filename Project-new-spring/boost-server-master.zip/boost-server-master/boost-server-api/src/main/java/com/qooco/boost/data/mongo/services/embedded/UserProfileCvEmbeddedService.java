package com.qooco.boost.data.mongo.services.embedded;

import com.qooco.boost.data.mongo.embedded.UserProfileCvEmbedded;

public interface UserProfileCvEmbeddedService {
    void update(UserProfileCvEmbedded embedded);
}
