package com.qooco.boost.data.mongo.services.impl;

import com.qooco.boost.data.mongo.services.VacancySearchDocService;
import org.springframework.stereotype.Service;

@Service
public class VacancySearchDocServiceImpl implements VacancySearchDocService {
}
