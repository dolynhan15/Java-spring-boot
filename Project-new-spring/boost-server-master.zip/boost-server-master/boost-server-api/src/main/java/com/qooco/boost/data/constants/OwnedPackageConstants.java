package com.qooco.boost.data.constants;

/*
 * Copyright: Falcon Team - AxonActive
 * User: mhvtrung
 * Date: 10/16/2018 - 3:26 PM
 */
public class OwnedPackageConstants {
    public static final String ID = "id";
    public static final String TIMESTAMP = "timestamp";
    public static final String USER_PROFILE_ID = "userProfileId";
}
