package com.qooco.boost.data.constants;

/*
* Copyright: Falcon Team - AxonActive
 User: nhphuc
 Date: 10/9/2018 - 4:27 PM
*/
public class LevelTestScaleDocConstants {
    public static final String TIMESTAMP = "timestamp";
    public static final String ID = "id";
}
