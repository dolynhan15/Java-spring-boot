package com.qooco.boost.data.model;

import lombok.experimental.FieldNameConstants;

@FieldNameConstants
public class CityGroup {

}
