package com.qooco.boost.constants;

public class AccountType {
    public static final int NORMAL = 1;
    public static final int FACEBOOK = 2;
    public static final int GOOGLE = 3;
}
