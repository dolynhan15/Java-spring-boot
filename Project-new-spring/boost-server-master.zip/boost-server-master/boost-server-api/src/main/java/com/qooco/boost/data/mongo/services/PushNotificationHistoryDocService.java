package com.qooco.boost.data.mongo.services;

import com.qooco.boost.data.mongo.entities.PushNotificationHistoryDoc;

public interface PushNotificationHistoryDocService {
    PushNotificationHistoryDoc save(PushNotificationHistoryDoc doc);
}
