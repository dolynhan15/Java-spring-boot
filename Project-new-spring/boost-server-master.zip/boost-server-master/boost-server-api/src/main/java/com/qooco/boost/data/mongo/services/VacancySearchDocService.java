package com.qooco.boost.data.mongo.services;

public interface VacancySearchDocService {

}
