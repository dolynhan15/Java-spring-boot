package com.qooco.boost.data.constants;

public interface SearchRange {
    int CITY = 1;
    int PROVINCE = 2;
    int REGION = 3;
    int COUNTRY = 4;
    int WORLD = 5;
}

