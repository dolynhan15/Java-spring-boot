package com.qooco.boost.data.constants;

/*
* Copyright: Falcon Team - AxonActive
 User: nhphuc
 Date: 10/2/2018 - 11:16 AM
*/
public class LocalizationDocConstants {
    public static final String ID = "id";
    public static final String COLLECTION = "collection";
    public static final String TIMESTAMP = "timestamp";
    public static final String CONTENT = "content";
}
