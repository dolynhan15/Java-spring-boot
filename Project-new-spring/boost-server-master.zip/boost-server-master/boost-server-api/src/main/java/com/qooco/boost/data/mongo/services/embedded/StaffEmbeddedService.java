package com.qooco.boost.data.mongo.services.embedded;

import com.qooco.boost.data.mongo.embedded.StaffShortEmbedded;

public interface StaffEmbeddedService {

    void update(StaffShortEmbedded staff);
}
