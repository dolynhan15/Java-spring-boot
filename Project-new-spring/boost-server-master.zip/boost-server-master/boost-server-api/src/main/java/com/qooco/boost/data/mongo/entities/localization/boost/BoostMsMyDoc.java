package com.qooco.boost.data.mongo.entities.localization.boost;

import com.qooco.boost.data.mongo.entities.localization.BaseLocaleDoc;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "BoostMsMyDoc")
public class BoostMsMyDoc extends BaseLocaleDoc {
}
