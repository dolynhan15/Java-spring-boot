
package com.qooco.boost.business;

public interface BusinessSocketConnectionService {

}