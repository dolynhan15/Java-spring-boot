package com.qooco.boost.data.constants;

public interface SupportChannelStatus {
    int OPENING = 1;
    int ARCHIVED = 2;
}
