package com.qooco.boost.data.constants;

public interface UserType {
    int SELECT = 1;
    int PROFILE = 2;
    int BOOST_HELPER = 3;
    int BOOST_HELPER_ERROR = 4;
    int BOOST_GENERAL_SUPPORTER = 5;
    int SYSTEM_ADMIN = 6;
}
