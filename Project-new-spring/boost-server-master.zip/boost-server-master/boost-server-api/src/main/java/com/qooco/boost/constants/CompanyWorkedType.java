package com.qooco.boost.constants;

/*
* Copyright: Falcon Team - AxonActive
 User: nhphuc
 Date: 8/28/2018 - 2:05 PM
*/
public class CompanyWorkedType {
    public static final int PENDING_AUTHORIZE_COMPANY = 1;
    public static final int PENDING_JOIN_COMPANY = 2;
    public static final int APPROVED_AUTHORIZE_COMPANY = 3;
    public static final int APPROVED_JOIN_COMPANY = 4;
}
