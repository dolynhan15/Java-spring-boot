package com.qooco.boost.data.constants;

public class ViewProfileDocConstants {
    public class Status {
        public static final int NOT_VIEWED = 1;
        public static final int VIEWED = 2;
    }
}
