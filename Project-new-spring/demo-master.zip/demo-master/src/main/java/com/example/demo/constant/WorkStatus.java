package com.example.demo.constant;

public class WorkStatus {
    public static final int PLANNING = 1;
    public static final int DOING = 2;
    public static final int COMPLETE = 3;
}
