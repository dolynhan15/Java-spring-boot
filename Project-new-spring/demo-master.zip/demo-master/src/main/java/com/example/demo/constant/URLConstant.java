package com.example.demo.constant;

public class URLConstant {
    public static final String WORK_PATH = "/work";
    public static final String ID = "/{id}";
}
