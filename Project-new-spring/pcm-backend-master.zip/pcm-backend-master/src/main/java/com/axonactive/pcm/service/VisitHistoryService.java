package com.axonactive.pcm.service;

import com.axonactive.pcm.entity.Technology;
import com.axonactive.pcm.entity.VisitHistory;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;

import java.util.List;

public interface VisitHistoryService {
    VisitHistory save(VisitHistory visitHistory);

    void deleteVisithistoryById(int id);

    void validate(VisitHistory visitHistory);

    List<VisitHistory> findVisitHistoriesByContactId(int contactId);

    void delete(List<VisitHistory> visitHistories);
}
