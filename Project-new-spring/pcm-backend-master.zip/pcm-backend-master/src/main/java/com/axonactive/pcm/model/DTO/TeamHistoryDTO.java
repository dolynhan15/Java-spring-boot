package com.axonactive.pcm.model.DTO;

public class TeamHistoryDTO {
    String teamName;

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }
}
