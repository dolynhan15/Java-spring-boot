package com.axonactive.pcm.controller;

import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.constant.EntityConstants;
import com.axonactive.pcm.model.authentication.AuthenticatedUser;
import com.axonactive.pcm.service.TechnologyService;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.axonactive.pcm.constant.EntityConstants.*;

@RestController
@RequestMapping(DefaultPath.TECHNOLOGY_PATH)
@CrossOrigin
public class TechnologyController {

    private static final Logger logger = LogManager.getLogger(TechnologyController.class);

    private final TechnologyService technologyService;

    @Autowired
    public TechnologyController(TechnologyService technologyService) {
        this.technologyService = technologyService;
    }

    @GetMapping
    @PreAuthorize("hasAnyAuthority('Edit Team', 'New Project', 'Edit Project', 'Edit My Team', 'Exception-SM-Interact-Project-Only')")
    public ResponseEntity getTechnologies(Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/technologies/ - getTechnologies -- user: {}", currentUser.getUsername());
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(technologyService.getTechnologies());
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_TECHNOLOGY, SimpleBeanPropertyFilter.serializeAllExcept(PROJECTS, TEAMS))
                .addFilter(FILTER_PROJECT, SimpleBeanPropertyFilter.filterOutAllExcept());
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }
}
