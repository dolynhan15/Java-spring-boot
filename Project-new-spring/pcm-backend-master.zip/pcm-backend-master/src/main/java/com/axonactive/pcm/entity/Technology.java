package com.axonactive.pcm.entity;

import com.axonactive.pcm.constant.EntityConstants;
import com.fasterxml.jackson.annotation.JsonFilter;

import javax.persistence.*;
import java.util.List;

@Entity
@JsonFilter(EntityConstants.FILTER_TECHNOLOGY)
public class Technology {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable = false)
    private int id;

    private String name;

    @ManyToMany(mappedBy = "technologies")
    private List<Project> projects;

    @ManyToMany(mappedBy = "technologies")
    private List<Team> teams;

    public List<Project> getProjects() {
        return projects;
    }

    public void setProjects(List<Project> projects) {
        this.projects = projects;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Team> getTeams() {
        return teams;
    }

    public void setTeams(List<Team> teams) {
        this.teams = teams;
    }
}
