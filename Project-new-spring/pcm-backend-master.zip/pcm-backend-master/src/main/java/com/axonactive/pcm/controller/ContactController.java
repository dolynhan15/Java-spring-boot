package com.axonactive.pcm.controller;

import com.axonactive.pcm.constant.DefaultParam;
import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.constant.ErrorMessageConstants;
import com.axonactive.pcm.constant.SuccessMessageConstants;
import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.model.authentication.AuthenticatedUser;
import com.axonactive.pcm.service.ContactPositionService;
import com.axonactive.pcm.service.ContactService;
import com.axonactive.pcm.service.FileService;
import com.axonactive.pcm.service.ProjectContactService;
import com.axonactive.pcm.utility.JwtTokenValidator;
import com.axonactive.pcm.utility.PathHepper;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

import static com.axonactive.pcm.constant.EntityConstants.*;

@CrossOrigin
@RestController
@RequestMapping(DefaultPath.CONTACT_PATH)
public class ContactController {

    private static final Logger logger = LogManager.getLogger(ContactController.class);

    private final ContactService contactService;

    private final ContactPositionService contactPositionService;

    private final ProjectContactService projectContactService;

    private final FileService fileService;

    private final JwtTokenValidator jwtTokenValidator;

    private final PathHepper pathHepper;

    @Autowired
    public ContactController(ContactService contactService, ContactPositionService contactPositionService, ProjectContactService projectContactService, FileService fileService, JwtTokenValidator jwtTokenValidator, PathHepper pathHepper) {
        this.contactService = contactService;
        this.contactPositionService = contactPositionService;
        this.projectContactService = projectContactService;
        this.fileService = fileService;
        this.jwtTokenValidator = jwtTokenValidator;
        this.pathHepper = pathHepper;
    }

    @GetMapping(DefaultPath.UNASSIGNED_PATH)
    @PreAuthorize("hasAnyAuthority('New Customer', 'Edit Customer')")
    public ResponseEntity getUnassignedContacts(Authentication authentication){
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/contacts/unassigned - getUnassignedContacts -- user: {}", currentUser.getUsername());
        List<Contact> contacts = contactService.readUnAssignedContacts();
        for (Contact contact : contacts) {
            contact.setContactAvatar(pathHepper.handlerImage(contact.getContactAvatar()));
        }
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(contacts);
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_CONTACT, SimpleBeanPropertyFilter.serializeAllExcept(
                        PROJECTS,
                        VISIT_HISTORIES
                ))
                .addFilter(FILTER_CUSTOMER, SimpleBeanPropertyFilter.filterOutAllExcept(
                        CUSTOMER_ID,
                        CUSTOMER_NAME
                ))
                .addFilter(FILTER_POSITION, SimpleBeanPropertyFilter.serializeAllExcept(
                        CONTACTS
                ));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @GetMapping(DefaultPath.ID_VARIABLE)
    @PreAuthorize("hasAnyAuthority('View Contact Detail', 'Edit Contact', 'View My Contact')")
    public ResponseEntity getContact(@PathVariable int id, Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/contacts/{} - getContact -- user: {}", id, currentUser.getUsername());
        jwtTokenValidator.isMyContact(currentUser, id);
        Contact contact = contactService.readContactById(id);
        contact.setContactAvatar(pathHepper.handlerImage(contact.getContactAvatar()));
        contact.setContactGallery(pathHepper.handlerScreenShot(contact.getContactGallery()));
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(contact);
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_CONTACT, SimpleBeanPropertyFilter.serializeAllExcept(PROJECTS))
                .addFilter(FILTER_VISIT_HISTORY, SimpleBeanPropertyFilter.serializeAllExcept(
                        CONTACT
                ))
                .addFilter(FILTER_CUSTOMER, SimpleBeanPropertyFilter.filterOutAllExcept(
                        CUSTOMER_ID,
                        CUSTOMER_NAME
                ))
                .addFilter(FILTER_POSITION, SimpleBeanPropertyFilter.serializeAllExcept(
                        CONTACTS
                ));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @GetMapping
    @PreAuthorize("hasAnyAuthority('View Contact List')")
    public ResponseEntity getListContact(Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/contacts/ - getListContact -- user: {}", currentUser.getUsername());
        List<Contact> contacts = contactService.readListContacts();
        for (Contact contact : contacts) {
            contact.setContactAvatar(pathHepper.handlerImage(contact.getContactAvatar()));
        }

        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(contacts);
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_CONTACT, SimpleBeanPropertyFilter.serializeAllExcept(PROJECTS,
                        VISIT_HISTORIES
                ))
                .addFilter(FILTER_CUSTOMER, SimpleBeanPropertyFilter.filterOutAllExcept(
                        CUSTOMER_ID,
                        CUSTOMER_NAME,
                        STATUS))
                .addFilter(FILTER_POSITION, SimpleBeanPropertyFilter.serializeAllExcept(
                        CONTACTS
                ));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @PostMapping
    @PreAuthorize("hasAnyAuthority('New Contact')")
    public ResponseEntity saveContact(@RequestBody Contact contact, Authentication authentication) throws InvalidParamException{
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/contacts/ - {} - saveContact -- user: {}", contact.getContactFirstName()+"", currentUser.getUsername());

        Contact savedContact = contactPositionService.savePositionWithContact(contact);

        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(contactService.detachAndSetPath(savedContact));

        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_CONTACT, SimpleBeanPropertyFilter.serializeAllExcept(
                        PROJECTS,
                        VISIT_HISTORIES))
                .addFilter(FILTER_CUSTOMER, SimpleBeanPropertyFilter.filterOutAllExcept(
                        CUSTOMER_ID,
                        CUSTOMER_NAME))
                .addFilter(FILTER_POSITION, SimpleBeanPropertyFilter.serializeAllExcept(
                        CONTACTS
                ));
        mappingJacksonValue.setFilters(filterProvider);

        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CREATED);
    }

    @PutMapping
    @PreAuthorize("hasAnyAuthority('Edit Contact')")
    public ResponseEntity editContact(@RequestBody Contact contact, Authentication authentication) throws InvalidParamException{
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/contacts/ - {} - editContact -- user: {}", contact.getContactId()+"", currentUser.getUsername());
        if(contact.getContactId() == 0) {
            throw new InvalidParamException("Could not find id in body", DefaultPath.CONTACT_PATH);
        }

        contact = contactPositionService.savePositionWithContact(contact);

        contact.setContactAvatar(fileService.uploadImage(DefaultParam.TARGET_CONTACT, contact.getContactId() + "", pathHepper.removePathServerImage(contact.getContactAvatar())));
        contact.setContactGallery(fileService.uploadImageList(DefaultParam.TARGET_CONTACT, contact.getContactId() + "", pathHepper.removePathServerScreenShot(contact.getContactGallery())));

        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(contactService.saveContact(contact));
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_CONTACT, SimpleBeanPropertyFilter.serializeAllExcept(
                        PROJECTS,
                        VISIT_HISTORIES))
                .addFilter(FILTER_CUSTOMER, SimpleBeanPropertyFilter.filterOutAllExcept(
                        CUSTOMER_ID,
                        CUSTOMER_NAME))
                .addFilter(FILTER_POSITION, SimpleBeanPropertyFilter.serializeAllExcept(
                        CONTACTS));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @PutMapping(DefaultPath.WIFIKEY_PATH)
    @PreAuthorize("hasAnyAuthority('Edit Wifikey')")
    public ResponseEntity editWifikey(@RequestBody Map<String, String> body, Authentication authentication) throws InvalidParamException {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/contacts/wifikey - bodySize: {} - editWifikey -- user: {}", body.size(), currentUser.getUsername());
        if (Integer.parseInt(body.get(DefaultPath.PARAMETER_CONTACT_ID)) == 0) {
            throw new InvalidParamException(ErrorMessageConstants.ID_NOT_FOUND_ERROR, DefaultPath.CONTACT_PATH + DefaultPath.WIFIKEY_PATH);
        }

        contactService.updateWifiKey(body.get(DefaultPath.PARAMETER_WIFIKEY), Integer.parseInt(body.get(DefaultPath.PARAMETER_CONTACT_ID)));
        com.axonactive.pcm.model.SuccessEntity.SuccessMessage successMessage = new com.axonactive.pcm.model.SuccessEntity.SuccessMessage();
        successMessage.setStatus(SuccessMessageConstants.SUCCESS_STATUS);
        successMessage.setMessage(SuccessMessageConstants.EDIT_WIFIKEY_SUCCESS);

        return new ResponseEntity<>(successMessage, HttpStatus.OK);
    }

    @DeleteMapping(DefaultPath.ID_VARIABLE)
    @PreAuthorize("hasAnyAuthority('Delete Contact')")
    public ResponseEntity deleteVisitHistory(@PathVariable int id, Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/contacts/{} - deleteVisitHistory -- user: {}", id, currentUser.getUsername());
        if (id <= 0) {
            throw new InvalidParamException(ErrorMessageConstants.ID_INVALID_ERROR, DefaultPath.CONTACT_PATH);
        }

        projectContactService.deleteContactById(id);
        com.axonactive.pcm.model.SuccessEntity.SuccessMessage successMessage = new com.axonactive.pcm.model.SuccessEntity.SuccessMessage();
        successMessage.setStatus(SuccessMessageConstants.SUCCESS_STATUS);
        successMessage.setMessage(SuccessMessageConstants.DELETE_CONTACT_SUCCESS);

        return new ResponseEntity<>(successMessage, HttpStatus.OK);
    }
}
