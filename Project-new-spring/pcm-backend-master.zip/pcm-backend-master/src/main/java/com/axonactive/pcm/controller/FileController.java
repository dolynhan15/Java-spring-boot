package com.axonactive.pcm.controller;


import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.constant.SuccessMessageConstants;
import com.axonactive.pcm.model.SuccessEntity.SuccessMessage;
import com.axonactive.pcm.service.FileService;
import com.axonactive.pcm.utility.PathHepper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;


@RestController
@RequestMapping(DefaultPath.FILE_PATH)
@CrossOrigin
public class FileController {

    private static final Logger logger = LogManager.getLogger(FileController.class);

    @Autowired
    private FileService fileService;

    @Autowired
    private PathHepper pathHepper;


    @PostMapping
    public ResponseEntity deleteImage(@RequestBody Map<String, String> body) {
        logger.info("-- api/files/ - deleteImage --");
        fileService.deleteImage(pathHepper.removePathServerImage(body.get(DefaultPath.PARAMETER_PATH)), body.get(DefaultPath.PARAMETER_PAGETYPE), Integer.parseInt(body.get("id")));
        SuccessMessage successMessage = new SuccessMessage();
        successMessage.setStatus(SuccessMessageConstants.SUCCESS_STATUS);
        successMessage.setMessage(SuccessMessageConstants.DELETE_IMAGE_SUCCESS);
        return new ResponseEntity<>(successMessage, HttpStatus.OK);
    }
}
