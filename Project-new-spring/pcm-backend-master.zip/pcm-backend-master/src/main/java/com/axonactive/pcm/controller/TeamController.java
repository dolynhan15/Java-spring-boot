package com.axonactive.pcm.controller;


import com.axonactive.pcm.constant.DefaultParam;
import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.constant.EntityConstants;
import com.axonactive.pcm.constant.ErrorMessageConstants;
import com.axonactive.pcm.entity.Team;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.model.DTO.TeamDTO;
import com.axonactive.pcm.model.authentication.AuthenticatedUser;
import com.axonactive.pcm.service.FileService;
import com.axonactive.pcm.service.TeamService;
import com.axonactive.pcm.service.TeamTechnologyService;
import com.axonactive.pcm.utility.JwtTokenValidator;
import com.axonactive.pcm.utility.PathHepper;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.axonactive.pcm.constant.EntityConstants.*;

@RestController
@RequestMapping(DefaultPath.TEAM_PATH)
@CrossOrigin
public class TeamController {

    private static final Logger logger = LogManager.getLogger(TeamController.class);

    private final TeamService teamService;

    private final TeamTechnologyService teamTechnologyService;

    private final FileService fileService;

    private final JwtTokenValidator jwtTokenValidator;

    private final PathHepper pathHepper;

    @Autowired
    public TeamController(TeamService teamService, TeamTechnologyService teamTechnologyService, FileService fileService, JwtTokenValidator jwtTokenValidator, PathHepper pathHepper) {
        this.teamService = teamService;
        this.teamTechnologyService = teamTechnologyService;
        this.fileService = fileService;
        this.jwtTokenValidator = jwtTokenValidator;
        this.pathHepper = pathHepper;
    }

    @GetMapping
    public ResponseEntity getActiveTeams() {
        logger.info("-- api/teams/ - getActiveTeams --");
        List<TeamDTO> teams = teamService.readActiveTeamListDTOs();
        for (TeamDTO teamDTO : teams) {
            teamDTO.team.setTeamLogo(pathHepper.handlerImage(teamDTO.team.getTeamLogo()));
        }

        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(teams);
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_TEAM_DTO, SimpleBeanPropertyFilter.serializeAll())
                .addFilter(FILTER_TEAM, SimpleBeanPropertyFilter.filterOutAllExcept(TEAM_ID, TEAM_NAME, TEAM_STATUS, TEAM_LEADER_NAME, TEAM_MEMBERS, TEAM_LOGO))
                .addFilter(FILTER_CUSTOMER, SimpleBeanPropertyFilter.filterOutAllExcept(CUSTOMER_ID, CUSTOMER_NAME));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @GetMapping(DefaultPath.ALL_TEAM_PATH)
    @PreAuthorize("hasAnyAuthority('New Project', 'Edit Project', 'Exception-SM-Interact-Project-Only')")
    public ResponseEntity getTeams(Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/teams/all - getTeams -- user: {}", currentUser.getUsername());
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(teamService.readTeams());
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_TEAM, SimpleBeanPropertyFilter.serializeAll())
                .addFilter(FILTER_PROJECT, SimpleBeanPropertyFilter.filterOutAllExcept(PROJECT_ID, PROJECT_NAME, PROJECT_STATUS, CONTACT))
                .addFilter(FILTER_CONTACT, SimpleBeanPropertyFilter.filterOutAllExcept(CUSTOMER))
                .addFilter(FILTER_CUSTOMER, SimpleBeanPropertyFilter.filterOutAllExcept(CUSTOMER_ID, CUSTOMER_NAME))
                .addFilter(FILTER_TECHNOLOGY, SimpleBeanPropertyFilter.filterOutAllExcept(ID, NAME));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @GetMapping(DefaultPath.ID_VARIABLE)
    @PreAuthorize("hasAnyAuthority('View Team Detail', 'Edit Team', 'Edit My Team', 'Exception-SM-Interact-Project-Only')")
    public ResponseEntity getTeamDetail(@PathVariable int id, Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/teams/{} - getTeamDetail -- user: {}", id, currentUser.getUsername());

        Team team = teamService.readTeamById(id);

        jwtTokenValidator.isTeamOwner(authentication, team.getTeamName());

        team.setTeamLogo(pathHepper.handlerImage(team.getTeamLogo()));
        team.setTeamGallery(pathHepper.handlerScreenShot(team.getTeamGallery()));
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(team);
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_TEAM, SimpleBeanPropertyFilter.serializeAll())
                .addFilter(FILTER_PROJECT, SimpleBeanPropertyFilter.filterOutAllExcept(PROJECT_ID, PROJECT_NAME, PROJECT_STATUS, CONTACT))
                .addFilter(FILTER_CONTACT, SimpleBeanPropertyFilter.filterOutAllExcept(CUSTOMER))
                .addFilter(FILTER_CUSTOMER, SimpleBeanPropertyFilter.filterOutAllExcept(CUSTOMER_ID, CUSTOMER_NAME))
                .addFilter(FILTER_TECHNOLOGY, SimpleBeanPropertyFilter.filterOutAllExcept(ID, NAME));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @PutMapping()
    @PreAuthorize("hasAnyAuthority('Edit Team',  'Edit My Team', 'Exception-SM-Interact-Project-Only')")
    public ResponseEntity editTeam(@RequestBody Team team, Authentication authentication) throws InvalidParamException {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/teams/ - {} - editTeam -- user: {}", team.getTeamId()+"", currentUser.getUsername());

        if (team.getTeamId() == 0) {
            throw new InvalidParamException(ErrorMessageConstants.ID_NOT_FOUND_ERROR, DefaultPath.TEAM_PATH);
        }

        jwtTokenValidator.isTeamOwner(authentication, team.getTeamName());

        team = teamTechnologyService.saveTeamWithNewTechnology(team);
        //Save logo
        team.setTeamLogo(fileService.uploadImage(DefaultParam.TARGET_TEAM, team.getTeamId() + "", pathHepper.removePathServerImage(team.getTeamLogo())));
        team.setTeamGallery(fileService.uploadImageList(DefaultParam.TARGET_TEAM, team.getTeamId() + "", pathHepper.removePathServerScreenShot(team.getTeamGallery())));

        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(teamService.saveTeam(team));
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_TEAM, SimpleBeanPropertyFilter.serializeAll())
                .addFilter(FILTER_PROJECT, SimpleBeanPropertyFilter.filterOutAllExcept(PROJECT_ID, PROJECT_NAME, PROJECT_STATUS, CONTACT))
                .addFilter(FILTER_CONTACT, SimpleBeanPropertyFilter.filterOutAllExcept(CUSTOMER))
                .addFilter(FILTER_CUSTOMER, SimpleBeanPropertyFilter.filterOutAllExcept(CUSTOMER_ID, CUSTOMER_NAME))
                .addFilter(FILTER_TECHNOLOGY, SimpleBeanPropertyFilter.filterOutAllExcept(ID, NAME));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @GetMapping(DefaultPath.GET_ID_BY_NAME_PATH)
    @PreAuthorize("hasAnyAuthority('View Team Detail', 'Edit Team', 'Edit My Team', 'Exception-SM-Interact-Project-Only')")
    public ResponseEntity getTeamIdByTeamName(@PathVariable String teamName, Authentication authentication){
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/teams/getIdByName/{} - getTeamIdByTeamName -- user: {}", teamName, currentUser.getUsername());
        jwtTokenValidator.isTeamOwner(authentication, teamName);
        return new ResponseEntity<>(teamService.getTeamIdByTeamName(teamName), HttpStatus.OK);
    }
}
