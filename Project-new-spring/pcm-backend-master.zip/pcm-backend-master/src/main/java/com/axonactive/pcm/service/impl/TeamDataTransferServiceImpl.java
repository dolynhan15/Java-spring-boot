package com.axonactive.pcm.service.impl;

import com.axonactive.pcm.entity.Team;
import com.axonactive.pcm.model.HRObject.Branch;
import com.axonactive.pcm.model.HRObject.Department;
import com.axonactive.pcm.model.HRObject.TeamHR;
import com.axonactive.pcm.service.TeamDataTransferService;
import com.axonactive.pcm.service.TeamHRService;
import com.axonactive.pcm.service.TeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TeamDataTransferServiceImpl implements TeamDataTransferService {

    @Autowired
    TeamHRService teamHRService;

    @Autowired
    TeamService teamService;

    @Override
    public List<Team> teamHRToTeam() {
        List<Team> teams = new ArrayList<>();
        List<Branch> branches = teamHRService.getAllBranches();
        branches.forEach(branch -> {
            List<Department> departments = teamHRService.getAllDepartmentByBranchId(branch.getBranchId());
            departments.forEach(department -> {
                List<TeamHR> teamHRS = teamHRService.getAllTeamByDepartmentId(department.getDeptId());
                teamHRS.forEach(teamHR -> {
                    if (teamHR.getTeamId() != 79 || teamHR.getTeamId() != 80 || teamHR.getTeamId() != 134) {
                        Team team = new Team();
                        team.setTeamHrId(teamHR.getTeamId());
                        team.setTeamName(teamHR.getTeamName());
                        team.setDepartmentName(department.getDeptName());
                        team.setBranchName(branch.getBranchName());
                        team.setTeamLeaderName(teamHR.getScrumMasterTeamLeader());
                        team.setTeamMembers(teamHR.getMembers().stream().collect(Collectors.joining(";")));
                        teams.add(team);
                    }
                });
            });
        });
        return teams;
    }

    @Override
    public List<Team> saveAllTeam() {
        return teamService.saveAllTeam(this.teamHRToTeam());
    }
}
