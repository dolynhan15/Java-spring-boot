package com.axonactive.pcm.service;

import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.entity.Project;

import java.util.List;

public interface ProjectContactService {

    List<Project> readProjects();

    Project readProjectById(int projectId);

    Project deleteContactDefaultInProject(Project project);

    Contact createContactDefault(Project project);

    void deleteContactById(int contactId);
}
