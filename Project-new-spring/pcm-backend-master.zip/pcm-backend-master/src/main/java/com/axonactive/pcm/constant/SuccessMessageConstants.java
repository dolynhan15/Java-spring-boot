package com.axonactive.pcm.constant;

public  class SuccessMessageConstants {
    public static final String SUCCESS_STATUS = "success";
    public static final String EDIT_WIFIKEY_SUCCESS = "Edit wifi key successful";
    public static final String DELETE_VISITHISTORY_SUCCESS = "Delete visit information successful";
    public static final String DELETE_CONTACT_SUCCESS = "Delete contact successful";
    public static final String DELETE_IMAGE_SUCCESS = "Delete image successful";

}
