package com.axonactive.pcm.service;

import com.axonactive.pcm.entity.Team;

public interface TeamTechnologyService {

    Team saveTeamWithNewTechnology(Team team);
}
