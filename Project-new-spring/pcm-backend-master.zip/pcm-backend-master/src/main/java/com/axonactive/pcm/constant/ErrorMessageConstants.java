package com.axonactive.pcm.constant;

public class ErrorMessageConstants {
    /**
     * Not found
     */
    public static final String CUSTOMER_NOT_FOUND = "Could not find any customers in database.";
    public static final String CUSTOMER_NOT_FOUND_IN_CONTACTS = "Could not find any customers with relative contacts.";
    public static final String CONTACT_NOT_FOUND = "Could not find any contacts in database.";
    public static final String POSITION_NOT_FOUND = "Could not find any positions in database.";
    public static final String TEAM_NOT_FOUND = "Could not find any teams in database.";
    public static final String PROJECT_NOT_FOUND = "Could not find any projects in database.";
    public static final String ENTITY_NOT_FOUND_ERROR = "Entity Not Found.";
    public static final String ID_NOT_FOUND_ERROR = "Could not find id in body";
    public static final String IMAGE_NOT_EXIST = "Image is not exist.";


    /**
     * Invalid param
     */
    public static final String PARAM_INVALID_ERROR = "Invalid Param.";
    public static final String ID_INVALID_ERROR = "Id is Invalid";


    /**
     * Permission
     */
    public static final String YOU_DO_NOT_HAVE_RIGHT_TO_THIS_CUSTOMER = "You don't have permission to this customer.";
    public static final String YOU_DO_NOT_HAVE_RIGHT_TO_THIS_CONTACT = "You don't have permission to this contact.";
    public static final String YOU_DO_NOT_HAVE_RIGHT_TO_THIS_TEAM = "You don't have permission to this team.";
    public static final String YOU_DO_NOT_HAVE_RIGHT_TO_THIS_PROJECTS = "You don't have permission to this projects.";

    public static final String SOMETHING_WENT_WRONG = "Something went wrong.";

    public static final String CANNOT_PARSE_TEAM_HISTORY = "Project cannot parse teams history.";
    public static final String CANNOT_MAP_STRING_OBJECT_TO_TEAM_HISTORY = "Project cannot map string object to team history.";
    public static final String CANNOT_PARSE_LIST_POS = "Project cannot parse POs.";
    public static final String CANNOT_MAP_STRING_OBJECT_TO_LIST_POS = "Project cannot map string object to list POs.";

    public static final String NEGATIVE_PATH_VARIABLE = "Path variable could not be negative.";
    public static final String CANNOT_SAVE = "Could not save.";
}
