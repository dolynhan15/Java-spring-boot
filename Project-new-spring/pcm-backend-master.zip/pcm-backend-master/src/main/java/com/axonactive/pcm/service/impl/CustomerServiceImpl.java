package com.axonactive.pcm.service.impl;

import com.axonactive.pcm.constant.DefaultParam;
import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.constant.ErrorMessageConstants;
import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.entity.Customer;
import com.axonactive.pcm.enums.Status;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.repository.CustomerRepository;
import com.axonactive.pcm.service.CustomerService;
import com.axonactive.pcm.utility.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class CustomerServiceImpl implements CustomerService {

    private static final String COULD_NOT_FIND_ANY_CUSTOMER_IN_DATABASE_WITH_ID = "Could not find any customer in database with id:";
    private static final String CUSTOMER_S_NAME_IS_REQUIRED = "Customer's name is required!";
    private static final String CUSTOMER_S_NAME_IS_TOO_LONG_MAX_LENGTH_IS = "Customer's name is too long! Max length is:";
    private static final String CUSTOMER_S_ADDRESS_IS_TOO_LONG_MAX_LENGTH_IS = "Customer's address is too long! Max length is:";
    private static final String CUSTOMER_S_WEBSITE_IS_TOO_LONG_MAX_LENGTH_IS = "Customer's website is too long! Max length is:";
    private static final String CUSTOMER_S_NOTES_IS_TOO_LONG_MAX_LENGTH_IS = "Customer's notes is too long! Max length is:";
    private static final String CUSTOMER_S_START_DATE_IS_REQUIRED = "Customer's start date is required!";
    private static final String INACTIVE_CUSTOMER_MUST_HAVE_END_DATE = "Inactive customer must have end date!";
    private static final String START_DATE_MUST_BE_BEFORE_END_DATE = "Start date must be before end date!";
    private static final String HTTP = "http://";
    private static final String HTTPS = "https://";
    private final CustomerRepository customerRepository;

    @Autowired
    public CustomerServiceImpl(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @Override
    public Customer readCustomerById(int customerId) {
        if(customerId <= 0){
            throw new InvalidParamException(ErrorMessageConstants.NEGATIVE_PATH_VARIABLE, DefaultPath.CUSTOMER_PATH + "/" + customerId);
        }

        Customer customer = customerRepository.findByCustomerId(customerId);

        if (Objects.isNull(customer)) {
            throw new PCMEntityNotFoundException(COULD_NOT_FIND_ANY_CUSTOMER_IN_DATABASE_WITH_ID, DefaultPath.CUSTOMER_PATH + "/" +  customerId);
        }

        // Make representative contact first of the list
        customer.getContacts().sort(Comparator.comparing(Contact::getContactIsRepresentative).reversed());

        // Make sure don't return null customer Logo
        customer.setCustomerLogo(!StringUtils.isBlank(customer.getCustomerLogo()) ? customer.getCustomerLogo() : "");

        return customer;
    }

    @Override
    public List<Customer> readCustomers() {

        List<Customer> customers = customerRepository.findAllByOrderByCustomerIdDesc();

        if (customers.isEmpty()) {
            throw new PCMEntityNotFoundException(ErrorMessageConstants.CUSTOMER_NOT_FOUND, DefaultPath.CUSTOMER_PATH);
        }

        for (Customer customer:customers) {
            if(!customer.getContacts().isEmpty()){
                List<Contact> representative = customer.getContacts().stream().filter(Contact::getContactIsRepresentative).collect(Collectors.toList());
                customer.setContacts(representative);
            }
        }
        return customers;
    }

    @Override
    public Customer saveCustomer(Customer customer) {
        validate(customer);
        customer.setCustomerWebsite(modifyWebsiteUrl(customer.getCustomerWebsite()));
        return customerRepository.save(customer);
    }

    @Override
    public List<Customer> readCustomersAllContact() {
        List<Customer> customers = (List<Customer>) customerRepository.findAll();

        if (customers.isEmpty()) {
            throw new PCMEntityNotFoundException(ErrorMessageConstants.CUSTOMER_NOT_FOUND, DefaultPath.CUSTOMER_PATH);
        }
        return customers;
    }

    private  void validate(Customer customer) throws InvalidParamException {
        String path = DefaultPath.CUSTOMER_PATH + (customer.getCustomerId() != 0 ? "/" + customer.getCustomerId() : "");
        if (StringUtils.isBlank(customer.getCustomerName())) {
            throw new InvalidParamException(CUSTOMER_S_NAME_IS_REQUIRED, path);
        }

        if ((customer.getCustomerName()+ "").length() > DefaultParam.MAX_STRING_FIELD_LENGTH) {
            throw new InvalidParamException(CUSTOMER_S_NAME_IS_TOO_LONG_MAX_LENGTH_IS + DefaultParam.MAX_STRING_FIELD_LENGTH, path);
        }

        if ((customer.getCustomerAddress()+ "").length() > DefaultParam.MAX_TEXT_FIELD_LENGTH) {
            throw new InvalidParamException(CUSTOMER_S_ADDRESS_IS_TOO_LONG_MAX_LENGTH_IS + DefaultParam.MAX_TEXT_FIELD_LENGTH, path);
        }

        if ((customer.getCustomerWebsite()+ "").length() > DefaultParam.MAX_STRING_FIELD_LENGTH) {
            throw new InvalidParamException(CUSTOMER_S_WEBSITE_IS_TOO_LONG_MAX_LENGTH_IS + DefaultParam.MAX_STRING_FIELD_LENGTH, path);
        }

        if ((customer.getCustomerNotes()+ "").length() > DefaultParam.MAX_TEXT_FIELD_LENGTH) {
            throw new InvalidParamException(CUSTOMER_S_NOTES_IS_TOO_LONG_MAX_LENGTH_IS + DefaultParam.MAX_TEXT_FIELD_LENGTH, path);
        }

        if (Objects.isNull(customer.getCustomerStartDate())) {
            throw new InvalidParamException(CUSTOMER_S_START_DATE_IS_REQUIRED, path);
        }
        if (customer.getStatus() == Status.INACTIVE && Objects.isNull(customer.getCustomerEndDate())) {
            throw new InvalidParamException(INACTIVE_CUSTOMER_MUST_HAVE_END_DATE, path);
        }
        if (customer.getStatus() == Status.INACTIVE && !DateUtil.compareDate(customer.getCustomerStartDate(), customer.getCustomerEndDate())) {
            throw new InvalidParamException(START_DATE_MUST_BE_BEFORE_END_DATE, path);
        }
    }

    private String modifyWebsiteUrl(String url) {
        if (Objects.nonNull(url) && !url.startsWith(HTTP) && !url.startsWith(HTTPS)) {
            url = HTTP + url;
        }
        return url;
    }
}
