package com.axonactive.pcm.controller;

import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.constant.ErrorMessageConstants;
import com.axonactive.pcm.entity.NetworkInfrastructure;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.model.authentication.AuthenticatedUser;
import com.axonactive.pcm.service.NetworkInfrastructureService;
import com.axonactive.pcm.service.ProjectService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(DefaultPath.NETWORKINFRASTRUCTURE_PATH)
@CrossOrigin
public class NetworkInfrastructureController {

    private static final Logger logger = LogManager.getLogger(NetworkInfrastructureController.class);

    private final NetworkInfrastructureService networkInfrastructureService;

    private final ProjectService projectService;

    @Autowired
    public NetworkInfrastructureController(NetworkInfrastructureService networkInfrastructureService, ProjectService projectService) {
        this.networkInfrastructureService = networkInfrastructureService;
        this.projectService = projectService;
    }

    @PostMapping(DefaultPath.ID_VARIABLE)
    @PreAuthorize("hasAnyAuthority('Edit Network Infrastructure')")
    public ResponseEntity createNetworkInfrastructure(@RequestBody NetworkInfrastructure networkInfrastructure, @PathVariable int id, Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/networkinfrastructures/{} - createNetworkInfrastructure -- user: {}", id, currentUser.getUsername());
        networkInfrastructure = networkInfrastructureService.saveNetworkInfrastructure(networkInfrastructure);
        projectService.updateNetworkInfrastructureId(networkInfrastructure.getId(), id);
        return new ResponseEntity<>(networkInfrastructure, HttpStatus.CREATED);
    }

    @PutMapping()
    @PreAuthorize("hasAnyAuthority('Edit Network Infrastructure')")
    public ResponseEntity UpdateNetworkInfrastructure(@RequestBody NetworkInfrastructure networkInfrastructure, Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/networkinfrastructures/ - {} - UpdateNetworkInfrastructure -- user: {}", networkInfrastructure.getId()+"", currentUser.getUsername());
        if (networkInfrastructure.getId() <= 0) {
            throw new InvalidParamException(ErrorMessageConstants.ID_INVALID_ERROR, DefaultPath.NETWORKINFRASTRUCTURE_PATH);
        }
        networkInfrastructure = networkInfrastructureService.saveNetworkInfrastructure(networkInfrastructure);
        return new ResponseEntity<>(networkInfrastructure, HttpStatus.OK);
    }
}
