package com.axonactive.pcm.entity;

import com.axonactive.pcm.constant.EntityConstants;
import com.axonactive.pcm.enums.Status;
import com.fasterxml.jackson.annotation.*;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


@Entity
@JsonFilter(EntityConstants.FILTER_CUSTOMER)
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable = false)
    private int customerId;

    @Column(columnDefinition = "TEXT")
    private String customerLogo;

    @Column(nullable = false)
    private String customerName;

    private Date customerStartDate;

    private Date customerEndDate;

    @OneToMany(mappedBy = "customer")
    private List<Contact> contacts;

    @Column(columnDefinition = "TEXT")
    private String customerAddress;

    private String customerWebsite;

    @Column(columnDefinition = "TEXT")
    private String customerNotes;

    private Status status;

    public int getCustomerId() {
        return customerId;
    }

    public String getCustomerLogo() {
        return customerLogo;
    }

    public void setCustomerLogo(String customerLogo) {
        this.customerLogo = customerLogo;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public String getCustomerWebsite() {
        return customerWebsite;
    }

    public void setCustomerWebsite(String customerWebsite) {
        this.customerWebsite = customerWebsite;
    }

    public String getCustomerNotes() {
        return customerNotes;
    }

    public void setCustomerNotes(String customerNotes) {
        this.customerNotes = customerNotes;
    }

    public Date getCustomerStartDate() {
        return customerStartDate;
    }

    public void setCustomerStartDate(Date customerStartDate) {
        this.customerStartDate = customerStartDate;
    }

    public Date getCustomerEndDate() {
        return customerEndDate;
    }

    public void setCustomerEndDate(Date customerEndDate) {
        this.customerEndDate = customerEndDate;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public List<Contact> getContacts() {
        return contacts;
    }

    public void setContacts(List<Contact> contacts) {
        this.contacts = contacts;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
}
