package com.axonactive.pcm.controller;

import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.constant.EntityConstants;
import com.axonactive.pcm.constant.ErrorMessageConstants;
import com.axonactive.pcm.constant.SuccessMessageConstants;
import com.axonactive.pcm.entity.VisitHistory;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.model.SuccessEntity.SuccessMessage;
import com.axonactive.pcm.model.authentication.AuthenticatedUser;
import com.axonactive.pcm.service.VisitHistoryService;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;

import static com.axonactive.pcm.constant.EntityConstants.*;

@RestController
@RequestMapping(DefaultPath.VISITHISTORY_PATH)
@CrossOrigin
public class VisitHistoryController {

    private static final Logger logger = LogManager.getLogger(TechnologyController.class);

    private final VisitHistoryService visitHistoryService;

    @Autowired
    public VisitHistoryController(VisitHistoryService visitHistoryService) {
        this.visitHistoryService = visitHistoryService;
    }

    @PostMapping()
    @PreAuthorize("hasAnyAuthority('Update Visit History')")
    public ResponseEntity createVisitHistory(@RequestBody VisitHistory visitHistory, Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/visisthistory/ - {} - createVisitHistory -- user: {}",
                Objects.nonNull(visitHistory.getContact()) ? visitHistory.getContact().getContactFirstName()+"" : "contact null",
                currentUser.getUsername());
        visitHistory = visitHistoryService.save(visitHistory);

        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(visitHistory);
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_VISIT_HISTORY, SimpleBeanPropertyFilter.serializeAllExcept(CONTACT));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CREATED);
    }

    @PutMapping()
    @PreAuthorize("hasAnyAuthority('Update Visit History')")
    public ResponseEntity updateVisitHistory(@RequestBody VisitHistory visitHistory, Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/visisthistory/ - {} - updateVisitHistory -- user: {}", visitHistory.getId()+"", currentUser.getUsername());
        if (visitHistory.getId() <= 0) {
            throw new InvalidParamException(ErrorMessageConstants.ID_INVALID_ERROR, DefaultPath.VISITHISTORY_PATH);
        }

        visitHistory = visitHistoryService.save(visitHistory);

        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(visitHistory);
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_VISIT_HISTORY, SimpleBeanPropertyFilter.serializeAllExcept(CONTACT));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @DeleteMapping(DefaultPath.ID_VARIABLE)
    @PreAuthorize("hasAnyAuthority('Update Visit History')")
    public ResponseEntity deleteVisitHistory(@PathVariable int id, Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/visisthistory/{} - deleteVisitHistory -- user: {}", id, currentUser.getUsername());
        if (id <= 0) {
            throw new InvalidParamException(ErrorMessageConstants.ID_INVALID_ERROR, DefaultPath.VISITHISTORY_PATH);
        }

        visitHistoryService.deleteVisithistoryById(id);
        SuccessMessage successMessage = new SuccessMessage();
        successMessage.setStatus(SuccessMessageConstants.SUCCESS_STATUS);
        successMessage.setMessage(SuccessMessageConstants.DELETE_VISITHISTORY_SUCCESS);

        return new ResponseEntity<>(successMessage, HttpStatus.OK);
    }
}
