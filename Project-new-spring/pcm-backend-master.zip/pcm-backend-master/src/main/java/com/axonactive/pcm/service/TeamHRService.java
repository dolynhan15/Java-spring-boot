package com.axonactive.pcm.service;

import com.axonactive.pcm.model.HRObject.*;

import java.util.List;

public interface TeamHRService {

    List<Branch> getAllBranches();
    List<Department> getAllDepartmentByBranchId(int id);
    List<TeamHR> getAllTeamByDepartmentId(int id);
}
