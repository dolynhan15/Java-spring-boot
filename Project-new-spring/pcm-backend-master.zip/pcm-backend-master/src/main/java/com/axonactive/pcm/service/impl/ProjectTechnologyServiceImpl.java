package com.axonactive.pcm.service.impl;

import com.axonactive.pcm.entity.Project;
import com.axonactive.pcm.entity.Technology;
import com.axonactive.pcm.service.ProjectTechnologyService;
import com.axonactive.pcm.service.TechnologyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class ProjectTechnologyServiceImpl implements ProjectTechnologyService {
    @Autowired
    private TechnologyService technologyService;

    @Override
    public Project saveProjectWithNewTechnology(Project project) {
        List<Technology> technologies = technologyService.saveListTechnologiesNotExist(project.getTechnologies());
        project.setTechnologies(technologies);
        return project;
    }
}
