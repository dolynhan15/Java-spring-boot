package com.axonactive.pcm.service.impl;

import com.axonactive.pcm.constant.DefaultParam;
import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.constant.ErrorMessageConstants;
import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.entity.Project;
import com.axonactive.pcm.entity.VisitHistory;
import com.axonactive.pcm.enums.Gender;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.service.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class ProjectContactServiceImpl implements ProjectContactService {

    public static final String YOU_CANNOT_DELETE_THIS_CONTACT_BELONG_TO_PROJECTS = "You cannot delete this contact belong to projects: ";
    public static final String YOU_CANNOT_DELETE_THIS_CONTACT_BECAUSE_IT_DOESN_T_EXIST = "You cannot delete this contact because it doesn't exist";
    @Autowired
    public ProjectService projectService;

    @Autowired
    @Lazy
    public ContactService contactService;

    @Autowired
    public PositionService positionService;

    @Autowired
    public TeamService teamService;

    @Autowired
    public VisitHistoryService visitHistoryService;

    @Override
    public List<Project> readProjects() {
        List<Project> projects = projectService.findAllByOrderByProjectIdDesc();

        projects.stream().forEach(project -> {
            List<Integer> a = project.getListContactId();
            if(!project.getListContactId().isEmpty()) {
                List<Contact> contacts = contactService.findByContactIdIn(project.getListContactId());
                project.setListContactPOs(contacts);
            }
        });

        return projects;
    }

    @Override
    public Project readProjectById(int projectId) throws PCMEntityNotFoundException {
        if (projectId <= 0) {
            throw new InvalidParamException(ErrorMessageConstants.NEGATIVE_PATH_VARIABLE, DefaultPath.PROJECT_PATH + "/" + projectId);
        }

        Project project = projectService.findByProjectId(projectId);

        if(project.getListContactId().isEmpty()) {
            return project;
        }

        List<Contact> contacts = contactService.findByContactIdIn(project.getListContactId());
        project.setListContactPOs(contacts);
        project.setProjectCover(!StringUtils.isBlank(project.getProjectCover()) ? project.getProjectCover() : "");
        return project;
    }

    @Override
    public Project deleteContactDefaultInProject(Project project) {
        Project oldProject = projectService.findByProjectId(project.getProjectId());
        if(oldProject.getContact().getContactId() != project.getContact().getContactId()){
            project.setContact(createContactDefault(project));
            projectService.updateContactId(project.getContact().getContactId(), project.getProjectId());
            if( oldProject.getContact().isContactIsDefault()) {
                contactService.delete(oldProject.getContact().getContactId());
            }
        }
        return project;
    }

    @Override
    public Contact createContactDefault(Project project) {
        if (project.getContact().getContactId() == 0) {
            Contact contact = new Contact();
            contact.setContactFirstName(DefaultParam.DEFAULT_CONTACT);
            contact.setContactLastName(DefaultParam.DEFAULT_CONTACT);
            contact.setContactEmail(DefaultParam.DEFAULT_CONTACT_EMAIL);
            contact.setContactPosition(positionService.readPositionByPositionTitle(DefaultParam.DEFAULT_CONTACT_POSITION));
            contact.setContactGender(Gender.OTHER);
            contact.setCustomer(project.getContact().getCustomer());
            contact.setContactIsDefault(true);
            return contactService.saveContact(contact);
        }
        return project.getContact();
    }

    @Override
    public void deleteContactById(int contactId) {
        List<String> projectNameList = projectService.findProjectNameByContactId(contactId);
        List<Project> projectsHasPOs = projectService.findByListPOsNotNull();
        if (Objects.nonNull(projectsHasPOs) && !projectsHasPOs.isEmpty()) {
            projectsHasPOs.stream().forEach(project -> {
                project.getListContactId().stream().forEach(id -> {
                    if(id == contactId){
                        projectNameList.add(project.getProjectName());
                    }
                });
            });
        }
        if (!projectNameList.isEmpty()) {
            throw new InvalidParamException(YOU_CANNOT_DELETE_THIS_CONTACT_BELONG_TO_PROJECTS
                    + projectNameList.toString().substring(1, projectNameList.toString().length()-1),
                    DefaultPath.CONTACT_PATH + "/" + contactId);
        }

        List<VisitHistory> visitHistories = visitHistoryService.findVisitHistoriesByContactId(contactId);
        if (!visitHistories.isEmpty()) {
            visitHistoryService.delete(visitHistories);
        }
        try {
            contactService.delete(contactId);
        } catch (EmptyResultDataAccessException e){
            throw new InvalidParamException(YOU_CANNOT_DELETE_THIS_CONTACT_BECAUSE_IT_DOESN_T_EXIST, DefaultPath.CONTACT_PATH + "/" + contactId);
        }
    }
}
