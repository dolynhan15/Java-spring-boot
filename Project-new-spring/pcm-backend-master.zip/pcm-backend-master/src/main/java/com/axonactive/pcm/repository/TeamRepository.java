package com.axonactive.pcm.repository;

import com.axonactive.pcm.entity.Team;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Transactional
@Repository
public interface TeamRepository extends CrudRepository<Team, Integer>{

    @Query(value = "Select * from team where team_id in (select team_id from project_team where project_id in " +
            "(select project_id from project where contact_id in (select contact_id from contact where customer_id = :id)))", nativeQuery = true)
    List<Team> getTeamsByCustomerId(@Param("id") int id);

    @Query(value = "Select * from team where team_id in (select team_id from project_team where project_id in " +
            "(select project_id from project where contact_id = :id))", nativeQuery = true)
    List<Team> getTeamsByContactId(@Param("id") int id);

    @Query(value = "Select * from team where team_id in (select team_id from project_team where project_id= :id)", nativeQuery = true)
    List<Team> getTeamsByProjectId(@Param("id") int id);

    Team findByTeamId(int teamId);

    @Query(value = "select t from Team t ")
    List<Team> findAllTeams();

    @Modifying
    @Query(value = "update team set branch_name = :branch_name, department_name = :department_name, team_email = :team_email, team_hr_id = :team_hr_id, " +
            "team_leader_name= :team_leader_name, team_members = :team_members, team_name = :team_name, team_notes = :team_notes where team_id = :team_id", nativeQuery = true)
    int updateTeam(@Param("branch_name") String branch_name, @Param("department_name") String department_name, @Param("team_email") String team_email,
                   @Param("team_hr_id") int team_hr_id, @Param("team_leader_name") String team_leader_name, @Param("team_members") String team_members,
                   @Param("team_name") String team_name, @Param("team_notes") String team_notes, @Param("team_id") int team_id);


    @Query(value = "select t.teamId from Team t where t.teamName = :teamName")
    Integer getTeamIdByTeamName(@Param("teamName") String teamName);



}
