package com.axonactive.pcm.service.impl;

import com.axonactive.pcm.constant.DefaultParam;
import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.constant.ErrorMessageConstants;
import com.axonactive.pcm.entity.Position;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.repository.PositionRepository;
import com.axonactive.pcm.service.PositionService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PositionServiceImpl implements PositionService {
    public static final String POSITION_S_TITLE_IS_REQUIRED = "Position's title is required!";
    public static final String POSITION_S_TITLE_IS_TOO_LONG_MAX_LENGTH_IS = "Position's title is too long! Max length is ";

    @Autowired
    private PositionRepository positionRepository;

    public List<Position> readPositions(){
        List<Position> result = (List<Position>) positionRepository.findAll();
        if(result.size() == 0){
            throw new PCMEntityNotFoundException(ErrorMessageConstants.POSITION_NOT_FOUND, DefaultPath.POSITION_PATH);
        }
        return result;
    }

    @Override
    public Position readPositionByPositionTitle(String positionTitle) {
        return positionRepository.findByPositionTitle(positionTitle);
    }

    @Override
    public Position savePosition(Position position) {
        validate(position);
        return positionRepository.save(position);
    }

    private void validate(Position position) throws InvalidParamException {
        String path = DefaultPath.POSITION_PATH + (position.getPositionId() != 0 ? "/" + position.getPositionId() : "");
        if(StringUtils.isBlank(position.getPositionTitle())){
            throw new InvalidParamException(POSITION_S_TITLE_IS_REQUIRED, path);
        }

        if((position.getPositionTitle()+ "").length() > DefaultParam.MAX_STRING_FIELD_LENGTH){
            throw new InvalidParamException(POSITION_S_TITLE_IS_TOO_LONG_MAX_LENGTH_IS + DefaultParam.MAX_STRING_FIELD_LENGTH, path);
        }
    }
}
