package com.axonactive.pcm.service.impl;

import com.axonactive.pcm.constant.DefaultParam;
import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.entity.Customer;
import com.axonactive.pcm.entity.Project;
import com.axonactive.pcm.enums.Gender;
import com.axonactive.pcm.repository.ContactRepository;
import com.axonactive.pcm.service.ContactService;
import com.axonactive.pcm.service.CustomerContactService;
import com.axonactive.pcm.service.PositionService;
import com.axonactive.pcm.service.ProjectService;
import com.axonactive.pcm.utility.PathHepper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


@Service
public class CustomerContactServiceImpl implements CustomerContactService {

    @Autowired
    @Lazy
    private ContactService contactService;

    private final ProjectService projectService;

    private final PositionService positionService;

    private final ContactRepository contactRepository;

    private final PathHepper pathHepper;

    @Autowired
    public CustomerContactServiceImpl(ProjectService projectService,
                                      PositionService positionService,
                                      ContactRepository contactRepository,
                                      PathHepper pathHepper) {

        this.projectService = projectService;
        this.positionService = positionService;
        this.contactRepository = contactRepository;
        this.pathHepper = pathHepper;
    }

    @Override
    public Customer saveContactsWithCustomer(Customer customer, List<Contact> contacts) {
        if(Objects.isNull(contacts) || contacts.isEmpty()){
            contactService.resetContactsCustomerIdToNullBeforeSave(customer.getCustomerId(), new int[1]);
        } else {
            int[] noResetContacts = contacts.stream().mapToInt(Contact::getContactId).toArray();
            for (Contact contact: contacts) {
                contact.setCustomer(customer);
            }
            contactService.resetContactsCustomerIdToNullBeforeSave(customer .getCustomerId(), noResetContacts);
            for (Contact contact : contacts) {
                contact.setContactAvatar(pathHepper.removePathServerImage(contact.getContactAvatar()));
            }
            contactService.saveContacts(contacts);
        }
        return customer;
    }

    @Override
    public Customer editContactCustomer(Customer oldCustomer, Customer newCustomer) {
        List<Contact> ListContactToBeSaved = new ArrayList<>();
        List<Integer> ListContactToBeDeleted = new ArrayList<>();

        for(Contact newContact : newCustomer.getContacts()) {
            if(oldCustomer.getContacts().stream().noneMatch(o -> o.getContactId() == newContact.getContactId())){
                newContact.setContactAvatar(pathHepper.removePathServerImage(newContact.getContactAvatar()));
                newContact.setContactGallery(pathHepper.removePathServerScreenShot(newContact.getContactGallery()));
                ListContactToBeSaved.add(contactRepository.save(newContact));
            }
        }

        for(Contact oldContact : oldCustomer.getContacts()) {
            if(newCustomer.getContacts().stream().noneMatch(n -> n.getContactId() == oldContact.getContactId())){
                ListContactToBeDeleted.add(oldContact.getContactId());
            } else {
                List<Contact> contacts = newCustomer.getContacts();
                for(Contact contact : contacts){
                    if(contact.getContactId() == oldContact.getContactId()){
                        oldContact.setContactIsRepresentative(contact.getContactIsRepresentative());
                        oldContact.setContactPosition(contact.getContactPosition());
                    }
                }
                ListContactToBeSaved.add(oldContact);
            }
        }

        for (Contact ct: ListContactToBeSaved) {
            contactService.updateCustomerId(ct.getContactId(), newCustomer.getCustomerId(), ct.getContactIsRepresentative());
        }

        UnsetCustomerInContact(ListContactToBeDeleted);

        newCustomer.setContacts(ListContactToBeSaved);
        return newCustomer;
    }

    private void UnsetCustomerInContact(List<Integer> listContactToBeDeleted) {
        for (Integer i: listContactToBeDeleted) {
            List<Project> projects = projectService.readProjectsByContactId(i);
            if(projects.size() == 0){
                contactService.unSetCustomer(i);
            }else{
                contactService.unSetCustomer(i);
                for(Project project : projects){
                    Contact contact = new Contact();
                    contact.setContactFirstName(DefaultParam.DEFAULT_CONTACT);
                    contact.setContactLastName(DefaultParam.DEFAULT_CONTACT);
                    contact.setContactEmail(DefaultParam.DEFAULT_CONTACT_EMAIL);
                    contact.setContactPosition(positionService.readPositionByPositionTitle(DefaultParam.DEFAULT_CONTACT_POSITION));
                    contact.setContactGender(Gender.OTHER);
                    contact.setContactIsDefault(true);
                    contact.setCustomer(project.getContact().getCustomer());
                    contact = contactService.saveContact(contact);
                    project.setContact(contact);
                }
            }
        }
    }
}
