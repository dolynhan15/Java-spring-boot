package com.axonactive.pcm.constant;

public class EntityConstants {
    /**
     * Filter name
     */
    public static final String FILTER_CONTACT = "filter.Contact";
    public static final String FILTER_CUSTOMER = "filter.Customer";
    public static final String FILTER_POSITION = "filter.Position";
    public static final String FILTER_PROJECT = "filter.Project";
    public static final String FILTER_TEAM = "filter.Team";
    public static final String FILTER_TECHNOLOGY = "filter.Technology";
    public static final String FILTER_VISIT_HISTORY = "filter.VisitHistory";

    /**
     * Commons
     */
    public static final String ID = "id";
    public static final String NAME = "name";
    public static final String STATUS = "status";

    public static final String CONTACT = "contact";
    public static final String CONTACTS = "contacts";
    public static final String CUSTOMER = "customer";
    public static final String CUSTOMERS = "customers";
    public static final String TEAM = "team";
    public static final String TEAMS = "teams";
    public static final String PROJECT = "project";
    public static final String PROJECTS = "projects";
    public static final String POSITION = "positon";
    public static final String POSITIONS = "positons";
    public static final String TECHNOLOGY = "technology";
    public static final String TECHNOLOGIES = "technologies";

    public static final String LIST_POs = "listPOs";
    public static final String LIST_CONTACT_POS = "listContactPOs";

    /**
     * Contact Attributes
     */
    public static final String CONTACT_ID = "contactId";
    public static final String CONTACT_FIRST_NAME = "contactFirstName";
    public static final String CONTACT_LAST_NAME = "contactLastName";
    public static final String CONTACT_GENDER = "contactGender";
    public static final String CONTACT_AVATAR = "contactAvatar";
    public static final String CONTACT_BIRTHDAY = "contactBirthday";
    public static final String CONTACT_PHONE = "contactPhone";
    public static final String CONTACT_EMAIL = "contactEmail";
    public static final String CONTACT_SKYPE = "contactSkype";
    public static final String CONTACT_SLACK = "contactSlack";
    public static final String CONTACT_LINKEDIN = "contactLinkedin";
    public static final String CONTACT_WIFIKEY = "contactWifiKey";
    public static final String CONTACT_NOTES = "contactNotes";
    public static final String CONTACT_IS_REPRESENTATIVE = "contactIsRepresentative";
    public static final String CONTACT_IS_DEFAULT = "contactIsDefault";
    public static final String VISIT_HISTORIES = "visitHistories";
    public static final String CONTACT_GALLERY = "contactGallery";


    /**
     * Customer Attributes
     */
    public static final String CUSTOMER_ID = "customerId";
    public static final String CUSTOMER_LOGO = "customerLogo";
    public static final String CUSTOMER_NAME = "customerName";
    public static final String CUSTOMER_START_DATE = "customerStartDate";
    public static final String CUSTOMER_END_DATE = "customerEndDate";
    public static final String CUSTOMER_ADDRESS = "customerAddress";
    public static final String CUSTOMER_WEBSITE = "customerWebsite";
    public static final String CUSTOMER_NOTES = "customerNotes";


    /**
     * NetworkInfrastructure Attributes
     */
    public static final String NETWORK_INFRASTRUCTURE_SERVER = "server";
    public static final String NETWORK_INFRASTRUCTURE_OS = "operationSystem";
    public static final String NETWORK_INFRASTRUCTURE_IP = "ip";
    public static final String NETWORK_INFRASTRUCTURE_CORE = "core";
    public static final String NETWORK_INFRASTRUCTURE_MEMORY = "memory";
    public static final String NETWORK_INFRASTRUCTURE_CAPACITY = "capacity";
    public static final String NETWORK_INFRASTRUCTURE_USERNAME = "username";
    public static final String NETWORK_INFRASTRUCTURE_PASSWORD = "password";


    /**
     * Position Attributes
     */
    public static final String POSITION_ID = "positionId";
    public static final String POSITION_TITLE = "positionTitle";

    /**
     * Project Attributes
     */
    public static final String PROJECT_ID = "projectId";
    public static final String PROJECT_NAME = "projectName";
    public static final String PROJECT_COVER = "projectCover";
    public static final String PROJECT_DESCRIPTION = "projectDescription";
    public static final String PROJECT_NOTES = "projectNotes";
    public static final String PROJECT_START_DATE = "projectStartDate";
    public static final String PROJECT_END_DATE = "projectEndDate";
    public static final String PROJECT_STATUS = "projectStatus";
    public static final String PROJECT_TEAM_HISTORY = "teamHistory";
    public static final String PROJECT_SCREENSHOT = "projectScreenshot";
    public static final String PROJECT_NETWORK_INFRASTRUCTURE = "networkInfrastructure";


    /**
     * Team Attributes
     */
    public static final String TEAM_ID = "teamId";
    public static final String ESTABLISH_DATE = "establishDate";
    public static final String TEAM_LOGO = "teamLogo";
    public static final String TEAM_NAME = "teamName";
    public static final String TEAM_HR_ID = "teamHrId";
    public static final String TEAM_NOTES = "teamNotes";
    public static final String BRANCH_NAME = "branchName";
    public static final String TEAM_LEADER_NAME = "teamLeaderName";
    public static final String TEAM_MEMBERS = "teamMembers";
    public static final String DEPARTMENT_NAME = "departmentName";
    public static final String TEAM_EMAIL = "teamEmail";
    public static final String TEAM_GALLERY = "teamGallery";

    /**
     * Technology Attributes
     */

    /**
     * VisitHistory Attributes
     */
    public static final String START_DATE = "startDate";
    public static final String END_DATE = "endDate";
    public static final String NOTES = "notes";
    public static final String FILTER_TEAM_DTO = "filter.TeamDTO";
    public static final String TEAM_STATUS = "teamStatus";
}
