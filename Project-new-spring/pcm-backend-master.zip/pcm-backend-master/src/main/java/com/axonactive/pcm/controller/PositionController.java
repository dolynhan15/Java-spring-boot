package com.axonactive.pcm.controller;


import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.constant.EntityConstants;
import com.axonactive.pcm.model.authentication.AuthenticatedUser;
import com.axonactive.pcm.service.PositionService;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import static com.axonactive.pcm.constant.EntityConstants.*;


@RestController
@RequestMapping(DefaultPath.POSITION_PATH)
@CrossOrigin
public class PositionController {
    private static final Logger logger = LogManager.getLogger(PositionController.class);
    @Autowired
    private PositionService positionService;

    @GetMapping()
    @PreAuthorize("hasAnyAuthority('Edit Customer', 'New Contact', 'Edit Contact', 'New Customer')")
    public ResponseEntity getPositions(Authentication authentication){
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/positions/ - getPositions -- user: {}", currentUser.getUsername());
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(positionService.readPositions());
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_POSITION, SimpleBeanPropertyFilter.serializeAllExcept(CONTACTS));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }
}
