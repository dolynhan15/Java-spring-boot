package com.axonactive.pcm.model.HRObject;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class TeamHR {

    @JsonProperty("teamId")
    private int teamId;

    @JsonProperty("teamName")
    private String teamName;

    @JsonProperty("scrumMasterTeamLeader")
    private String scrumMasterTeamLeader;

    @JsonProperty("members")
    private List<String> members;

    public int getTeamId() {
        return teamId;
    }

    public void setTeamId(int teamId) {
        this.teamId = teamId;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public String getScrumMasterTeamLeader() {
        return scrumMasterTeamLeader;
    }

    public void setScrumMasterTeamLeader(String scrumMasterTeamLeader) {
        this.scrumMasterTeamLeader = scrumMasterTeamLeader;
    }

    public List<String> getMembers() {
        return members;
    }

    public void setMembers(List<String> members) {
        this.members = members;
    }
}
