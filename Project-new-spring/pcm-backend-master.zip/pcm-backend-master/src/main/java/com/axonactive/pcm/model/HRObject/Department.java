package com.axonactive.pcm.model.HRObject;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Department {

    @JsonProperty("deptId")
    private int deptId;

    @JsonProperty("deptName")
    private String deptName;

    public int getDeptId() {
        return deptId;
    }

    public void setDeptId(int deptId) {
        this.deptId = deptId;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }
}
