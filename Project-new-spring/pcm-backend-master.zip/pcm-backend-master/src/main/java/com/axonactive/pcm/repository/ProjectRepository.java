package com.axonactive.pcm.repository;

import com.axonactive.pcm.entity.Project;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Transactional
@Repository
public interface ProjectRepository extends CrudRepository<Project, Integer> {

    List<Project> findAllByOrderByProjectIdDesc();

    @Modifying
    @Query(value = "update project set contact_id = :contact_id where project_id = :project_id", nativeQuery = true)
    int updateContactId(@Param("contact_id") int contact_id, @Param("project_id") int project_id);

    Project findByProjectId(int projectId);

    @Query(value = "select * from project where contact_id = :contact_id", nativeQuery = true)
    List<Project> findProjectByContactId(@Param("contact_id") int contact_id);

    @Query(value = "select * from project p where p.project_id in (select pt.project_id from project_team pt where pt.team_id = (select t.team_id from team t where t.team_name = :teamName)) ORDER By p.project_id desc", nativeQuery = true)
    List<Project> findAllByTeamName(@Param("teamName") String teamName);

    @Query(value = "select * from project p where p.project_id in (select pt.project_id from project_team pt where pt.team_id = ( select t.team_id from team t where t.team_name = :teamName)) or p.project_id not in (select project_team.project_id from project_team) ORDER By p.project_id desc", nativeQuery = true)
    List<Project> findByTeamNameAndNotHasTeam(@Param("teamName") String teamname);

    @Modifying
    @Query(value = "UPDATE project SET networkinfrastructure_id = :networkinfrastructureId where project_id = :projectId", nativeQuery = true)
    int updateNetworkInfrastructureId(@Param("networkinfrastructureId") int networkinfrastructureId, @Param("projectId") int projectId);

    @Query(value = "SELECT p.projectName FROM Project p WHERE p.contact.contactId = ?1")
    List<String> findProjectNameByContactId(int contactId);

    List<Project> findByListPOsNotNull();
}


