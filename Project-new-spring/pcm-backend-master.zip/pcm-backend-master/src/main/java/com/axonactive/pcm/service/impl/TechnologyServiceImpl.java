package com.axonactive.pcm.service.impl;

import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.constant.ErrorMessageConstants;
import com.axonactive.pcm.entity.Technology;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.repository.TechnologyRepository;
import com.axonactive.pcm.service.TechnologyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
public class TechnologyServiceImpl implements TechnologyService {
    @Autowired
    private TechnologyRepository technologyRepository;

    @Override
    public Technology saveTechnology(Technology technology) {
        return technologyRepository.save(technology);
    }

    @Override
    public List<Technology> getTechnologies() {
        List<Technology> result = (List<Technology>) technologyRepository.findAll();
        if(result.size() == 0){
            throw new PCMEntityNotFoundException(ErrorMessageConstants.POSITION_NOT_FOUND, DefaultPath.POSITION_PATH);
        }
        return result;
    }

    @Override
    public Technology getTechnologyByName(String technologyName) {
        return technologyRepository.findByName(technologyName);
    }

    @Override
    public List<Technology> saveListTechnologiesNotExist(List<Technology> technologies) {

        List<Technology> technologyList = new ArrayList<>();
        for (Technology t : technologies) {
            Technology tech = this.getTechnologyByName(t.getName().trim().toUpperCase());
            if (Objects.isNull(tech)) {
                Technology newTechnology = new Technology();
                newTechnology.setName(t.getName().toUpperCase());
                newTechnology = this.saveTechnology(newTechnology);
                technologyList.add(newTechnology);
            } else {
                technologyList.add(tech);
            }
        }
        return technologyList;
    }



}
