package com.axonactive.pcm.entity;

import com.axonactive.pcm.constant.EntityConstants;
import com.fasterxml.jackson.annotation.JsonFilter;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@JsonFilter(EntityConstants.FILTER_TEAM)
public class Team {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable = false)
    private int teamId;

    private Date establishDate;

    @Column(columnDefinition = "TEXT")
    private String teamLogo;

    @Column(nullable = false)
    private String teamName;

    private int teamHrId;


    @Column(columnDefinition = "TEXT")
    private String teamNotes;

    @ManyToMany(mappedBy = "teams")
    private List<Project> projects;

    private String branchName;

    private String teamLeaderName;

    @Column(columnDefinition = "TEXT")
    private String teamMembers;

    private String departmentName;

    private String teamEmail;

    @Column(columnDefinition = "TEXT")
    private String teamGallery;

    @ManyToMany
    @JoinTable(
            name = "team_technology",
            joinColumns = @JoinColumn(name = "team_id"),
            inverseJoinColumns = @JoinColumn(name = "technology_id")
    )
    private List<Technology> technologies;

    public int getTeamId() {
        return teamId;
    }

    public Date getEstablishDate() {
        return establishDate;
    }

    public void setEstablishDate(Date establishDate) {
        this.establishDate = establishDate;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public String getTeamNotes() {
        return teamNotes;
    }

    public void setTeamNotes(String teamNotes) {
        this.teamNotes = teamNotes;
    }

    public int getTeamHrId() {
        return teamHrId;
    }

    public void setTeamHrId(int teamHrId) {
        this.teamHrId = teamHrId;
    }

    public List<Project> getProjects() {
        return projects;
    }

    public void setProjects(List<Project> projects) {
        this.projects = projects;
    }

    public String getTeamLeaderName() {
        return teamLeaderName;
    }

    public void setTeamLeaderName(String teamLeaderName) {
        this.teamLeaderName = teamLeaderName;
    }

    public String getTeamMembers() {
        return teamMembers;
    }

    public void setTeamMembers(String teamMembers) {
        this.teamMembers = teamMembers;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public List<Technology> getTechnologies() {
        return technologies;
    }

    public void setTechnologies(List<Technology> technologies) {
        this.technologies = technologies;
    }

    public String getTeamEmail() {
        return teamEmail;
    }

    public void setTeamEmail(String teamEmail) {
        this.teamEmail = teamEmail;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public String getTeamLogo() {
        return teamLogo;
    }

    public void setTeamLogo(String teamLogo) {
        this.teamLogo = teamLogo;
    }

    public String getTeamGallery() {
        return teamGallery;
    }

    public void setTeamGallery(String teamGallery) {
        this.teamGallery = teamGallery;
    }
}
