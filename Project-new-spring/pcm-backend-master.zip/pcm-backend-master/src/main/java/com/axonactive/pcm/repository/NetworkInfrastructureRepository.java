package com.axonactive.pcm.repository;

import com.axonactive.pcm.entity.NetworkInfrastructure;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NetworkInfrastructureRepository extends CrudRepository<NetworkInfrastructure, Integer> {

}
