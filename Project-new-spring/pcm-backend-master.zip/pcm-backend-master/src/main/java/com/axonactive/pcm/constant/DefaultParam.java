package com.axonactive.pcm.constant;


public class DefaultParam {
    public static final long MAX_IMAGE_SIZE = 10485760;
    public static final String DEFAULT_IMAGE = "";
    public static final String DEFAULT_SCREENSHOT = "[]";
    public static final String IMAGE_SEPARATOR = ",";
    public static final int MAX_STRING_FIELD_LENGTH = 200;
    public static final int MAX_TEXT_FIELD_LENGTH = 1000;
    public static final int MAX_TEXT_FIELD_LENGTH_FOR_PROJECT = 2000;
    public static final String SCREENSHOT = "screenshot";
    public static final String GALLERY = "gallery";
    public static final String DEFAULT_CONTACT = "default";
    public static final String DEFAULT_CONTACT_EMAIL = "default@gmail.com";
    public static final String DEFAULT_CONTACT_POSITION = "CEO";


    /**
     * Image target
     */
    public static final String TARGET_CUSTOMER = "customer";
    public static final String TARGET_CONTACT = "contact";
    public static final String TARGET_PROJECT = "project";
    public static final String TARGET_TEAM = "team";


    /**
     * PCM role's name
     */
    public static final String EDIT_TEAM = "Edit Team";
    public static final String EXCEPTION_SM_INTERACT_PROJECT_ONLY = "Exception-SM-Interact-Project-Only";
    public static final String EDIT_MY_TEAM = "Edit My Team";
    public static final String VIEW_CUSTOMER_DETAIL = "View Customer Detail";
    public static final String VIEW_MY_CUSTOMER = "View My Customer";
    public static final String VIEW_CONTACT_DETAIL = "View Contact Detail";
    public static final String VIEW_MY_CONTACT = "View My Contact";
    public static final String VIEW_PROJECT_DETAIL = "View Project Detail";
    public static final String VIEW_MY_PROJECT = "View My Project";
}
