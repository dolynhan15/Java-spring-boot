package com.axonactive.pcm.service.impl;

import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.constant.ErrorMessageConstants;
import com.axonactive.pcm.entity.Project;
import com.axonactive.pcm.entity.Team;
import com.axonactive.pcm.enums.Status;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.model.DTO.TeamDTO;
import com.axonactive.pcm.repository.TeamRepository;
import com.axonactive.pcm.service.TeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Service
public class TeamServiceImpl implements TeamService {

    public static final String COULD_NOT_FIND_ANY_TEAM_WITH_ID = "Could not find any team with id = ";
    @Autowired
    private TeamRepository teamRepository;

    @Override
    public List<Team> readTeamByCustomerId(int customerId) {
        if (customerId <= 0) {
            throw new InvalidParamException(ErrorMessageConstants.NEGATIVE_PATH_VARIABLE, DefaultPath.TEAM_PATH + "/" + customerId);
        }

        List<Team> teams = teamRepository.getTeamsByCustomerId(customerId);

        return teams;
    }

    @Override
    public List<Team> readTeamsByContactId(int contactId) {
        if (contactId <= 0) {
            throw new InvalidParamException(ErrorMessageConstants.NEGATIVE_PATH_VARIABLE, DefaultPath.TEAM_PATH + "/" + contactId);
        }

        List<Team> teams = teamRepository.getTeamsByContactId(contactId);

        return teams;
    }

    @Override
    public List<Team> readTeamsByProjectId(int projectId) {
        if (projectId <= 0) {
            throw new InvalidParamException(ErrorMessageConstants.NEGATIVE_PATH_VARIABLE, DefaultPath.TEAM_PATH + "/" + projectId);
        }

        List<Team> teams = teamRepository.getTeamsByProjectId(projectId);

        return teams;
    }

    @Override
    public List<TeamDTO> readActiveTeamListDTOs() {
        List<TeamDTO> result = new ArrayList<>();
        List<Team> teamList = (List<Team>) teamRepository.findAll();

        if (teamList.size() == 0) {
            throw new PCMEntityNotFoundException(ErrorMessageConstants.TEAM_NOT_FOUND, DefaultPath.TEAM_PATH);
        }
        for (Team team : teamList) {
            TeamDTO teamDTO = new TeamDTO();
            teamDTO.team = team;
            teamDTO.teamStatus = isTeamActive(team);

            List<Project> projects = team.getProjects();

            teamDTO.customers = new ArrayList<>();
            for (Project project : projects) {
                if ((project.getProjectStatus()).equals(Status.ACTIVE) && Objects.nonNull(project.getContact().getCustomer())) {
                    teamDTO.customers.add(project.getContact().getCustomer());
                }
            }

            teamDTO.customers = teamDTO.customers.stream().filter(distinctByKey(c -> c.getCustomerId())).collect(Collectors.toList());
            result.add(teamDTO);
        }
        result.sort(new Comparator<TeamDTO>() {
            @Override
            public int compare(TeamDTO o1, TeamDTO o2) {
                if (o1.teamStatus == Status.ACTIVE) {
                    return -1;
                }
                if (o2.teamStatus == Status.ACTIVE) {
                    return 1;
                }
                return 0;
            }
        });
        return result;
    }

    private static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Map<Object, Boolean> seen = new ConcurrentHashMap<>();
        return t -> seen.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }

    @Override
    public Team readTeamById(int teamId) {
        if (teamId < 0) {
            throw new InvalidParamException(ErrorMessageConstants.NEGATIVE_PATH_VARIABLE, DefaultPath.TEAM_PATH + "/" + teamId);
        }

        Team team = teamRepository.findByTeamId(teamId);

        if (Objects.isNull(team)) {
            throw new PCMEntityNotFoundException(COULD_NOT_FIND_ANY_TEAM_WITH_ID + teamId);
        }

        return team;

    }

    public List<Team> saveAllTeam(List<Team> teams) throws InvalidParamException {
        return (List<Team>) teamRepository.save(teams);
    }

    @Override
    public Team saveTeam(Team team) throws InvalidParamException {
        return teamRepository.save(team);
    }

    @Override
    public List<Team> readTeams() throws PCMEntityNotFoundException {
        List<Team> teamList = (List<Team>) teamRepository.findAll();

        if (teamList.size() == 0) {
            throw new PCMEntityNotFoundException(ErrorMessageConstants.TEAM_NOT_FOUND, DefaultPath.TEAM_PATH);
        }

        return teamList;
    }

    @Override
    public int updateTeam(String branch_name, String department_name, String team_email, int team_hr_id, String team_leader_name, String team_members, String team_name, String team_notes, int team_id) {
        return teamRepository.updateTeam(branch_name, department_name, team_email, team_hr_id, team_leader_name, team_members, team_name, team_notes, team_id);
    }

    @Override
    public int getTeamIdByTeamName(String teamName) {
        Integer id = teamRepository.getTeamIdByTeamName(teamName);
        if (Objects.isNull(id)) {
            throw new PCMEntityNotFoundException(ErrorMessageConstants.TEAM_NOT_FOUND, DefaultPath.TEAM_PATH);
        }
        return id;
    }

    @Override
    public boolean deleteTeam(int team_id) {
        teamRepository.delete(team_id);
        return true;
    }


    private Status isTeamActive(Team team) {
        for (Project project : team.getProjects()) {
            if (project.getProjectStatus().equals(Status.ACTIVE)) {
                return Status.ACTIVE;
            }
        }
        return Status.INACTIVE;
    }
}
