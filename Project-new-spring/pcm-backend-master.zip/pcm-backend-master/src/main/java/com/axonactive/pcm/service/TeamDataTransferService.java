package com.axonactive.pcm.service;

import com.axonactive.pcm.entity.Team;

import java.util.List;

public interface TeamDataTransferService {

    List<Team> teamHRToTeam();
    List<Team> saveAllTeam();
}
