package com.axonactive.pcm.service.impl;

import com.axonactive.pcm.entity.Team;
import com.axonactive.pcm.entity.Technology;
import com.axonactive.pcm.service.TeamTechnologyService;
import com.axonactive.pcm.service.TechnologyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeamTechnologyServiceImpl implements TeamTechnologyService {

    @Autowired
    private TechnologyService technologyService;

    @Override
    public Team saveTeamWithNewTechnology(Team team) {
        List<Technology> technologies = technologyService.saveListTechnologiesNotExist(team.getTechnologies());
        team.setTechnologies(technologies);
        return team;
    }
}
