package com.axonactive.pcm.enums;

public enum Status {ACTIVE, INACTIVE;}
