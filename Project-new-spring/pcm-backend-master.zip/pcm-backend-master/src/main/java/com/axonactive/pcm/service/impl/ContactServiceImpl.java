package com.axonactive.pcm.service.impl;

import com.axonactive.pcm.constant.DefaultParam;
import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.constant.ErrorMessageConstants;
import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.repository.ContactRepository;
import com.axonactive.pcm.service.ContactService;
import com.axonactive.pcm.service.FileService;
import com.axonactive.pcm.utility.PathHepper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.List;

import static java.util.Objects.isNull;

@Service
public class ContactServiceImpl implements ContactService {

    private static final String COULD_NOT_FIND_ANY_CONTACT_IN_DATABASE_WITH_ID = "Could not find any contact in database with id:";
    private static final String CANNOT_FIND_CONTACT_WITH_ID = "Cannot find contact with Id:";
    private static final String CANNOT_UPDATE_WIFI_KEY = "Cannot update wifi key";
    private static final String CONTACT_S_FIRST_NAME_IS_REQUIRED = "Contact's first name is required!";
    private static final String CONTACT_S_FIRST_NAME_IS_TOO_LONG_MAX_LENGTH_IS = "Contact's first name is too long! Max length is:";
    private static final String CONTACT_S_LAST_NAME_IS_REQUIRED = "Contact's last name is required!";
    private static final String CONTACT_S_LAST_NAME_IS_TOO_LONG_MAX_LENGTH_IS = "Contact's last name is too long! Max length is:";
    private static final String CONTACT_S_EMAIL_IS_TOO_LONG_MAX_LENGTH_IS = "Contact's email is too long! Max length is:";
    private static final String CONTACT_S_NOTES_IS_TOO_LONG_MAX_LENGTH_IS = "Contact's notes is too long! Max length is:";
    private static final String CONTACT_S_GENDER_IS_REQUIRED = "Contact's gender is required!";
    private static final String CONTACT_S_POSITION_IS_REQUIRED = "Contact's position is required!";
    private final FileService fileService;
    private final ContactRepository contactRepository;
    private final EntityManager entityManager;
    private final PathHepper pathHepper;

    @Autowired
    public ContactServiceImpl(ContactRepository contactRepository,
                              EntityManager entityManager, FileService fileService, PathHepper pathHepper) {
        this.contactRepository = contactRepository;
        this.entityManager = entityManager;
        this.fileService = fileService;
        this.pathHepper = pathHepper;
    }

    @Override
    public List<Contact> saveContacts(List<Contact> contacts) {
        for (Contact contact : contacts){
            validate(contact);
        }
        return (List<Contact>) contactRepository.save(contacts);
    }

    @Override
    public List<Contact> readUnAssignedContacts() {
        return contactRepository.getUnAssignContacts();
    }

    @Override
    public Contact readContactById(int contactId) {
        if(contactId <= 0){
            throw new InvalidParamException(ErrorMessageConstants.NEGATIVE_PATH_VARIABLE, DefaultPath.CONTACT_PATH + "/" + contactId);
        }

        Contact result = contactRepository.getContactsByContactId(contactId);

        if(result == null){
            throw new PCMEntityNotFoundException(COULD_NOT_FIND_ANY_CONTACT_IN_DATABASE_WITH_ID + contactId, DefaultPath.CONTACT_PATH + "/" + contactId);
        }

        return result;
    }

    @Override
    public List<Contact> readListContacts() {
        List<Contact> result = contactRepository.findAllByContactIsDefaultFalseOrderByCustomerCustomerStartDateDescPositionPositionTitleAscContactLastNameAsc();

        if(result.size() == 0){
            throw new PCMEntityNotFoundException(ErrorMessageConstants.CONTACT_NOT_FOUND, DefaultPath.CONTACT_PATH);
        }

        return result;
    }

    @Override
    public Contact saveContact(Contact contact) {
        validate(contact);
        return contactRepository.save(contact);
    }

    @Override
    public int resetContactsCustomerIdToNullBeforeSave(int customerId, int[] contactsNotBeReset) {
        return contactRepository.resetCustomerId(customerId, contactsNotBeReset);
    }

    @Override
    public List<Contact> resetContacts(List<Contact> contacts) {
        List<Contact> result = new ArrayList<>();
        for(Contact contact : contacts){
            if(!contact.isContactIsDefault()){
                result.add(contact);
            }
        }
        return result;
    }

    @Override
    public List<Contact> findByContactIdIn(List<Integer> contactIds) {
        return contactRepository.findByContactIdIn(contactIds);
    }

    @Override
    public void delete (int contactId) {
        contactRepository.delete(contactId);
    }

    @Override
    public int unSetCustomer(int contact_id) {
        int result = contactRepository.unSetCustomer(contact_id);
        if (result == 0) {
            throw new PCMEntityNotFoundException(CANNOT_FIND_CONTACT_WITH_ID + contact_id);
        } else {
            return result;
        }
    }

    @Override
    public int updateCustomerId(int contact_id, int customer_id, boolean contact_is_representative) {
        int result = contactRepository.updateCustomerId(contact_id, customer_id, contact_is_representative);
        if (result == 0) {
            throw new PCMEntityNotFoundException(CANNOT_FIND_CONTACT_WITH_ID + contact_id);
        } else {
            return result;
        }
    }

    @Override
    public int updateWifiKey(String wifiKey, int contactId) throws InvalidParamException{
        int result = contactRepository.updateWifiKey(wifiKey, contactId);
        if (result == 0) {
            throw new InvalidParamException(CANNOT_UPDATE_WIFI_KEY, DefaultPath.CONTACT_PATH + DefaultPath.WIFIKEY_PATH);
        } else {
            return result;
        }
    }

    @Override
    public void validate(Contact contact) throws InvalidParamException {
        String path = DefaultPath.CONTACT_PATH + (contact.getContactId() != 0 ? "/" + contact.getContactId() : "");
        if(StringUtils.isBlank(contact.getContactFirstName())){
            throw new InvalidParamException(CONTACT_S_FIRST_NAME_IS_REQUIRED, path);
        }

        if (contact.getContactFirstName().length() > DefaultParam.MAX_STRING_FIELD_LENGTH) {
            throw new InvalidParamException(CONTACT_S_FIRST_NAME_IS_TOO_LONG_MAX_LENGTH_IS + DefaultParam.MAX_STRING_FIELD_LENGTH, path);
        }

        if(StringUtils.isBlank(contact.getContactLastName())){
            throw new InvalidParamException(CONTACT_S_LAST_NAME_IS_REQUIRED, path);
        }

        if((contact.getContactLastName() + "").length() > DefaultParam.MAX_STRING_FIELD_LENGTH){
            throw new InvalidParamException(CONTACT_S_LAST_NAME_IS_TOO_LONG_MAX_LENGTH_IS + DefaultParam.MAX_STRING_FIELD_LENGTH, path);
        }

        if(!StringUtils.isBlank(contact.getContactEmail()) &&
                (contact.getContactEmail() + "").length() > DefaultParam.MAX_STRING_FIELD_LENGTH){
            throw new InvalidParamException(CONTACT_S_EMAIL_IS_TOO_LONG_MAX_LENGTH_IS + DefaultParam.MAX_STRING_FIELD_LENGTH, path);
        }

        if((contact.getContactNotes() + "").length() > DefaultParam.MAX_TEXT_FIELD_LENGTH){
            throw new InvalidParamException(CONTACT_S_NOTES_IS_TOO_LONG_MAX_LENGTH_IS + DefaultParam.MAX_TEXT_FIELD_LENGTH, path);
        }

        if(isNull(contact.getContactGender())){
            throw new InvalidParamException(CONTACT_S_GENDER_IS_REQUIRED, path);
        }
        if(isNull(contact.getContactPosition())){
            throw new InvalidParamException(CONTACT_S_POSITION_IS_REQUIRED, path);
        }
    }

    @Override
    public Contact detachAndSetPath(Contact contact) {
        String contactAvatar = contact.getContactAvatar();
        String contactGallery = contact.getContactGallery();
        contact.setContactAvatar(null);
        contact.setContactGallery(null);

        Contact newContact = saveContact(contact);

        newContact.setContactAvatar(fileService.uploadImage(DefaultParam.TARGET_CONTACT, newContact.getContactId() + "", contactAvatar));
        newContact.setContactGallery(fileService.uploadImageList(DefaultParam.TARGET_CONTACT, newContact.getContactId() + "", contactGallery));
        newContact = saveContact(newContact);

        entityManager.detach(newContact);
        newContact.setContactAvatar(pathHepper.handlerImage(contact.getContactAvatar()));
        return contact;
    }

}
