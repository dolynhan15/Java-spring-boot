package com.axonactive.pcm.exceptionhandler;

import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.constant.ErrorMessageConstants;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.exception.ParseJsonProcessingException;
import com.axonactive.pcm.exception.SMNotBelongToTeamException;
import com.axonactive.pcm.model.ErrorEntity.ErrorMessage;
import org.omg.CORBA.portable.UnknownException;
import org.springframework.beans.TypeMismatchException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestController
@ControllerAdvice
public class RestExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(PCMEntityNotFoundException.class)
    protected ResponseEntity<Object> handleEntityNotFound(
            PCMEntityNotFoundException ex) {
        com.axonactive.pcm.model.ErrorEntity.ErrorMessage errorMessage = new com.axonactive.pcm.model.ErrorEntity.ErrorMessage(HttpStatus.NOT_FOUND);
        errorMessage.setMessage(ex.getMessage());
        errorMessage.setPath(ex.getPath());
        errorMessage.setError(ErrorMessageConstants.ENTITY_NOT_FOUND_ERROR);
        logger.error("-- handleEntityNotFound() --" + ex.getMessage());
        return buildResponseEntity(errorMessage);
    }

    @ExceptionHandler(InvalidParamException.class)
    protected ResponseEntity<Object> handleInvalidParam(InvalidParamException ex) {
        com.axonactive.pcm.model.ErrorEntity.ErrorMessage errorMessage = new com.axonactive.pcm.model.ErrorEntity.ErrorMessage(HttpStatus.BAD_REQUEST);
        errorMessage.setMessage(ex.getMessage());
        errorMessage.setError(ErrorMessageConstants.PARAM_INVALID_ERROR);
        errorMessage.setPath(ex.getPath());
        logger.warn("-- handleInvalidParam() --" + ex.getMessage());
        return buildResponseEntity(errorMessage);
    }

    @ExceptionHandler(ParseJsonProcessingException.class)
    protected ResponseEntity<Object> handleJsonProcessing(ParseJsonProcessingException ex) {
        ErrorMessage errorMessage = new ErrorMessage(HttpStatus.BAD_REQUEST);
        errorMessage.setMessage(ex.getMessage());
        errorMessage.setError(ErrorMessageConstants.CANNOT_PARSE_TEAM_HISTORY);
        logger.error("handleJsonProcessing()--" + ex.getMessage());
        return buildResponseEntity(errorMessage);
    }

    @Override
    protected ResponseEntity<Object> handleTypeMismatch(TypeMismatchException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        com.axonactive.pcm.model.ErrorEntity.ErrorMessage errorMessage = new com.axonactive.pcm.model.ErrorEntity.ErrorMessage(HttpStatus.BAD_REQUEST);
        errorMessage.setMessage(ex.getMessage());
        errorMessage.setError(ErrorMessageConstants.PARAM_INVALID_ERROR);
        errorMessage.setPath(request.getUserPrincipal().toString());
        logger.warn("-- handleTypeMismatch() --" + ex.getMessage());
        return buildResponseEntity(errorMessage);
    }

    @ExceptionHandler(UnknownException.class)
    protected ResponseEntity<Object> handleUnknownException(UnknownException ex) {
        com.axonactive.pcm.model.ErrorEntity.ErrorMessage errorMessage = new com.axonactive.pcm.model.ErrorEntity.ErrorMessage(HttpStatus.INTERNAL_SERVER_ERROR);
        errorMessage.setMessage("Unknown Error!");
        logger.error("-- handleUnknownException() --", ex);
        return buildResponseEntity(errorMessage);
    }


    @ExceptionHandler(SMNotBelongToTeamException.class)
    protected ResponseEntity<Object> handleSMNotBelongToTeam(SMNotBelongToTeamException ex) {
        com.axonactive.pcm.model.ErrorEntity.ErrorMessage errorMessage = new com.axonactive.pcm.model.ErrorEntity.ErrorMessage(HttpStatus.FORBIDDEN);
        errorMessage.setMessage(ex.getMessage());
        errorMessage.setPath(DefaultPath.TEAM_PATH);
        errorMessage.setError("Unauthorized");
        logger.warn("-- handleSMNotBelongToTeam() --" + ex.getMessage());
        return buildResponseEntity(errorMessage);
    }

    @ExceptionHandler(Exception.class)
    protected ResponseEntity<Object> handleException(Exception ex) {
        ErrorMessage errorMessage = new ErrorMessage(HttpStatus.INTERNAL_SERVER_ERROR);
        errorMessage.setError(ErrorMessageConstants.SOMETHING_WENT_WRONG);
        errorMessage.setMessage(ex.getMessage());
        logger.warn("--handleException()--", ex);
        return buildResponseEntity(errorMessage);
    }

    private ResponseEntity<Object> buildResponseEntity(com.axonactive.pcm.model.ErrorEntity.ErrorMessage errorMessage) {
        return new ResponseEntity<>(errorMessage, errorMessage.getStatus());
    }
}
