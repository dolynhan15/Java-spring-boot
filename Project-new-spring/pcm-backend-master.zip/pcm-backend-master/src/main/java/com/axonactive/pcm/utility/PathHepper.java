package com.axonactive.pcm.utility;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class PathHepper {

    @Value("${path.server.images}")
    private String pathServerImages;

    @Value("${path.hrtool}")
    private String pathHrTool;

    @Value("${access.key}")
    private String accessKey;

    public String handlerScreenShot(String screenShot) {
        String result = "";
        if (StringUtils.isNotBlank(screenShot)) {
            if (!screenShot.equals("[]")) {
                String arrayScreenShot = screenShot.substring(1, screenShot.length() - 1);
                String[] array = arrayScreenShot.split(",");
                for (int i = 0; i < array.length; i++) {
                    array[i] = pathServerImages + array[i].substring(1, array[i].length() - 1);
                    result += "\"" + array[i] + "\"" + ",";
                }
                result = "[" + result.substring(0, result.length() - 1) + "]";
                return result;
            }
        }
        return screenShot;
    }

    public String handlerImage(String imageString) {
        if (StringUtils.isNotBlank(imageString)) {
            imageString = pathServerImages + imageString;
        }
        return imageString;
    }

    public String removePathServerImage(String imageString) {
        if (StringUtils.isNotBlank(imageString)) {
            return imageString.replace(pathServerImages, "");
        }
        return imageString;
    }

    public String removePathServerScreenShot(String screenShot) {
        if (StringUtils.isNotBlank(screenShot)) {
            screenShot = screenShot.replace(pathServerImages, "");
        }
        return screenShot;
    }

    public String getPathHrTool(String url) {
        return pathHrTool + url;
    }

    public String getAccessKey() {
        return accessKey;
    }
}
