package com.axonactive.pcm.service;

import com.axonactive.pcm.entity.Team;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.model.DTO.TeamDTO;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TeamService {

    List<Team> readTeamByCustomerId (int customerId);

    List<Team> readTeamsByContactId(int contactId);

    List<Team> readTeamsByProjectId(int projectId);

    List<TeamDTO> readActiveTeamListDTOs() throws PCMEntityNotFoundException;

    Team readTeamById(int teamId) throws PCMEntityNotFoundException, InvalidParamException;

    List<Team> saveAllTeam(List<Team> teams) throws InvalidParamException;

    Team saveTeam(Team team) throws InvalidParamException;

    List<Team> readTeams() throws  PCMEntityNotFoundException;

    int updateTeam(String branch_name, String department_name, String team_email,
                  int team_hr_id, String team_leader_name, String team_members,
                   String team_name, String team_notes, int team_id);

    int getTeamIdByTeamName(String teamName);

    boolean deleteTeam(int team_id);

}
