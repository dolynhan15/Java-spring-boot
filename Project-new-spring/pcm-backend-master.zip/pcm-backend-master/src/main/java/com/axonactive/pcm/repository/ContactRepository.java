package com.axonactive.pcm.repository;

import com.axonactive.pcm.entity.Contact;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public interface ContactRepository extends CrudRepository<Contact, Integer> {

    @Query(value = "SELECT c FROM Contact c WHERE c.customer IS NULL AND c.contactIsDefault = false ORDER BY c.contactId DESC")
    List<Contact> getUnAssignContacts();

    Contact getContactsByContactId(int id);

    @Modifying
    @Query(value = "UPDATE Contact c SET c.customer = NULL WHERE c.customer.customerId = :id AND c.contactId NOT IN :noReset")
    int resetCustomerId(@Param("id") int customerId, @Param("noReset") int[] noReset);

    List<Contact> findAllByContactIsDefaultFalseOrderByCustomerCustomerStartDateDescPositionPositionTitleAscContactLastNameAsc();

    @Modifying
    @Query(value = "UPDATE contact SET customer_id = :customer_id, contact_is_representative = :contact_is_representative where contact_id = :contact_id", nativeQuery = true)
    int updateCustomerId(@Param("contact_id") int contact_id, @Param("customer_id") int customer_id, @Param("contact_is_representative") boolean contact_is_representative);

    @Modifying
    @Query(value = "UPDATE Contact c SET c.customer = NULL WHERE c.contactId =:contact_id")
    int unSetCustomer(@Param("contact_id") int contact_id);

    @Modifying
    @Query(value = "UPDATE Contact SET contact_wifi_key = :wifi_key WHERE contact_id =:contact_id", nativeQuery = true)
    int updateWifiKey(@Param("wifi_key") String wifiKey, @Param("contact_id") int contactId);

    List<Contact> findByContactIdIn(List<Integer> contactIds);
}
