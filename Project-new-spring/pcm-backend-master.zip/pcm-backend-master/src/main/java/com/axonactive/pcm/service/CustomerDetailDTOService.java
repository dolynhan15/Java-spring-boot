package com.axonactive.pcm.service;

import com.axonactive.pcm.model.DTO.CustomerDetailDTO;

public interface CustomerDetailDTOService {
    CustomerDetailDTO detachAndSetPath(CustomerDetailDTO customerDetailDTO);
}
