package com.axonactive.pcm.service.impl;

import com.axonactive.pcm.constant.DefaultParam;
import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.entity.Project;
import com.axonactive.pcm.entity.Team;
import com.axonactive.pcm.exception.CustomException;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.model.FileModel.Image;
import com.axonactive.pcm.service.*;
import com.axonactive.pcm.utility.ImageUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import sun.misc.BASE64Decoder;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import static com.axonactive.pcm.constant.ErrorMessageConstants.ENTITY_NOT_FOUND_ERROR;
import static com.axonactive.pcm.constant.ErrorMessageConstants.IMAGE_NOT_EXIST;

@Service
public class FileServiceImpl implements FileService {

    private static final String AVATAR = "avatar";
    private static final String SPLASH = "/";
    @Autowired
    private ProjectService projectService;

    @Autowired
    private ProjectContactService projectContactService;

    @Autowired
    @Lazy
    private ContactService contactService;

    @Autowired
    private CustomerService customerService;

    @Autowired
    private TeamService teamService;

    public String uploadImage(String target, String target_id, String imageString) {
        if (StringUtils.isBlank(imageString)){
            return DefaultParam.DEFAULT_IMAGE;
        }

        ImageUtil imageUtil = new ImageUtil(imageString);

        if (imageUtil.isNoImageFound() || imageUtil.isImageAlreadyExist()) {
            return imageUtil.getImageString();
        }

        Image image = imageUtil.getImage();
        if (Objects.isNull(image)) {
            switch (target) {
                case DefaultParam.TARGET_CUSTOMER:
                    return customerService.readCustomerById(Integer.parseInt(target_id)).getCustomerLogo();
                case DefaultParam.TARGET_CONTACT:
                    return contactService.readContactById(Integer.parseInt(target_id)).getContactAvatar();
                case DefaultParam.TARGET_PROJECT:
                    return projectContactService.readProjectById(Integer.parseInt(target_id)).getProjectCover();
                case DefaultParam.TARGET_TEAM:
                    return teamService.readTeamById(Integer.parseInt(target_id)).getTeamLogo();
            }
        }

        String imageDir;
        String targetImageUrl;

        switch (target) {
            case DefaultParam.TARGET_CUSTOMER:
                imageDir = DefaultPath.CUSTOMER_FOLDER + File.separator + target_id;
                targetImageUrl = DefaultPath.CUSTOMER_FILE_URL + target_id + SPLASH;
                break;
            case DefaultParam.TARGET_CONTACT:
                imageDir = DefaultPath.CONTACT_FOLDER + File.separator + target_id + File.separator + AVATAR;
                targetImageUrl = DefaultPath.CONTACT_FILE_URL + target_id + SPLASH + AVATAR + SPLASH;
                break;
            case DefaultParam.TARGET_PROJECT:
                imageDir = DefaultPath.PROJECT_FOLDER + File.separator + target_id + File.separator + AVATAR;
                targetImageUrl = DefaultPath.PROJECT_FILE_URL + target_id + SPLASH + AVATAR + SPLASH;
                break;
            case DefaultParam.TARGET_TEAM:
                imageDir = DefaultPath.TEAM_FOLDER + File.separator + target_id + File.separator + AVATAR;
                targetImageUrl = DefaultPath.TEAM_FILE_URL + target_id + SPLASH + AVATAR + SPLASH;
                break;
            default:
                imageDir = DefaultPath.COMMON_FOLDER + File.separator + target_id;
                targetImageUrl = DefaultPath.COMMON_FILE_URL + target_id + SPLASH;
        }

        try {
            // Create directory for image if not exist
            if (!ImageUtil.createDirectories(imageDir)) {
                return DefaultParam.DEFAULT_IMAGE; // Can not create directory
            } else {
                ImageUtil.cleanDirectory(imageDir);
            }

            //Decode image
            BASE64Decoder decoder = new BASE64Decoder();
            byte[] imageBytes = decoder.decodeBuffer(image.getBase64String());

            // Save image to directory
            ByteArrayInputStream bis = new ByteArrayInputStream(imageBytes);
            BufferedImage bi = ImageIO.read(bis);
            File outputFile = new File(imageDir + File.separator + image.generateNameByNanoTime());
            ImageIO.write(bi, image.getFormat(), outputFile);
            return targetImageUrl + image.getName();

        } catch (IOException | NullPointerException | UnsupportedOperationException | ArrayIndexOutOfBoundsException iOE) {
            return DefaultParam.DEFAULT_IMAGE;
        }
    }

    public String uploadImageList(String target, String target_id, String images) {
        String[] imageList;
        String imageDir;
        String result = "[";
        String targetImageUrl;

        if (StringUtils.isBlank(target_id)) {
            return DefaultParam.DEFAULT_SCREENSHOT; // Can not create directory
        } else {
            switch (target) {
                case DefaultParam.TARGET_CUSTOMER:
                    imageDir = DefaultPath.CUSTOMER_FOLDER + File.separator + target_id + File.separator + DefaultParam.SCREENSHOT;
                    break;
                case DefaultParam.TARGET_CONTACT:
                    imageDir = DefaultPath.CONTACT_FOLDER + File.separator + target_id + File.separator + DefaultParam.GALLERY;
                    break;
                case DefaultParam.TARGET_PROJECT:
                    imageDir = DefaultPath.PROJECT_FOLDER + File.separator + target_id + File.separator + DefaultParam.SCREENSHOT;
                    break;
                case DefaultParam.TARGET_TEAM:
                    imageDir = DefaultPath.TEAM_FOLDER + File.separator + target_id + File.separator + DefaultParam.GALLERY;
                    break;
                default:
                    imageDir = DefaultPath.COMMON_FOLDER + File.separator + target_id;
            }
            if (!ImageUtil.createDirectories(imageDir)) {
                return DefaultParam.DEFAULT_SCREENSHOT; // Can not create directory
            }
        }

        if (StringUtils.isBlank(images)) {
            return getImagesListFromDatabase(target_id, target);
        } else {
            imageList = images.split("~");
        }

        for (int i = 0; i < imageList.length; i++) {
            ImageUtil imageUtil = new ImageUtil(imageList[i]);

            Image image = imageUtil.getImage();
            if (Objects.isNull(image)) {
                continue;
            }

            try {
                //Decode image
                BASE64Decoder decoder = new BASE64Decoder();
                byte[] imageBytes = decoder.decodeBuffer(image.getBase64String());

                // Save image to directory
                ByteArrayInputStream bis = new ByteArrayInputStream(imageBytes);
                BufferedImage bi = ImageIO.read(bis);
                File outputFile = new File(imageDir + File.separator + image.generateNameByNanoTime());
                ImageIO.write(bi, image.getFormat(), outputFile);
                switch (target) {
                    case DefaultParam.TARGET_CUSTOMER:
                        targetImageUrl = DefaultPath.CUSTOMER_FILE_URL + target_id + SPLASH + DefaultParam.SCREENSHOT + SPLASH;
                        break;
                    case DefaultParam.TARGET_CONTACT:
                        targetImageUrl = DefaultPath.CONTACT_FILE_URL + target_id + SPLASH + DefaultParam.GALLERY + SPLASH;
                        break;
                    case DefaultParam.TARGET_PROJECT:
                        targetImageUrl = DefaultPath.PROJECT_FILE_URL + target_id + SPLASH + DefaultParam.SCREENSHOT + SPLASH;
                        break;
                    case DefaultParam.TARGET_TEAM:
                        targetImageUrl = DefaultPath.TEAM_FILE_URL + target_id + SPLASH + DefaultParam.GALLERY + SPLASH;
                        break;
                    default:
                        targetImageUrl = DefaultPath.COMMON_FILE_URL + target_id + SPLASH;
                }
                targetImageUrl += image.getName();

                result += "\"" + targetImageUrl + "\",";
            } catch (IOException | NullPointerException | UnsupportedOperationException | ArrayIndexOutOfBoundsException iOE) {
                return DefaultParam.DEFAULT_SCREENSHOT;
            }
        }
        result = addNewImageInFolder(result, getImagesListFromDatabase(target_id, target));
        if (result.charAt(result.length()-1) == ',') {
            result = result.substring(0, result.length() - 1);
        }
        result += "]";
        return result;
    }

    private String getImagesListFromDatabase(String target_id, String target) {
        switch (target) {
            case DefaultParam.TARGET_CONTACT:
                return contactService.readContactById(Integer.parseInt(target_id)).getContactGallery();
            case DefaultParam.TARGET_PROJECT:
                return projectContactService.readProjectById(Integer.parseInt(target_id)).getProjectScreenshot();
            case DefaultParam.TARGET_TEAM:
                return teamService.readTeamById(Integer.parseInt(target_id)).getTeamGallery();
            default:
                return DefaultParam.DEFAULT_SCREENSHOT;
        }
    }

    private String addNewImageInFolder(String newImages, String oldImages) {
        if(StringUtils.isNotBlank(oldImages) && !oldImages.equals("[]")){
            String[] oldHandleGallerys = oldImages.substring(1, oldImages.length()-1).split(",");
            for(int t = 0; t < oldHandleGallerys.length; t++) {
                oldHandleGallerys[t] = oldHandleGallerys[t].substring(1, oldHandleGallerys[t].length()-1);
                newImages +=  "\"" + oldHandleGallerys[t] + "\",";
            }
        }
        return newImages;
    }

    @Override
    public boolean deleteImage(String imagePath, String pageType, int id) {
        List<String> images;
        boolean result = false;
        switch (pageType) {
            case DefaultParam.TARGET_CONTACT:
                result = new File(DefaultPath.PCM_FOLDER + imagePath).delete();
                if (result) {
                    Contact contact = contactService.readContactById(id);

                    if (Objects.isNull(contact)) {
                        throw new PCMEntityNotFoundException(ENTITY_NOT_FOUND_ERROR);
                    }

                    images = new ArrayList<>(jsonImageToStringArray(contact.getContactGallery()));

                    images.remove(imagePath);

                    String jsonImages = "[]";
                    if (images.size() != 0) {
                        jsonImages = "[\"" + String.join("\",\"", images) + "\"]";
                    }

                    contact.setContactGallery(jsonImages);
                    contactService.saveContact(contact);
                } else {
                    throw new CustomException(IMAGE_NOT_EXIST, HttpStatus.NOT_FOUND);
                }
                break;
            case DefaultParam.TARGET_PROJECT:
                result = new File(DefaultPath.PCM_FOLDER + imagePath).delete();
                if (result) {
                    Project project = projectContactService.readProjectById(id);

                    if (Objects.isNull(project)) {
                        throw new PCMEntityNotFoundException(ENTITY_NOT_FOUND_ERROR);
                    }

                    images = new ArrayList<>(jsonImageToStringArray(project.getProjectScreenshot()));

                    images.remove(imagePath);

                    String jsonImages = "[]";
                    if (images.size() != 0) {
                        jsonImages = "[\"" + String.join("\",\"", images) + "\"]";
                    }

                    project.setProjectScreenshot(jsonImages);
                    projectService.saveProject(project);
                } else {
                    throw new CustomException(IMAGE_NOT_EXIST, HttpStatus.NOT_FOUND);
                }
                break;
            case DefaultParam.TARGET_TEAM:
                result = new File(DefaultPath.PCM_FOLDER + imagePath).delete();
                if (result) {
                    Team team = teamService.readTeamById(id);

                    if (Objects.isNull(team)) {
                        throw new PCMEntityNotFoundException(ENTITY_NOT_FOUND_ERROR);
                    }

                    images = new ArrayList<>(jsonImageToStringArray(team.getTeamGallery()));

                    images.remove(imagePath);

                    String jsonImages = "[]";
                    if (images.size() != 0) {
                        jsonImages = "[\"" + String.join("\",\"", images) + "\"]";
                    }

                    team.setTeamGallery(jsonImages);
                    teamService.saveTeam(team);
                } else {
                    throw new CustomException(IMAGE_NOT_EXIST, HttpStatus.NOT_FOUND);
                }
                break;
            default:
        }
        return result;
    }

    private List<String> jsonImageToStringArray(String json){
        json = json.replace("[", "");
        json = json.replace("]", "");
        json = json.replace("\"", "");
        return Arrays.asList(json.split(","));
    }
}
