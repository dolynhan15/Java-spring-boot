package com.axonactive.pcm.repository;

import com.axonactive.pcm.entity.Customer;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CustomerRepository extends CrudRepository<Customer, Integer> {

    Customer findByCustomerId(int customerId);

    List<Customer> findAllByOrderByCustomerIdDesc();

}
