package com.axonactive.pcm.utility;

import com.axonactive.pcm.constant.DefaultParam;
import com.axonactive.pcm.constant.ErrorMessageConstants;
import com.axonactive.pcm.entity.Project;
import com.axonactive.pcm.entity.Team;
import com.axonactive.pcm.exception.SMNotBelongToTeamException;
import com.axonactive.pcm.model.DTO.JwtUserDTO;
import com.axonactive.pcm.model.authentication.AuthenticatedUser;
import com.axonactive.pcm.service.TeamService;
import io.jsonwebtoken.*;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwt.consumer.JwtConsumer;
import org.jose4j.jwt.consumer.JwtConsumerBuilder;
import org.jose4j.keys.RsaKeyUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.PublicKey;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Class validates a given token by using the secret configured in the application
 *
 */
@Component
public class JwtTokenValidator {


    @Autowired
    private ResourceLoader resourceLoader;

    @Autowired
    private TeamService teamService;

    @Value("${jwt.client}")
    private String client;

    /**
     * Tries to parse specified String as a JWT token. If successful, returns User object with username, id and role prefilled (extracted from token).
     * If unsuccessful (token is invalid or not containing all required user properties), simply returns null.
     *
     * @param token the JWT token to parse
     * @return the User object extracted from specified token or null if a token is invalid.
     */
    public JwtUserDTO parseToken(String token) {
        JwtUserDTO u = null;

        try {

            Resource resource = resourceLoader.getResource("classpath:static/publickey.txt");
            String publicKeyPEM = readFromInputStream(resource.getInputStream());


            RsaKeyUtil rsaKeyUtil = new RsaKeyUtil();
            PublicKey publicKey = rsaKeyUtil.fromPemEncoded(publicKeyPEM);

            // validate and decode the jwt
            JwtConsumer jwtConsumer = new JwtConsumerBuilder()
                    .setRequireExpirationTime()
                    .setVerificationKey(publicKey)
                    .setSkipDefaultAudienceValidation()
                    .build();


            JwtClaims jwtDecoded = jwtConsumer.processToClaims(token);

            String username = jwtDecoded.getStringClaimValue("preferred_username"); // "MChambe4"
            Map<String,Object> resource_access = jwtDecoded.getClaimValue("resource_access", Map.class);


            Object myClient = resource_access.get(client);

            HashMap<String,List<String>> clientMap = (HashMap<String, List<String>>)myClient;
            List<String> roles = clientMap.get("roles");

            String teamName = "";
            try{
                String entry = jwtDecoded.getStringClaimValue("entry");
                teamName = entry.split(",")[1].split("=")[1];
                if(teamName.contains(" Team")) {
                    teamName = teamName.substring(0, teamName.length() - " Team".length());
                } else {
                    teamName = "";
                }

            } catch (NullPointerException e){
//                e.printStackTrace();
            }

            u = new JwtUserDTO();
            u.setUsername(username);
            u.setId(1L);
            u.setRoles(roles);
            u.setTeamName(teamName);

        } catch (JwtException e) {
//            e.printStackTrace();
        } catch (Exception ee){
//            ee.printStackTrace();
        }
        return u;
    }

    private String readFromInputStream(InputStream inputStream) {
        StringBuilder resultStringBuilder = new StringBuilder();
        try (BufferedReader br
                     = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            while ((line = br.readLine()) != null) {
                resultStringBuilder.append(line).append("\n");
            }
        }
        catch (IOException e){
            return "";
        }
        return resultStringBuilder.toString();
    }

    public void isTeamOwner(Authentication authentication, String teamName){
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        if (currentUser.getAuthorities().contains(new SimpleGrantedAuthority(DefaultParam.EDIT_TEAM))) {
            return;
        }
        if (currentUser.getAuthorities().contains(new SimpleGrantedAuthority(DefaultParam.EXCEPTION_SM_INTERACT_PROJECT_ONLY))
                && (currentUser.getTeamName().equals(teamName))) {
            return;
        }
        if (currentUser.getAuthorities().contains(new SimpleGrantedAuthority(DefaultParam.EDIT_MY_TEAM))
                && currentUser.getTeamName().equals(teamName)) {
            return;
        }

        throw new SMNotBelongToTeamException(ErrorMessageConstants.YOU_DO_NOT_HAVE_RIGHT_TO_THIS_TEAM);
    }

    public void isMyCustomer(AuthenticatedUser authUser, int customerId) {
        if (authUser.getAuthorities().contains(new SimpleGrantedAuthority(DefaultParam.VIEW_CUSTOMER_DETAIL))) {
            return;
        }

        if (authUser.getAuthorities().contains(new SimpleGrantedAuthority(DefaultParam.VIEW_MY_CUSTOMER))
                && checkAuthUserHasAnyMatchTeamName(teamService.readTeamByCustomerId(customerId), authUser.getTeamName())) {
            return;
        }
        throw new SMNotBelongToTeamException(ErrorMessageConstants.YOU_DO_NOT_HAVE_RIGHT_TO_THIS_CUSTOMER);
    }


    public void isMyContact(AuthenticatedUser authUser, int contactId){
        if (authUser.getAuthorities().contains(new SimpleGrantedAuthority(DefaultParam.VIEW_CONTACT_DETAIL))) {
            return;
        }
        if (authUser.getAuthorities().contains(new SimpleGrantedAuthority(DefaultParam.VIEW_MY_CONTACT))
                && checkAuthUserHasAnyMatchTeamName(teamService.readTeamsByContactId(contactId), authUser.getTeamName())) {
            return;
        }
        throw new SMNotBelongToTeamException(ErrorMessageConstants.YOU_DO_NOT_HAVE_RIGHT_TO_THIS_CONTACT);
    }

    public void isMyProject(AuthenticatedUser authUser, int projectId){
        if (authUser.getAuthorities().contains(new SimpleGrantedAuthority(DefaultParam.VIEW_PROJECT_DETAIL))) {
            return;
        }
        if (checkRoleScrumMasterException(authUser, projectId)) return;

        if (checkRoleViewMyProject(authUser, projectId)) return;

        throw new SMNotBelongToTeamException(ErrorMessageConstants.YOU_DO_NOT_HAVE_RIGHT_TO_THIS_PROJECTS);
    }

    private boolean checkRoleViewMyProject(AuthenticatedUser authUser, int projectId) {
        if (authUser.getAuthorities().contains(new SimpleGrantedAuthority(DefaultParam.VIEW_MY_PROJECT))) {
            List<Team> teams = teamService.readTeamsByProjectId(projectId);
            return checkAuthUserHasAnyMatchTeamName(teams, authUser.getTeamName());
        }
        return false;
    }

    private boolean checkRoleScrumMasterException(AuthenticatedUser authUser, int projectId) {
        if (authUser.getAuthorities().contains(new SimpleGrantedAuthority(DefaultParam.EXCEPTION_SM_INTERACT_PROJECT_ONLY))) {
            List<Team> teamsByProject = teamService.readTeamsByProjectId(projectId);
            if (Objects.isNull(teamsByProject) || teamsByProject.size() == 0) {
                return true;
            }
            if (teamsByProject.stream().anyMatch(t -> t.getTeamName().contains(authUser.getTeamName()))) {
                return true;
            }
            throw new SMNotBelongToTeamException(ErrorMessageConstants.YOU_DO_NOT_HAVE_RIGHT_TO_THIS_PROJECTS);
        }
        return false;
    }

    private boolean checkAuthUserHasAnyMatchTeamName(List<Team> teams, String authUserTeamName) {
        return teams.stream().anyMatch(t -> t.getTeamName().contains(authUserTeamName));
    }

}
