package com.axonactive.pcm.enums;

public enum Gender {
    MALE, FEMALE, OTHER;
}
