package com.axonactive.pcm.service.impl;

import com.axonactive.pcm.constant.DefaultParam;
import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.constant.ErrorMessageConstants;
import com.axonactive.pcm.entity.Project;
import com.axonactive.pcm.enums.Status;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.repository.ProjectRepository;
import com.axonactive.pcm.service.ProjectService;
import com.axonactive.pcm.utility.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class ProjectServiceImpl implements ProjectService {

    public static final String COULD_NOT_FIND_ANY_PROJECT_IN_DATABASE_WITH_ID = "Could not find any project in database with id = ";
    public static final String PROJECT_S_NAME_IS_REQUIRED = "Project's name is required!";
    public static final String CUSTOMER_OBJECT_IS_REQUIRED = "Customer object is required!";
    public static final String PROJECT_S_NAME_IS_TOO_LONG_MAX_LENGTH_IS = "Project's name is too long! Max length is ";
    public static final String PROJECT_S_DESCRIPTION_IS_TOO_LONG_MAX_LENGTH_IS = "Project's description is too long! Max length is ";
    public static final String PROJECT_S_NOTES_IS_TOO_LONG_MAX_LENGTH_IS = "Project's notes is too long! Max length is ";
    public static final String INACTIVE_PROJECT_MUST_PROVIDE_END_DATE = "Inactive project must provide end date!";
    public static final String START_DATE_MUST_BE_BEFORE_END_DATE = "Start date must be before end date!";
    public static final String CAN_NOT_FIND_PROJECT_WITH_ID = "Can not find project with ID = ";

    @Autowired
    private ProjectRepository projectRepository;

    @Override
    public List<Project> readProjectsByContactId(int contact_id) {
       return projectRepository.findProjectByContactId(contact_id);
    }

    @Override
    public List<Project> findAllByOrderByProjectIdDesc() {
        List<Project> projects = projectRepository.findAllByOrderByProjectIdDesc();
        if (projects.isEmpty()) {
            throw new PCMEntityNotFoundException(ErrorMessageConstants.PROJECT_NOT_FOUND, DefaultPath.PROJECT_PATH);
        }
        return projects;
    }

    @Override
    public Project findByProjectId(int projectId) {

        Project project = projectRepository.findByProjectId(projectId);

        if (Objects.isNull(project)) {
            throw new PCMEntityNotFoundException(COULD_NOT_FIND_ANY_PROJECT_IN_DATABASE_WITH_ID + projectId, DefaultPath.PROJECT_PATH + "/" + projectId);
        }

        return project;
    }

    @Override
    public Project saveProject(Project project) throws InvalidParamException {
        validate(project);
        project.setTeamsHistory();
        project.setListPOs();
        return projectRepository.save(project);
    }

    @Override
    public void validate(Project project) throws InvalidParamException {
        String path = DefaultPath.PROJECT_PATH + (project.getProjectId() != 0 ? "/" + project.getProjectId() : "");
        if (StringUtils.isBlank(project.getProjectName())) {
            throw new InvalidParamException(PROJECT_S_NAME_IS_REQUIRED, path);
        }
        if (Objects.isNull(project.getContact().getCustomer())) {
            throw new InvalidParamException(CUSTOMER_OBJECT_IS_REQUIRED, path);
        }
        if ((project.getProjectName() + "").length() > DefaultParam.MAX_STRING_FIELD_LENGTH) {
            throw new InvalidParamException(PROJECT_S_NAME_IS_TOO_LONG_MAX_LENGTH_IS + DefaultParam.MAX_STRING_FIELD_LENGTH, path);
        }
        if ((project.getProjectDescription() + "").length() > DefaultParam.MAX_TEXT_FIELD_LENGTH_FOR_PROJECT) {
            throw new InvalidParamException(PROJECT_S_DESCRIPTION_IS_TOO_LONG_MAX_LENGTH_IS + DefaultParam.MAX_TEXT_FIELD_LENGTH_FOR_PROJECT, path);
        }
        if ((project.getProjectNotes() + "").length() > DefaultParam.MAX_TEXT_FIELD_LENGTH_FOR_PROJECT) {
            throw new InvalidParamException(PROJECT_S_NOTES_IS_TOO_LONG_MAX_LENGTH_IS + DefaultParam.MAX_TEXT_FIELD_LENGTH_FOR_PROJECT, path);
        }
        if (project.getProjectStatus() == Status.INACTIVE && Objects.isNull(project.getProjectEndDate())) {
            throw new InvalidParamException(INACTIVE_PROJECT_MUST_PROVIDE_END_DATE, path);
        }
        if (!Objects.isNull(project.getProjectStartDate()) && !Objects.isNull(project.getProjectEndDate()) && !DateUtil.compareDate(project.getProjectStartDate(), project.getProjectEndDate())) {
            throw new InvalidParamException(START_DATE_MUST_BE_BEFORE_END_DATE, path);
        }
    }

    @Override
    public int updateContactId(int contact_id, int project_id) {
        int result = projectRepository.updateContactId(contact_id, project_id);
        if (result == 0) {
            throw new PCMEntityNotFoundException(CAN_NOT_FIND_PROJECT_WITH_ID + project_id);
        } else {
            return result;
        }
    }

    @Override
    public List<String> findProjectNameByContactId(int contactId) {
        return projectRepository.findProjectNameByContactId(contactId);
    }

    @Override
    public List<Project> findByListPOsNotNull() {
        return projectRepository.findByListPOsNotNull();
    }

    @Override
    public List<Project> findByTeamNameAndNotHasTeam(String teamName) {
        List<Project> projects = projectRepository.findByTeamNameAndNotHasTeam(teamName);
        if (projects.isEmpty()) {
            throw new PCMEntityNotFoundException(ErrorMessageConstants.PROJECT_NOT_FOUND, DefaultPath.PROJECT_PATH);
        }

        return projects;
    }

    @Override
    public List<Project> findAllByTeamName(String teamName) {
        List<Project> projects = projectRepository.findAllByTeamName(teamName);
        if (projects.isEmpty()) {
            throw new PCMEntityNotFoundException(ErrorMessageConstants.PROJECT_NOT_FOUND, DefaultPath.PROJECT_PATH);
        }

        return projects;
    }

    @Override
    public int updateNetworkInfrastructureId(int networkInfrastructureId, int projectId) {
        int result = projectRepository.updateNetworkInfrastructureId(networkInfrastructureId, projectId);
        if (result == 0) {
            throw new PCMEntityNotFoundException(CAN_NOT_FIND_PROJECT_WITH_ID + projectId);
        }

        return result;
    }

}
