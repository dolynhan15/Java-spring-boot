package com.axonactive.pcm.constant;

import java.io.File;

public class DefaultPath {
    /**
     * for API HR tool
     */
    public static final String GET_ALL_BRANCHES = "/listBranches?";
    public static final String GET_ALL_DEPARTMENT_BY_BRANCHID = "/listDepartments?branchIndex=";
    public static final String GET_TEAM_BY_DEPARTMENTID = "/listTeamsAndMembers?deptIndex=";


    /**
     * for All path need path variables
     */
    public static final String ID_VARIABLE = "{id}";
    public static final String PROJECT_ID_VARIABLE = "{projectId}";
    public static final String TEAM_NAME_VARIABLE = "{teamName}";


    /**
     * for All path need request parameter
     */
    public static final String PARAMETER_WIFIKEY = "wifikey";
    public static final String PARAMETER_CONTACT_ID = "contactId";
    public static final String PARAMETER_PATH = "path";
    public static final String PARAMETER_PAGETYPE = "pageType";


    /**
     * for ContactController
     */
    public static final String CONTACT_PATH = "api/contacts";
    public static final String UNASSIGNED_PATH = "/unassigned";
    public static final String WIFIKEY_PATH = "/wifikey";


    /**
     * for CustomerController
     */
    public static final String CUSTOMER_PATH = "api/customers";
    public static final String ALL_CUSTOMER_PATH = "/all";


    /**
     * for FileController
     */
    public static final String FILE_PATH = "api/files";


    /**
     * for NetworkInfrastructureController
     */
    public static final String NETWORKINFRASTRUCTURE_PATH = "api/networkinfrastructures";


    /**
     * for PositionController
     */
    public static final String POSITION_PATH = "api/positions";


    /**
     * for ProjectController
     */
    public static final String PROJECT_PATH = "api/projects";
    public static final String GET_BY_TEAM_NAME_PATH = "/getByTeamName/" + TEAM_NAME_VARIABLE;


    /**
     * for TeamController
     */
    public static final String TEAM_PATH = "api/teams";
    public static final String ALL_TEAM_PATH = "/all";
    public static final String GET_ID_BY_NAME_PATH = "/getIdByName/" + TEAM_NAME_VARIABLE;


    /**
     * for TechnologyController
     */
    public static final String TECHNOLOGY_PATH = "api/technologies";


    /**
     * for VisitHistoryController
     */
    public static final String VISITHISTORY_PATH = "api/visithistories";


    /**
     * for Image
     */
    public static final String IMAGES = "images";
    public static final String CUSTOMER_FILE_URL = IMAGES + "/customers/";
    public static final String CONTACT_FILE_URL = IMAGES + "/contacts/";
    public static final String PROJECT_FILE_URL = IMAGES + "/projects/";
    public static final String TEAM_FILE_URL = IMAGES + "/teams/";
    public static final String COMMON_FILE_URL = IMAGES + "/common/";


    /**
     * for creating directory
     */
    private static final String baseDirectory = System.getProperty("user.home");
    private static final String PCM = "pcm";
    public static final String PCM_FOLDER = baseDirectory + File.separator + PCM + File.separator;
    private static final String ROOT_IMAGES_FOLDER =  PCM_FOLDER + IMAGES;
    public static final String CUSTOMER_FOLDER = ROOT_IMAGES_FOLDER + File.separator + "customers";
    public static final String CONTACT_FOLDER = ROOT_IMAGES_FOLDER + File.separator + "contacts";
    public static final String PROJECT_FOLDER = ROOT_IMAGES_FOLDER + File.separator + "projects";
    public static final String TEAM_FOLDER = ROOT_IMAGES_FOLDER + File.separator + "teams";
    public static final String COMMON_FOLDER = ROOT_IMAGES_FOLDER + File.separator + "common";


    /**
     * for Swagger
     */
    public static final String SWAGGER_REQUEST = "/swagger/documentation.html";
}
