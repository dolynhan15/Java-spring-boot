package com.axonactive.pcm.service;

import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.entity.Customer;

import java.util.List;

public interface CustomerContactService {
    Customer saveContactsWithCustomer(Customer customer, List<Contact> contacts);

    Customer editContactCustomer(Customer oldCustomer, Customer newCustomer);
}
