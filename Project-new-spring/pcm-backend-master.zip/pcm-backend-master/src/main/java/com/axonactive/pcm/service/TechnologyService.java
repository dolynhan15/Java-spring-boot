package com.axonactive.pcm.service;

import com.axonactive.pcm.entity.Technology;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;

import java.util.List;

public interface TechnologyService {
    Technology saveTechnology(Technology technology);
    List<Technology> getTechnologies() throws PCMEntityNotFoundException;
    Technology getTechnologyByName(String technologyName);

    List<Technology> saveListTechnologiesNotExist(List<Technology> technologies);
}
