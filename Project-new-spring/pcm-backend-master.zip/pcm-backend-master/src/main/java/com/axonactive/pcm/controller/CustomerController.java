package com.axonactive.pcm.controller;

import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.entity.Customer;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.model.DTO.CustomerDetailDTO;
import com.axonactive.pcm.model.authentication.AuthenticatedUser;
import com.axonactive.pcm.service.*;
import com.axonactive.pcm.utility.JwtTokenValidator;
import com.axonactive.pcm.utility.PathHepper;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

import static com.axonactive.pcm.constant.EntityConstants.*;

@RestController
@RequestMapping(DefaultPath.CUSTOMER_PATH)
@CrossOrigin
public class CustomerController {

    private static final Logger logger = LogManager.getLogger(CustomerController.class);

    private final CustomerService customerService;

    private final FileService fileService;

    private final CustomerContactService customerContactService;

    private final ContactService contactService;

    private final CustomerDetailDTOService customerDetailDTOService;

    private final JwtTokenValidator jwtTokenValidator;

    private final PathHepper pathHepper;

    @Autowired
    public CustomerController(CustomerService customerService,
                              FileService fileService,
                              CustomerContactService customerContactService,
                              ContactService contactService,
                              CustomerDetailDTOService customerDetailDTOService,
                              JwtTokenValidator jwtTokenValidator,
                              PathHepper pathHepper) {
        this.customerService = customerService;
        this.fileService = fileService;
        this.customerContactService = customerContactService;
        this.contactService = contactService;
        this.customerDetailDTOService = customerDetailDTOService;
        this.jwtTokenValidator = jwtTokenValidator;
        this.pathHepper = pathHepper;
    }

    @GetMapping()
    @PreAuthorize("hasAnyAuthority('View Customer List', 'New Contact', 'Edit Contact')")
    public ResponseEntity getCustomers(Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/customers/ - getCustomers -- user: {}", currentUser.getUsername());

        List<Customer> customers = customerService.readCustomers();
        for (Customer customer : customers) {
            customer.setCustomerLogo(pathHepper.handlerImage(customer.getCustomerLogo()));
        }

        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(customers);
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_CUSTOMER, SimpleBeanPropertyFilter.serializeAll())
                .addFilter(FILTER_CONTACT, SimpleBeanPropertyFilter.filterOutAllExcept(
                        CONTACT_ID,
                        CONTACT_FIRST_NAME,
                        CONTACT_LAST_NAME
                ));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @GetMapping(DefaultPath.ALL_CUSTOMER_PATH)
    @PreAuthorize("hasAnyAuthority('New Project', 'Edit Project', 'Exception-SM-Interact-Project-Only')")
    public ResponseEntity getCustomersWithAllContact(Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/customers/all - getCustomersWithAllContact -- user: {}", currentUser.getUsername());

        List<Customer> customers = customerService.readCustomersAllContact();
        for(Customer customer : customers){
            customer.setContacts(contactService.resetContacts(customer.getContacts()));
        }
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(customers);
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter("filter.Customer", SimpleBeanPropertyFilter.serializeAll())
                .addFilter("filter.Contact", SimpleBeanPropertyFilter.filterOutAllExcept("contactId", "contactFirstName", "contactLastName"));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @GetMapping(DefaultPath.ID_VARIABLE)
    @PreAuthorize("hasAnyAuthority('View Customer Detail', 'Edit Customer', 'View My Customer')")
    public ResponseEntity getCustomerDetail(@PathVariable Integer id, Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/customers/{} - getCustomerDetail -- user: {}", id, currentUser.getUsername());

        CustomerDetailDTO result = new CustomerDetailDTO();
        jwtTokenValidator.isMyCustomer(currentUser, id);
        result.customer = customerService.readCustomerById(id);
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(customerDetailDTOService.detachAndSetPath(result));
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_CUSTOMER, SimpleBeanPropertyFilter.serializeAll())
                .addFilter(FILTER_CONTACT, SimpleBeanPropertyFilter.serializeAllExcept(CUSTOMER, PROJECTS, VISIT_HISTORIES))
                .addFilter(FILTER_POSITION, SimpleBeanPropertyFilter.serializeAllExcept(CONTACTS))
                .addFilter(FILTER_PROJECT, SimpleBeanPropertyFilter.filterOutAllExcept())
                .addFilter(FILTER_TEAM, SimpleBeanPropertyFilter.serializeAllExcept(PROJECTS, TECHNOLOGIES));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @PostMapping()
    @PreAuthorize("hasAnyAuthority('New Customer')")
    public ResponseEntity createCustomer(@RequestBody Customer customer, Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/customers/ - {} - createCustomer -- user: {}", customer.getCustomerName()+"", currentUser.getUsername());

        List<Contact> newContacts = new ArrayList<>(customer.getContacts());
        String customerLogo = customer.getCustomerLogo() + "";
        customer.setCustomerLogo(null);
        Customer newCustomer = customerService.saveCustomer(customer);
        //Save logo
        newCustomer.setCustomerLogo(fileService.uploadImage("customer", newCustomer.getCustomerId() + "", customerLogo));
        //Update logo
        newCustomer = customerService.saveCustomer(newCustomer);
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(customerContactService.saveContactsWithCustomer(newCustomer,newContacts));
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_CUSTOMER, SimpleBeanPropertyFilter.serializeAll())
                .addFilter(FILTER_CONTACT, SimpleBeanPropertyFilter.serializeAllExcept(CUSTOMER, PROJECTS, VISIT_HISTORIES))
                .addFilter(FILTER_POSITION, SimpleBeanPropertyFilter.serializeAllExcept(CONTACTS))
                .addFilter(FILTER_PROJECT, SimpleBeanPropertyFilter.filterOutAllExcept())
                .addFilter(FILTER_TEAM, SimpleBeanPropertyFilter.serializeAllExcept(PROJECTS));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CREATED);
    }

    @PutMapping()
    @PreAuthorize("hasAnyAuthority('Edit Customer')")
    public ResponseEntity updateCustomer(@RequestBody Customer customer, Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/customers/ - {} - updateCustomer -- user: {}", customer.getCustomerId()+"", currentUser.getUsername());

        if(customer.getCustomerId() == 0) {
            throw new InvalidParamException("Could not find id in body", DefaultPath.CUSTOMER_PATH);
        }
        Customer oldCustomer = customerService.readCustomerById(customer.getCustomerId());
        customer = customerContactService.editContactCustomer(oldCustomer, customer);
        customer.setCustomerLogo(fileService.uploadImage(CUSTOMER, customer.getCustomerId() + "",
                pathHepper.removePathServerImage(customer.getCustomerLogo())));
        customer = customerService.saveCustomer(customer);
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(customer);
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_CUSTOMER, SimpleBeanPropertyFilter.serializeAll())
                .addFilter(FILTER_CONTACT, SimpleBeanPropertyFilter.serializeAllExcept(CUSTOMER, PROJECTS, VISIT_HISTORIES))
                .addFilter(FILTER_POSITION, SimpleBeanPropertyFilter.serializeAllExcept(CONTACTS))
                .addFilter(FILTER_PROJECT, SimpleBeanPropertyFilter.filterOutAllExcept())
                .addFilter(FILTER_TEAM, SimpleBeanPropertyFilter.serializeAllExcept(PROJECTS));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CREATED);
    }

}
