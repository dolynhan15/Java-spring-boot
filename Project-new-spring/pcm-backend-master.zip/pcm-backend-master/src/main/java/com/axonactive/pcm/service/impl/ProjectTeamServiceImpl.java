package com.axonactive.pcm.service.impl;

import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.entity.Project;
import com.axonactive.pcm.service.ContactService;
import com.axonactive.pcm.service.ProjectService;
import com.axonactive.pcm.service.ProjectTeamService;
import com.axonactive.pcm.service.TeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjectTeamServiceImpl implements ProjectTeamService{

    private ProjectService projectService;

    private TeamService teamService;

    private ContactService contactService;

    @Autowired
    public ProjectTeamServiceImpl(ProjectService projectService, TeamService teamService, ContactService contactService) {
        this.projectService = projectService;
        this.teamService = teamService;
        this.contactService = contactService;
    }

    @Override
    public List<Project> readProjectsByTeamName(String teamName) {
        teamService.getTeamIdByTeamName(teamName);

        List<Project> projects = projectService.findAllByTeamName(teamName);

        projects.stream().forEach(project -> {
            if(!project.getListContactId().isEmpty()) {
                List<Contact> contacts = contactService.findByContactIdIn(project.getListContactId());
                project.setListContactPOs(contacts);
            }
        });
        return projects;
    }

    @Override
    public List<Project> readProjectsByTeamAndNotHasTeam(String teamName) {
        teamService.getTeamIdByTeamName(teamName);

        List<Project> projects = projectService.findByTeamNameAndNotHasTeam(teamName);
        projects.stream().forEach(project -> {
            if(!project.getListContactId().isEmpty()) {
                List<Contact> contacts = contactService.findByContactIdIn(project.getListContactId());
                project.setListContactPOs(contacts);
            }
        });
        return projects;
    }
}
