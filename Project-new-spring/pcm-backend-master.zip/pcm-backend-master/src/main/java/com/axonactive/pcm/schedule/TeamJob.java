package com.axonactive.pcm.schedule;

import com.axonactive.pcm.entity.Team;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.service.TeamDataTransferService;
import com.axonactive.pcm.service.TeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class TeamJob {
    private final TeamDataTransferService teamDataTransferService;
    private final TeamService teamService;

    @Autowired
    public TeamJob(TeamDataTransferService teamDataTransferService, TeamService teamService) {
        this.teamDataTransferService = teamDataTransferService;
        this.teamService = teamService;
    }

    @Scheduled(initialDelay = 1000, fixedRate = 43200000)
    public void getDataTeamFromHrTool() {
        boolean isTeamEmpty = false;
        try {
            teamService.readTeams();
        } catch (PCMEntityNotFoundException e) {
            isTeamEmpty = true;
        }
        if (!isTeamEmpty) {
            List<Team> newTeams = teamDataTransferService.teamHRToTeam();
            List<Team> oldTeams = teamService.readTeams();
            for (Team newTeam : newTeams) {
                boolean isCheck = false;
                for (Team oldTeam : oldTeams) {
                    if (newTeam.getTeamHrId() == oldTeam.getTeamHrId()) {
                        teamService.updateTeam(newTeam.getBranchName(), newTeam.getDepartmentName(), newTeam.getTeamEmail(),
                                newTeam.getTeamHrId(), newTeam.getTeamLeaderName(), newTeam.getTeamMembers(), newTeam.getTeamName(), newTeam.getTeamNotes(), oldTeam.getTeamId());
                        isCheck = true;
                        break;
                    }
                }
                if (!isCheck) {
                    teamService.saveTeam(newTeam);
                }
            }
        } else {
            teamDataTransferService.saveAllTeam();
        }
    }
}
