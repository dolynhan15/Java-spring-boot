package com.axonactive.pcm.repository;

import com.axonactive.pcm.entity.Position;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository
@Component
public interface PositionRepository extends CrudRepository<Position, Integer> {
    Position findByPositionTitle(String positionTitle);
}
