package com.axonactive.pcm.service.impl;

import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.entity.Position;
import com.axonactive.pcm.service.PositionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class ContactPositionServiceImpl implements com.axonactive.pcm.service.ContactPositionService {

    private final PositionService positionService;

    @Autowired
    public ContactPositionServiceImpl(PositionService positionService) {
        this.positionService = positionService;
    }

    @Override
    public Contact savePositionWithContact(Contact contact) {
        Position existPosition = positionService.readPositionByPositionTitle(contact.getContactPosition().getPositionTitle());
        if (Objects.isNull(existPosition)) {
            Position newPosition = new Position();
            newPosition.setPositionTitle(contact.getContactPosition().getPositionTitle());
            newPosition = positionService.savePosition(newPosition);
            contact.setContactPosition(newPosition);
        }
        return contact;
    }
}
