package com.axonactive.pcm.repository;
import com.axonactive.pcm.entity.VisitHistory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface VisitHistoryRepository extends CrudRepository<VisitHistory, Integer> {
    int deleteVisitHistoryById(int id);

    @Query(value = "select * from visit_history where contact_id = :contact_id", nativeQuery = true)
    List<VisitHistory> findVisitHistoriesByContactId (@Param("contact_id") int contact_id);
}
