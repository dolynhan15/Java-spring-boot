package com.axonactive.pcm.service.impl;

import com.axonactive.pcm.constant.DefaultParam;
import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.entity.VisitHistory;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.repository.VisitHistoryRepository;
import com.axonactive.pcm.service.VisitHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VisitHistoryServiceImpl implements VisitHistoryService {
    public static final String START_DATE_IS_REQUIRED = "Start Date is required!";
    public static final String END_DATE_IS_REQUIRED = "End Date is required!";
    public static final String END_DATE_MUST_BE_AFTER_START_DATE = "End Date must be after start date!";
    public static final String NOTES_IS_TOO_LONG_MAX_LENGTH_IS = "Notes is too long! Max length is ";
    public static final String CANNOT_FIND_ANY_VISIT_HISTORY_WITH_ID = "Cannot find any visit history with Id = ";
    @Autowired
    private VisitHistoryRepository visitHistoryRepository;

    @Override
    public VisitHistory save(VisitHistory visitHistory) {
        validate(visitHistory);
        return visitHistoryRepository.save(visitHistory);
    }

    @Override
    public void deleteVisithistoryById(int id) {
        try {
            visitHistoryRepository.delete(id);
        } catch (EmptyResultDataAccessException e){
            throw new InvalidParamException(CANNOT_FIND_ANY_VISIT_HISTORY_WITH_ID + id, DefaultPath.VISITHISTORY_PATH + "/" + id);
        }
    }

    @Override
    public void validate(VisitHistory visitHistory) {
        String path = DefaultPath.VISITHISTORY_PATH + (visitHistory.getId() != 0 ? "/" + visitHistory.getId() : "");
        if (visitHistory.getStartDate() == null){
            throw new InvalidParamException(START_DATE_IS_REQUIRED, path);
        }

        if (visitHistory.getEndDate() == null){
            throw new InvalidParamException(END_DATE_IS_REQUIRED, path);
        }

        if (visitHistory.getEndDate().before(visitHistory.getStartDate())) {
            throw new InvalidParamException(END_DATE_MUST_BE_AFTER_START_DATE, path);
        }

        if((visitHistory.getNotes() + "").length() > DefaultParam.MAX_TEXT_FIELD_LENGTH){
            throw new InvalidParamException(NOTES_IS_TOO_LONG_MAX_LENGTH_IS + DefaultParam.MAX_TEXT_FIELD_LENGTH, path);
        }
    }

    @Override
    public List<VisitHistory> findVisitHistoriesByContactId(int contactId) {
        return visitHistoryRepository.findVisitHistoriesByContactId(contactId);
    }

    @Override
    public void delete(List<VisitHistory> visitHistories) {
        this.visitHistoryRepository.delete(visitHistories);
    }
}
