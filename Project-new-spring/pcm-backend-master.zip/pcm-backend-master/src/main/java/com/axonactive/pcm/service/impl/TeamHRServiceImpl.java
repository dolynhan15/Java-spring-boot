package com.axonactive.pcm.service.impl;

import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.model.HRObject.*;
import com.axonactive.pcm.service.TeamHRService;
import com.axonactive.pcm.utility.PathHepper;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Service
public class TeamHRServiceImpl implements TeamHRService {

    public static final String STRING = "String";
    @Autowired
    private PathHepper pathHepper;

    RestTemplate restTemplate;

    public TeamHRServiceImpl() {
        restTemplate = new RestTemplate();
    }

    @Override
    public List<Branch> getAllBranches() {

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        List<Branch> branches = new ArrayList<>();

        String postUrl = pathHepper.getPathHrTool(DefaultPath.GET_ALL_BRANCHES) + pathHepper.getAccessKey();
        ResponseEntity<String> branchEntity = restTemplate.postForEntity(postUrl, STRING, String.class);
        try {
            branches = mapper.readValue(branchEntity.getBody(), new TypeReference<List<Branch>>() {
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
        return branches;
    }

    @Override
    public List<Department> getAllDepartmentByBranchId(int id) {

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        List<Department> departments = new ArrayList<>();

        String encodedString = Base64.getEncoder().encodeToString(String.valueOf(id).getBytes());
        String postUrl = pathHepper.getPathHrTool(DefaultPath.GET_ALL_DEPARTMENT_BY_BRANCHID) + encodedString + "&" + pathHepper.getAccessKey();
        ResponseEntity<String> departmentEntity = restTemplate.postForEntity(postUrl, STRING, String.class);
        try {
            departments = mapper.readValue(departmentEntity.getBody(), new TypeReference<List<Department>>() {
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
        return departments;
    }

    @Override
    public List<TeamHR> getAllTeamByDepartmentId(int id) {

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        List<TeamHR> teamHRS = new ArrayList<>();

        String encodedString = Base64.getEncoder().encodeToString(String.valueOf(id).getBytes());
        String postUrl = pathHepper.getPathHrTool(DefaultPath.GET_TEAM_BY_DEPARTMENTID)  + encodedString + "&" + pathHepper.getAccessKey();
        ResponseEntity<String> teamHREntity = restTemplate.postForEntity(postUrl, STRING, String.class);

        try {
            teamHRS = mapper.readValue(teamHREntity.getBody(), new TypeReference<List<TeamHR>>() {
            });
        } catch (IOException e) {
            e.printStackTrace();
        }

        return teamHRS;
    }
}
