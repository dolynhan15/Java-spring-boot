package com.axonactive.pcm.entity;

import com.axonactive.pcm.constant.ErrorMessageConstants;
import com.axonactive.pcm.constant.EntityConstants;
import com.axonactive.pcm.enums.Status;
import com.axonactive.pcm.exception.ParseJsonProcessingException;
import com.axonactive.pcm.model.DTO.TeamHistoryDTO;
import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;

import javax.persistence.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Entity
@JsonFilter(EntityConstants.FILTER_PROJECT)
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable = false)
    private int projectId;

    private String projectName;

    @Column(columnDefinition = "TEXT")
    private String projectCover;

    @Column(columnDefinition = "TEXT")
    private String projectDescription;

    @Column(columnDefinition = "TEXT")
    private String projectNotes;

    private Date projectStartDate;

    private Date projectEndDate;

    private Status projectStatus;

    @Transient
    private List<Contact> listContactPOs;

    @Transient
    private List<Integer> listContactId;

    private String listPOs;

    @Column(columnDefinition = "TEXT")
    private String teamHistory;

    @Transient
    private List<TeamHistoryDTO> teamHistoryDTOs;

    @Column(columnDefinition = "TEXT")
    private String projectScreenshot;

    @ManyToOne
    @JoinColumn(name = "contact_id")
    private Contact contact;

    @ManyToMany
    @JoinTable(
            name = "project_team",
            joinColumns = @JoinColumn(name = "project_id"),
            inverseJoinColumns = @JoinColumn(name = "team_id")
    )
    private List<Team> teams;

    @ManyToMany(cascade = CascadeType.MERGE)
    @JoinTable(
            name = "project_technology",
            joinColumns = @JoinColumn(name = "project_id"),
            inverseJoinColumns = @JoinColumn(name = "technology_id")
    )
    private List<Technology> technologies;

    @OneToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "networkinfrastructure_id")
    private NetworkInfrastructure networkInfrastructure;


    public int getProjectId() {
        return projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectCover() {
        return projectCover;
    }

    public void setProjectCover(String projectCover) {
        this.projectCover = projectCover;
    }

    public String getProjectDescription() {
        return projectDescription;
    }

    public void setProjectDescription(String projectDescription) {
        this.projectDescription = projectDescription;
    }

    public String getProjectNotes() {
        return projectNotes;
    }

    public void setProjectNotes(String projectNotes) {
        this.projectNotes = projectNotes;
    }

    public Date getProjectStartDate() {
        return projectStartDate;
    }

    public void setProjectStartDate(Date projectStartDate) {
        this.projectStartDate = projectStartDate;
    }

    public Date getProjectEndDate() {
        return projectEndDate;
    }

    public void setProjectEndDate(Date projectEndDate) {
        this.projectEndDate = projectEndDate;
    }

    public Status getProjectStatus() {
        return projectStatus;
    }

    public void setProjectStatus(Status projectStatus) {
        this.projectStatus = projectStatus;
    }

    public Contact getContact() {
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }

    public List<Team> getTeams() {
        return teams;
    }

    public void setTeams(List<Team> teams) {
        this.teams = teams;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public String getProjectScreenshot() {
        return projectScreenshot;
    }

    public void setProjectScreenshot(String projectScreenshot) {
        this.projectScreenshot = projectScreenshot;
    }

    public List<Technology> getTechnologies() {
        return technologies;
    }

    public void setTechnologies(List<Technology> technologies) {
        this.technologies = technologies;
    }

    public NetworkInfrastructure getNetworkInfrastructure() {
        return networkInfrastructure;
    }

    public void setNetworkInfrastructure(NetworkInfrastructure networkInfrastructure) {
        this.networkInfrastructure = networkInfrastructure;
    }

    public List<Contact> getListContactPOs() {
        return listContactPOs;
    }

    public void setListContactPOs(List<Contact> listContactPOs) {
        this.listContactPOs = listContactPOs;
    }

    public List<Integer> getListContactId() {
        if (Objects.isNull(this.listPOs) || StringUtils.isBlank(this.listPOs)) {
            return new ArrayList<>();
        }
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.readValue(this.listPOs, mapper.getTypeFactory().constructCollectionType(List.class, Integer.class));
        } catch (IOException e) {
            throw new ParseJsonProcessingException(ErrorMessageConstants.CANNOT_MAP_STRING_OBJECT_TO_LIST_POS, HttpStatus.BAD_REQUEST);
        }
    }

    public void setListContactId(List<Integer> listContactId) {
        this.listContactId = listContactId;
    }

    public String getListPOs() {
        return listPOs;
    }

    public void setListPOs(String listPOs) {
        this.listPOs = listPOs;
    }

    public void setListPOs() {
        if (Objects.isNull(this.listContactId)|| this.listContactId.isEmpty()) {
            this.listPOs = null;
            return;
        }

        try {
            this.listPOs = new ObjectMapper().writeValueAsString(this.listContactId);
        } catch (JsonProcessingException e) {
            throw new ParseJsonProcessingException(ErrorMessageConstants.CANNOT_PARSE_LIST_POS, HttpStatus.BAD_REQUEST);
        }

        return;
    }

    public String getTeamHistory() {
        return teamHistory;
    }

    public void setTeamHistory(String teamHistory) {
        this.teamHistory = teamHistory;
    }

    public List<TeamHistoryDTO> getTeamHistoryDTOs(){
        if (Objects.isNull(this.teamHistory) || StringUtils.isBlank(this.teamHistory)) {
            return new ArrayList<>();
        }
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.readValue(this.teamHistory, mapper.getTypeFactory().constructCollectionType(List.class, TeamHistoryDTO.class));
        } catch (IOException e) {
            throw new ParseJsonProcessingException(ErrorMessageConstants.CANNOT_MAP_STRING_OBJECT_TO_TEAM_HISTORY, HttpStatus.BAD_REQUEST);
        }
    }

    public void setTeamHistoryDTOs(List<TeamHistoryDTO> teamHistoryDTOs) {
        this.teamHistoryDTOs = teamHistoryDTOs;
    }

    public void setTeamsHistory() {
        if (Objects.nonNull(this.teamHistoryDTOs)&& !this.teamHistoryDTOs.isEmpty()) {
            try {
                this.teamHistory = new ObjectMapper().writeValueAsString(this.teamHistoryDTOs);
            } catch (JsonProcessingException e) {
                throw new ParseJsonProcessingException(ErrorMessageConstants.CANNOT_PARSE_TEAM_HISTORY, HttpStatus.BAD_REQUEST);
            }
        }
        return;
    }
}
