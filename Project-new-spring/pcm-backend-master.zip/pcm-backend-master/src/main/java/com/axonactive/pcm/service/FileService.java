package com.axonactive.pcm.service;

public interface FileService {
    String uploadImage(String target, String target_id, String imageString);

    String uploadImageList(String target, String target_id, String screenShots);

    boolean deleteImage(String imagePath, String pageType, int id);
}
