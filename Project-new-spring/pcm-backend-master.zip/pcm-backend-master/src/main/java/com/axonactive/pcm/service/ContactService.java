package com.axonactive.pcm.service;

import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;

import java.util.List;

public interface ContactService {

    List<Contact> saveContacts(List<Contact> contacts);

    List<Contact> readUnAssignedContacts() ;

    Contact readContactById(int contactId) throws PCMEntityNotFoundException, InvalidParamException;

    List<Contact> readListContacts() throws PCMEntityNotFoundException, InvalidParamException;

    Contact saveContact(Contact contact) throws InvalidParamException;

    int resetContactsCustomerIdToNullBeforeSave(int customerId, int[] contactsNotBeReset);

    List<Contact> resetContacts(List<Contact> contacts);

    List<Contact> findByContactIdIn(List<Integer> contactIds);

    void delete(int contactId);

    int unSetCustomer(int contact_id);

    int updateCustomerId(int contact_id, int customer_id, boolean contact_is_representative);

    int updateWifiKey(String wifikey, int contactId);

    void validate(Contact contact);

    Contact detachAndSetPath(Contact contact);
}
