package com.axonactive.pcm.service;

import com.axonactive.pcm.entity.Project;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;

import java.util.List;

public interface ProjectService {

    List<Project> readProjectsByContactId(int contact_id);

    List<Project> findAllByOrderByProjectIdDesc();

    Project findByProjectId(int projectId);

    Project saveProject(Project project) throws InvalidParamException;

    int updateContactId(int contact_id, int id);

    List<String> findProjectNameByContactId(int contactId);

    List<Project> findByListPOsNotNull();

    List<Project> findByTeamNameAndNotHasTeam(String teamName);

    List<Project> findAllByTeamName(String teamName);

    int updateNetworkInfrastructureId(int networkInfrastructureId, int projectId);

    void validate(Project project);
}
