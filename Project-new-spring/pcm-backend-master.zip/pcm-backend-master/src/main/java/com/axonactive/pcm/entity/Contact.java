package com.axonactive.pcm.entity;

import com.axonactive.pcm.constant.EntityConstants;
import com.axonactive.pcm.enums.Gender;
import com.fasterxml.jackson.annotation.*;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@JsonFilter(EntityConstants.FILTER_CONTACT)
public class Contact {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable = false)
    private int contactId;

    @Column(nullable = false)
    private String contactFirstName;

    @Column(nullable = false)
    private String contactLastName;

    @Enumerated
    private Gender contactGender;

    @Column(columnDefinition = "TEXT")
    private String contactAvatar;

    private Date contactBirthday;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @OneToMany(mappedBy = "contact")
    private List<Project> projects;

    @ManyToOne
    @JoinColumn(name = "position_id")
    private Position position;

    private String contactPhone;

    private String contactEmail;

    private String contactSkype;

    private String contactSlack;

    private String contactLinkedin;

    private String contactWifiKey;

    @Column(columnDefinition = "TEXT")
    private String contactNotes;

    private boolean contactIsRepresentative;

    private boolean contactIsDefault;

    @OneToMany(mappedBy = "contact")
    private List<VisitHistory> visitHistories;

    @Column(columnDefinition = "TEXT")
    private String contactGallery;

    public boolean isContactIsDefault() {
        return contactIsDefault;
    }

    public void setContactIsDefault(boolean contactIsDefault) {
        this.contactIsDefault = contactIsDefault;
    }

    public int getContactId() {
        return contactId;
    }

    public String getContactFirstName() {
        return contactFirstName;
    }

    public void setContactFirstName(String contactFirstName) {
        this.contactFirstName = contactFirstName;
    }

    public String getContactLastName() {
        return contactLastName;
    }

    public void setContactLastName(String contactLastName) {
        this.contactLastName = contactLastName;
    }

    public Gender getContactGender() {
        return contactGender;
    }

    public void setContactGender(Gender contactGender) {
        this.contactGender = contactGender;
    }

    public Position getContactPosition() {
        return this.position;
    }

    public void setContactPosition(Position contactPosition) {
        this.position = contactPosition;
    }

    public Date getContactBirthday() {
        return contactBirthday;
    }

    public String getContactAvatar() {
        return contactAvatar;
    }

    public void setContactAvatar(String contactAvatar) {
        this.contactAvatar = contactAvatar;
    }

    public void setContactBirthday(Date contactBirthday) {
        this.contactBirthday = contactBirthday;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getContactSkype() {
        return contactSkype;
    }

    public void setContactSkype(String contactSkype) {
        this.contactSkype = contactSkype;
    }

    public String getContactSlack() {
        return contactSlack;
    }

    public void setContactSlack(String contactSlack) {
        this.contactSlack = contactSlack;
    }

    public String getContactLinkedin() {
        return contactLinkedin;
    }

    public void setContactLinkedin(String contactLinkedin) {
        this.contactLinkedin = contactLinkedin;
    }

    public String getContactWifiKey() {
        return contactWifiKey;
    }

    public void setContactWifiKey(String contactWifiKey) {
        this.contactWifiKey = contactWifiKey;
    }

    public String getContactNotes() {
        return contactNotes;
    }

    public void setContactNotes(String contactNotes) {
        this.contactNotes = contactNotes;
    }

    public boolean getContactIsRepresentative() {
        return contactIsRepresentative;
    }

    public void setContactIsRepresentative(boolean contactIsRepresentative) {
        this.contactIsRepresentative = contactIsRepresentative;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<Project> getProjects() {
        return projects;
    }

    public void setProjects(List<Project> projects) {
        this.projects = projects;
    }

    public void setContactId(int contactId) {
        this.contactId = contactId;
    }

    public String getContactGallery() {
        return contactGallery;
    }

    public void setContactGallery(String contactGallery) {
        this.contactGallery = contactGallery;
    }

    public List<VisitHistory> getVisitHistories() {
        return visitHistories;
    }

    public void setVisitHistories(List<VisitHistory> visitHistories) {
        this.visitHistories = visitHistories;
    }
}
