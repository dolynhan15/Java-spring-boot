package com.axonactive.pcm.service.impl;

import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.entity.Team;
import com.axonactive.pcm.model.DTO.CustomerDetailDTO;
import com.axonactive.pcm.service.ContactService;
import com.axonactive.pcm.service.CustomerDetailDTOService;
import com.axonactive.pcm.service.CustomerService;
import com.axonactive.pcm.utility.PathHepper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;

@Service
public class CustomerDetailDTOServiceImpl implements CustomerDetailDTOService {

    private final
    EntityManager entityManager;

    private final
    CustomerService customerService;

    private final
    ContactService contactService;

    private final
    TeamServiceImpl teamService;

    private final
    PathHepper pathHepper;

    @Autowired
    public CustomerDetailDTOServiceImpl(EntityManager entityManager, CustomerService customerService, ContactService contactService, TeamServiceImpl teamService, PathHepper pathHepper) {
        this.entityManager = entityManager;
        this.customerService = customerService;
        this.contactService = contactService;
        this.teamService = teamService;
        this.pathHepper = pathHepper;
    }

    @Override
    public CustomerDetailDTO detachAndSetPath(CustomerDetailDTO customerDetailDTO) {
        entityManager.detach(customerDetailDTO.customer);
        customerDetailDTO.customer.setCustomerLogo(pathHepper.handlerImage(customerDetailDTO.customer.getCustomerLogo()));
        customerDetailDTO.customer.setContacts(contactService.resetContacts(customerDetailDTO.customer.getContacts()));
        for (Contact contact : customerDetailDTO.customer.getContacts()) {
            entityManager.detach(contact);
            contact.setContactAvatar(pathHepper.handlerImage(contact.getContactAvatar()));
        }
        customerDetailDTO.teams = teamService.readTeamByCustomerId(customerDetailDTO.customer.getCustomerId());
        for (Team team : customerDetailDTO.teams) {
            entityManager.detach(team);
            team.setTeamLogo(pathHepper.handlerImage(team.getTeamLogo()));
        }
        return customerDetailDTO;
    }

}
