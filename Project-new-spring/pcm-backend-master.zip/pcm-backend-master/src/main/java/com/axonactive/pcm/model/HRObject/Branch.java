package com.axonactive.pcm.model.HRObject;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Branch {

    @JsonProperty("branchId")
    private int branchId;

    @JsonProperty("branchName")
    private String branchName;

    public int getBranchId() {
        return branchId;
    }

    public void setBranchId(int branchId) {
        this.branchId = branchId;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }
}
