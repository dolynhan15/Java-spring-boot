package com.axonactive.pcm.model.DTO;

import com.axonactive.pcm.entity.Customer;
import com.axonactive.pcm.entity.Project;
import com.axonactive.pcm.entity.Team;
import com.axonactive.pcm.enums.Status;
import com.fasterxml.jackson.annotation.JsonFilter;

import java.util.List;
@JsonFilter("filter.TeamDTO")
public class TeamDTO {
    public Team team;
    public List<Customer> customers;
    public Status teamStatus;
}