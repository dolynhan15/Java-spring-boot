package com.axonactive.pcm.service;

import com.axonactive.pcm.entity.Project;

import java.util.List;

public interface ProjectTeamService {

    List<Project> readProjectsByTeamName(String teamName);

    List<Project> readProjectsByTeamAndNotHasTeam(String teamName);
}
