package com.axonactive.pcm.service.impl;

import com.axonactive.pcm.entity.NetworkInfrastructure;
import com.axonactive.pcm.repository.NetworkInfrastructureRepository;
import com.axonactive.pcm.service.NetworkInfrastructureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NetworkInfrastructureServiceImpl implements NetworkInfrastructureService {
    @Autowired
    private NetworkInfrastructureRepository networkInfrastructureRepository;

    @Override
    public NetworkInfrastructure saveNetworkInfrastructure(NetworkInfrastructure networkInfrastructure) {
        return networkInfrastructureRepository.save(networkInfrastructure);
    }
}
