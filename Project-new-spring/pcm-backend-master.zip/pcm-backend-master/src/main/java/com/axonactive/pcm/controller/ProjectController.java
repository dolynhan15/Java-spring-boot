package com.axonactive.pcm.controller;

import com.axonactive.pcm.constant.DefaultParam;
import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.constant.EntityConstants;
import com.axonactive.pcm.constant.ErrorMessageConstants;
import com.axonactive.pcm.entity.Project;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.model.authentication.AuthenticatedUser;
import com.axonactive.pcm.service.*;
import com.axonactive.pcm.utility.JwtTokenValidator;
import com.axonactive.pcm.utility.PathHepper;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.axonactive.pcm.constant.EntityConstants.*;

@RestController
@RequestMapping(DefaultPath.PROJECT_PATH)
@CrossOrigin
public class ProjectController {

    private static final Logger logger = LogManager.getLogger(ProjectController.class);

    private final FileService fileService;

    private final ProjectService projectService;

    private final ProjectTechnologyService projectTechnologyService;

    private final ProjectContactService projectContactService;

    private final ProjectTeamService projectTeamService;

    private final JwtTokenValidator jwtTokenValidator;

    private final PathHepper pathHepper;

    @Autowired
    public ProjectController(FileService fileService, ProjectService projectService, ProjectTechnologyService projectTechnologyService, ProjectContactService projectContactService, ProjectTeamService projectTeamService, JwtTokenValidator jwtTokenValidator, PathHepper pathHepper) {
        this.fileService = fileService;
        this.projectService = projectService;
        this.projectTechnologyService = projectTechnologyService;
        this.projectContactService = projectContactService;
        this.projectTeamService = projectTeamService;
        this.jwtTokenValidator = jwtTokenValidator;
        this.pathHepper = pathHepper;
    }

    @PostMapping
    @PreAuthorize("hasAnyAuthority('New Project', 'Exception-SM-Interact-Project-Only')")
    public ResponseEntity createProject(@RequestBody Project project, Authentication authentication){
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/projects/ - {} - createProject -- user: {}", project.getProjectName()+"", currentUser.getUsername());
        project = projectTechnologyService.saveProjectWithNewTechnology(project);
        project.setContact(projectContactService.createContactDefault(project));

        String projectCover = project.getProjectCover();
        project.setProjectCover(null);

        String projectScreenshot = project.getProjectScreenshot();
        project.setProjectScreenshot(null);

        Project newProject = projectService.saveProject(project);

        //set logo
        newProject.setProjectCover(fileService.uploadImage(DefaultParam.TARGET_PROJECT, project.getProjectId() + "", projectCover));

        //set screenshot
        newProject.setProjectScreenshot(fileService.uploadImageList(DefaultParam.TARGET_PROJECT,project.getProjectId() + "", projectScreenshot));

        //Update logo + screenshot
        newProject = projectService.saveProject(newProject);
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(newProject);

        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_PROJECT, SimpleBeanPropertyFilter.serializeAll())
                .addFilter(FILTER_CONTACT, SimpleBeanPropertyFilter.filterOutAllExcept(
                        CONTACT_ID,
                        CONTACT_FIRST_NAME,
                        CONTACT_LAST_NAME,
                        CONTACT_IS_DEFAULT,
                        CUSTOMER))
                .addFilter(FILTER_CUSTOMER, SimpleBeanPropertyFilter.filterOutAllExcept(
                        CUSTOMER_ID,
                        CUSTOMER_NAME))
                .addFilter(FILTER_TECHNOLOGY, SimpleBeanPropertyFilter.filterOutAllExcept(
                        ID,
                        NAME))
                .addFilter(FILTER_TEAM, SimpleBeanPropertyFilter.serializeAllExcept(PROJECTS));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.CREATED);
    }

    @PutMapping
    @PreAuthorize("hasAnyAuthority('Edit Project', 'Exception-SM-Interact-Project-Only')")
    public ResponseEntity updateProject(@RequestBody Project project, Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/projects/ - {} - updateProject -- user: {}", project.getProjectName()+"", currentUser.getUsername());
        if (project.getProjectId() == 0) {
            throw new InvalidParamException(ErrorMessageConstants.ID_NOT_FOUND_ERROR, DefaultPath.PROJECT_PATH);
        }
        project = projectContactService.deleteContactDefaultInProject(project);
        project = projectTechnologyService.saveProjectWithNewTechnology(project);

        //set logo
        project.setProjectCover(fileService.uploadImage(DefaultParam.TARGET_PROJECT, project.getProjectId() + "", pathHepper.removePathServerImage(project.getProjectCover())));
        //set screenshot
        project.setProjectScreenshot(fileService.uploadImageList(DefaultParam.TARGET_PROJECT,project.getProjectId() + "", pathHepper.removePathServerScreenShot(project.getProjectScreenshot())));

        //Update logo + screenshot
        Project newProject = projectService.saveProject(project);
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(newProject);
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_PROJECT, SimpleBeanPropertyFilter.serializeAll())
                .addFilter(FILTER_CONTACT, SimpleBeanPropertyFilter.filterOutAllExcept(
                        CONTACT_ID,
                        CONTACT_FIRST_NAME,
                        CONTACT_LAST_NAME,
                        CONTACT_IS_DEFAULT,
                        CUSTOMER))
                .addFilter(FILTER_CUSTOMER, SimpleBeanPropertyFilter.filterOutAllExcept(
                        CUSTOMER_ID,
                        CUSTOMER_NAME))
                .addFilter(FILTER_TEAM, SimpleBeanPropertyFilter.filterOutAllExcept(
                        TEAM_ID,
                        TEAM_NAME))
                .addFilter(FILTER_TECHNOLOGY, SimpleBeanPropertyFilter.filterOutAllExcept(
                        ID,
                        NAME));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @GetMapping(DefaultPath.PROJECT_ID_VARIABLE)
    @PreAuthorize("hasAnyAuthority('View Project Detail', 'Edit Project', 'Edit Network Infrastructure', 'View My Project', 'Exception-SM-Interact-Project-Only')")
    public ResponseEntity getProjectDetail(@PathVariable int projectId, Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/projects/{} - getProjectDetail -- user: {}", projectId, currentUser.getUsername());
        jwtTokenValidator.isMyProject(currentUser, projectId);
        Project project = projectContactService.readProjectById(projectId);
        project.setProjectCover(pathHepper.handlerImage(project.getProjectCover()));
        project.setProjectScreenshot(pathHepper.handlerScreenShot(project.getProjectScreenshot()));
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(project);
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_PROJECT, SimpleBeanPropertyFilter.serializeAll())
                .addFilter(FILTER_CONTACT, SimpleBeanPropertyFilter.filterOutAllExcept(
                        CONTACT_ID,
                        CONTACT_FIRST_NAME,
                        CONTACT_LAST_NAME,
                        CONTACT_IS_DEFAULT,
                        CUSTOMER))
                .addFilter(FILTER_CUSTOMER, SimpleBeanPropertyFilter.filterOutAllExcept(
                        CUSTOMER_ID,
                        CUSTOMER_NAME))
                .addFilter(FILTER_TEAM, SimpleBeanPropertyFilter.filterOutAllExcept(
                        TEAM_ID,
                        TEAM_NAME))
                .addFilter(FILTER_TECHNOLOGY, SimpleBeanPropertyFilter.filterOutAllExcept(
                        ID,
                        NAME));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @GetMapping()
    @PreAuthorize("hasAnyAuthority('View Project List')")
    public ResponseEntity getProjects(Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/projects/ - getProjects -- user: {}" , currentUser.getUsername());
        List<Project> projects = projectContactService.readProjects();
        for (Project project : projects) {
            project.setProjectCover(pathHepper.handlerImage(project.getProjectCover()));
        }

        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(projects);
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_PROJECT, SimpleBeanPropertyFilter.filterOutAllExcept(
                        PROJECT_ID,
                        PROJECT_COVER,
                        PROJECT_NAME,
                        PROJECT_STATUS,
                        LIST_CONTACT_POS, CONTACT, TEAMS))
                .addFilter(FILTER_CONTACT, SimpleBeanPropertyFilter.filterOutAllExcept(
                        CONTACT_ID, CONTACT_FIRST_NAME, CONTACT_LAST_NAME, CONTACT_IS_DEFAULT, CUSTOMER))
                .addFilter(FILTER_CUSTOMER,SimpleBeanPropertyFilter.filterOutAllExcept(CUSTOMER_ID, CUSTOMER_NAME))
                .addFilter(FILTER_TEAM, SimpleBeanPropertyFilter.filterOutAllExcept(TEAM_ID, TEAM_NAME));
                mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

    @GetMapping(DefaultPath.GET_BY_TEAM_NAME_PATH)
    @PreAuthorize("hasAnyAuthority('View Project List By Team', 'Exception-SM-Interact-Project-Only')")
    public ResponseEntity getProjectsByTeamName(@PathVariable String teamName, Authentication authentication) {
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        logger.info("-- api/projects/getByTeamName/{} - getProjectsByTeamName -- user: {}", teamName, currentUser.getUsername());
        jwtTokenValidator.isTeamOwner(authentication, teamName);
        List<Project> projects;
        if (currentUser.getAuthorities().contains(new SimpleGrantedAuthority("Exception-SM-Interact-Project-Only"))) {
            projects = projectTeamService.readProjectsByTeamAndNotHasTeam(teamName);
        } else {
            projects = projectTeamService.readProjectsByTeamName(teamName);
        }

        for (Project project : projects) {
            project.setProjectCover(pathHepper.handlerImage(project.getProjectCover()));
        }

        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(projects);
        FilterProvider filterProvider = new SimpleFilterProvider()
                .addFilter(FILTER_PROJECT, SimpleBeanPropertyFilter.filterOutAllExcept(
                        PROJECT_ID, PROJECT_COVER, PROJECT_NAME, PROJECT_STATUS, LIST_CONTACT_POS, CONTACT, TEAMS))
                .addFilter(FILTER_CONTACT, SimpleBeanPropertyFilter.filterOutAllExcept(CONTACT_ID, CONTACT_FIRST_NAME, CONTACT_LAST_NAME, CONTACT_IS_DEFAULT, CUSTOMER))
                .addFilter(FILTER_CUSTOMER,SimpleBeanPropertyFilter.filterOutAllExcept(CUSTOMER_ID, CUSTOMER_NAME))
                .addFilter(FILTER_TEAM, SimpleBeanPropertyFilter.filterOutAllExcept(TEAM_ID, TEAM_NAME));
        mappingJacksonValue.setFilters(filterProvider);
        return new ResponseEntity<>(mappingJacksonValue, HttpStatus.OK);
    }

}
