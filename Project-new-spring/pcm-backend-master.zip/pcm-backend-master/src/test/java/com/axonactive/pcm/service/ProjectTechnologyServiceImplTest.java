package com.axonactive.pcm.service;

import com.axonactive.pcm.PcmApplication;
import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.entity.Project;
import com.axonactive.pcm.entity.Team;
import com.axonactive.pcm.entity.Technology;
import com.axonactive.pcm.enums.Status;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.transaction.Transactional;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import static junit.framework.TestCase.assertNotNull;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = PcmApplication.class)
@TestPropertySource("classpath:application-test.properties")
@Transactional
public class ProjectTechnologyServiceImplTest {
    public Project project;
    @Autowired
    public ProjectTechnologyService projectTechnologyService;
    @Autowired
    public ContactService contactService;
    @Autowired
    public TeamService teamService;
    @Autowired
    public TechnologyService technologyService;

    public Project data(){
        project = new Project();
        project.setProjectName("PCM");
        Contact contact = new Contact();
        contact = contactService.readContactById(11);
        project.setContact(contact);
        List<Team> teams = new ArrayList<>();
        Team team1 = new Team();
        team1 = teamService.readTeamById(431);
        Team team2 = new Team();
        team2 = teamService.readTeamById(432);
        teams.add(team1);
        teams.add(team2);
        project.setTeams(teams);
        List<Technology> technologies = new ArrayList<>();
        Technology technology = new Technology();
        technology = technologyService.getTechnologyByName("JAVA");
        technologies.add(technology);
        project.setTechnologies(technologies);
        project.setProjectDescription("This is project about Product Customer Management");
        project.setProjectNotes("");
        project.setProjectStatus(Status.ACTIVE);
        try {
            SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
            project.setProjectStartDate(df.parse("02/16/2018"));
            project.setProjectEndDate(df.parse("03/16/2019"));
        }catch (ParseException p) {
        }
        return project;
    }

    @Test
    public void whenSaveProjectWithNewTechnology_withValidProjectParam_ReturnProject(){
        data();
        Technology technology = new Technology();
        technology.setName("C#");
        List<Technology> technologies = new ArrayList<>();
        technologies.add(technology);
        project.setTechnologies(technologies);
        assertNotNull(projectTechnologyService.saveProjectWithNewTechnology(project));
    }
}
