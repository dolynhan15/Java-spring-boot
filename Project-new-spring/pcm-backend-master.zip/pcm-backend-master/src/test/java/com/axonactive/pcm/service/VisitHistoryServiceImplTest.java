package com.axonactive.pcm.service;

import com.axonactive.pcm.PcmApplication;
import com.axonactive.pcm.entity.VisitHistory;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.repository.VisitHistoryRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.transaction.Transactional;
import java.util.Date;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertNotNull;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = PcmApplication.class)
@TestPropertySource("classpath:application-test.properties")
@Transactional
public class VisitHistoryServiceImplTest {
    private static String tooLongText = "saaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaassssssssssssssssssssssssssssssssssssssssssssssssss";
    private VisitHistory visitHistory;

    @Autowired
    public VisitHistoryService visitHistoryService;

    @Autowired
    public VisitHistoryRepository visitHistoryRepository;

    @Before
    public void createVisitHistory(){
        visitHistory = new VisitHistory();
        visitHistory.setId(90);
        visitHistory.setStartDate(new Date(2018,5,10));
        visitHistory.setEndDate(new Date(2018,5,20));
        visitHistory.setNotes("This is a test notes");
    }

    /*---------Validate()----------*/
    @Test(expected = InvalidParamException.class)
    public void whenValidate_withStartDateIsNull_thenThrowInvalidParamException() {
        visitHistory.setStartDate(null);
        visitHistoryService.validate(visitHistory);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withEndDateIsNull_thenThrowInvalidParamException() {
        visitHistory.setEndDate(null);
        visitHistoryService.validate(visitHistory);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withEndDateBeforeStartDate_thenThrowInvalidParamException() {
        visitHistory.setStartDate(new Date(2018, 5, 10));
        visitHistory.setEndDate(new Date(2018, 5, 4));
        visitHistoryService.validate(visitHistory);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withNotesIsTooLong_thenThrowInvalidParamException() {
        visitHistory.setNotes(tooLongText);
        visitHistoryService.validate(visitHistory);
    }

    /*---------save()----------*/
    @Test
    public void whenSave_withValidParam_thenReturnTheSameObject(){
        assertNotNull(visitHistoryService.save(this.visitHistory));
    }

    /*---------deleteVisithistoryById()----------*/
    @Test
    public void whenDeleteVisithistoryById_withIdIsExist() {
        visitHistoryService.deleteVisithistoryById(103);
        assertEquals(null, visitHistoryRepository.findOne(103));
    }

    @Test(expected = InvalidParamException.class)
    public void whenDeleteVisithistoryById_withIdIsNotExist_thenThrowInvalidParamException() {
        visitHistoryService.deleteVisithistoryById(1000);
    }
}
