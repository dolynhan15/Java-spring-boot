package com.axonactive.pcm.service;

import com.axonactive.pcm.PcmApplication;
import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.entity.Customer;
import com.axonactive.pcm.enums.Status;
import com.axonactive.pcm.service.impl.CustomerContactServiceImpl;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.transaction.Transactional;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = PcmApplication.class)
@TestPropertySource("classpath:application-test.properties")
@Transactional
public class CustomerContactServiceImplTest {
    @Autowired
    public CustomerContactService customerContactService;

    @Autowired
    public ContactService contactService;

    @Autowired
    private CustomerService customerService;

    private Customer customer;
    private List<Contact> contacts = new ArrayList<>();
    private int contactId = 14;

    public Customer data() {
        customer = new Customer();
        customer.setCustomerId(11);
        customer.setCustomerName("Hoang Long 1");
        customer.setCustomerWebsite("www.hoanglong1.org");
        customer.setCustomerAddress("193 Nguyen Luong Bang");
        customer.setStatus(Status.ACTIVE);
        try {
            String startDateString = "07/27/2007";
            SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
            customer.setCustomerStartDate(df.parse(startDateString));
        } catch (ParseException p) {
        }
        customer.setContacts(null);
        customer.setCustomerLogo("");
        customer.setCustomerNotes("This is Company Hoang Long");
        return customer;
    }

    public List<Contact> getContacts() {
        Contact contact = new Contact();
        contact = contactService.readContactById(contactId);
        contacts.add(contact);
        return contacts;
    }

    /*------------saveContactsWithCustomer-------------*/
    @Test
    public void WhenSaveContactWithCustomer_withValidParam_thenReturnCustomerSame() {
        data();
        getContacts();
        Customer c = customerContactService.saveContactsWithCustomer(customer, contacts);
        assertNotNull(c);
    }

    @Test
    public void WhenSaveContactWithCustomer_withContactsIsEmpty_thenReturnCustomerSame() {
        data();
        contacts.clear();
        Customer c = customerContactService.saveContactsWithCustomer(customer, contacts);
        assertNotNull(c);
    }

    /*------------editContactCustomer-------------*/
    @Test
    public void whenEditContactCustomer_withValidInput_thenReturnCustomer() {
        Customer oldCustomer = customerService.readCustomerById(15);

        Customer newCustomer = new Customer();
        newCustomer.setCustomerId(15);
        List<Contact> newContacts = getContacts();
        newContacts.forEach(ct -> {
            ct.setCustomer(null);
        });
        newCustomer.setContacts(newContacts);

        Customer resultCustomer = customerContactService.editContactCustomer(oldCustomer, newCustomer);

        // new contacts belong to customer
        assertEquals(contactId, resultCustomer.getContacts().get(0).getContactId());
    }
}
