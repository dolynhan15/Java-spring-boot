package com.axonactive.pcm.service;

import com.axonactive.pcm.PcmApplication;
import com.axonactive.pcm.entity.NetworkInfrastructure;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.transaction.Transactional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = PcmApplication.class)
@TestPropertySource("classpath:application-test.properties")
@Transactional
public class NetworkInfrastructureServiceImplTest {
    @Autowired
    public NetworkInfrastructureService networkInfrastructureService;

    public NetworkInfrastructure createData() {
        NetworkInfrastructure networkInfrastructure = new NetworkInfrastructure();
        networkInfrastructure.setId(2);
        networkInfrastructure.setCapacity("{\"data\":\"150\",\"unit\":\"Tb\"}");
        networkInfrastructure.setMemory("{\"data\":\"8\",\"unit\":\"Gb\"}");
        networkInfrastructure.setCore("4");
        networkInfrastructure.setIp("192.168.1.1");
        networkInfrastructure.setOperationSystem("Linux 16.04");
        networkInfrastructure.setServer("Flamingo-server");
        networkInfrastructure.setPassword("aavn@1234*");
        networkInfrastructure.setUsername("PCM-server");

        networkInfrastructure = networkInfrastructureService.saveNetworkInfrastructure(networkInfrastructure);

        return networkInfrastructure;
    }

    @Test
    public void whenSaveNetworkInfrastructure_withValidParams_thenReturnNetworkInfrastructure() {
        NetworkInfrastructure networkInfrastructure = createData();

        assertNotNull(networkInfrastructureService.saveNetworkInfrastructure(networkInfrastructure));
    }
}
