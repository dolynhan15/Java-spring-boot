package com.axonactive.pcm.service;

import com.axonactive.pcm.PcmApplication;
import com.axonactive.pcm.constant.DefaultPath;
import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.entity.Customer;
import com.axonactive.pcm.entity.Position;
import com.axonactive.pcm.enums.Gender;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.repository.ContactRepository;
import com.axonactive.pcm.service.impl.ContactServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = PcmApplication.class)
@TestPropertySource("classpath:application-test.properties")
@Transactional
public class ContactServiceImplTest {
    @Autowired
    private ContactService contactService;

    @Autowired
    private PositionService positionService;

    @InjectMocks
    private ContactServiceImpl contactServiceMock;

    @Mock
    private ContactRepository contactRepositoryMock;

    private static List<Contact> contacts;
    private static Contact contact;
    private static String tooLongString = "saaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaassssssssssssssssssssssssssssssssssssssssssssssssss";
    private static String tooLongText = "saaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaassssssssssssssssssssssssssssssssssssssssssssssssss";

    @Before
    public void data() {
        contact = new Contact();
        contact.setContactId(11);
        contact.setContactFirstName("Hoang");
        contact.setContactLastName("Ta");
        Position p = positionService.readPositionByPositionTitle("CEO");
        contact.setContactPosition(p);
        contact.setContactGender(Gender.MALE);
        contact.setContactEmail("hoangta@gmail.com");
        contact.setContactNotes("");
        contact.setCustomer(new Customer());
    }

    @Before
    public void getContacts() {
        contacts = new ArrayList<>();
        Contact contact = new Contact();
        contact = contactService.readContactById(12);
        Contact contact1 = new Contact();
        contact1 = contactService.readContactById(13);
        Contact contact2 = new Contact();
        contact2 = contactService.readContactById(15);
        contacts.add(contact);
        contacts.add(contact1);
        contacts.add(contact2);
    }

    public Contact createContactDefault(){
        Contact contactDefault = new Contact();
        contactDefault.setContactId(100);
        contactDefault.setContactFirstName("Default");
        contactDefault.setContactLastName("Detault");
        Position p = positionService.readPositionByPositionTitle("CEO");
        contactDefault.setContactPosition(p);
        contactDefault.setContactGender(Gender.MALE);
        contactDefault.setContactEmail("default@gmail.com");
        contactDefault.setContactNotes("");
        contactDefault.setContactIsDefault(true);
        return contactService.saveContact(contactDefault);
    }

    /*--------- validate() --------*/
    @Test(expected = InvalidParamException.class)
    public void whenValidate_withEmptyFirstName_thenThrowInvalidParamException () {
        data();
        contact.setContactFirstName("");
        contactService.validate(contact);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withFirstNameIsNull_thenThrowInvalidParamException () {
        data();
        contact.setContactFirstName(null);
        contactService.validate(contact);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withFirstNameIsTooLong_thenThrowInvalidParamException () {
        data();
        contact.setContactFirstName(tooLongString);
        contactService.validate(contact);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withEmptyLastName_thenThrowInvalidParamException () {
        data();
        contact.setContactLastName("");
        contactService.validate(contact);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withLastNameIsNull_thenThrowInvalidParamException () {
        data();
        contact.setContactLastName(null);
        contactService.validate(contact);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withLastNameIsTooLong_thenThrowInvalidParamException () {
        data();
        contact.setContactLastName(tooLongString);
        contactService.validate(contact);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withEmailIsTooLong_thenThrowInvalidParamException () {
        data();
        contact.setContactEmail(tooLongString);
        contactService.validate(contact);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withNoteIsTooLong_thenThrowInvalidParamException () {
        data();
        contact.setContactNotes(tooLongText);
        contactService.validate(contact);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withGenderIsNull_thenThrowInvalidParamException () {
        data();
        contact.setContactGender(null);
        contactService.validate(contact);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withPositionIsNull_thenThrowInvalidParamException () {
        data();
        contact.setContactPosition(null);
        contactService.validate(contact);
    }

    /*--------- SaveContacts()--------*/
    @Test
    public void whenSaveContactsList_withListContactIsValid_returnListContactNotNull() {
        assertNotNull(contactService.saveContacts(contacts));
    }

    /*--------- SaveReadUnAssignedContacts()--------*/
    @Test
    public void whenReadUnAssignedContacts_withNotParam_returnSameListContactUnAssignedContacts() {
        List<Contact> contactList = contactService.readUnAssignedContacts();
        assertNotNull(contactList);
    }

    /*--------- ReadListContacts()--------*/
    @Test
    public void whenReadListContacts_withNotParam_returnSameListContact() {
        List<Contact> contactList = contactService.readListContacts();
        assertNotNull(contactList);
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenReadListContacts_thenThrowPCMEntityNotFoundException(){
        when(contactRepositoryMock.findAllByContactIsDefaultFalseOrderByCustomerCustomerStartDateDescPositionPositionTitleAscContactLastNameAsc())
                .thenReturn(new ArrayList<Contact>());

        contactServiceMock.readListContacts();
    }

    /*--------- ReadContactByID(ContactId)--------*/
    @Test()
    public void whenReadContactById_withValidContactId_returnSameContact() {
        assertNotNull(contactService.readContactById(11));
    }

    @Test(expected = InvalidParamException.class)
    public void whenReadContactById_withValidContactIdNegative_returnInvalidParamException() {
        contactService.readContactById(-1);
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenReadContactById_withInValidContactId_returnPCMEntityNotFoundException() {
        contactService.readContactById(10000);
    }

    /*--------- SaveContact(Contact)--------*/
    @Test
    public void whenSaveContact_withContactIsValid_returnSameContact() {
        contact.setCustomer(null);
        contact.setContactAvatar(DefaultPath.IMAGES);
        assertNotNull(contactService.saveContact(contact));
    }

    @Test
    public void whenSaveContact_withContactAndContactAvatarNull_returnSameContact() {
        contact.setCustomer(null);
        contact.setContactAvatar("");
        assertNotNull(contactService.saveContact(contact));
    }

    /*--------- resetContactsCustomerIdToNullBeforeSave() --------*/
    @Test
    public void whenResetCustomerIdInContact_withCustomerIdAndArrayContactId_returnRecordNumberUpdate() {
        int customerId = 10;
        int[] contactIds = {11, 20};
        int result = contactService.resetContactsCustomerIdToNullBeforeSave(customerId, contactIds);
        assertEquals(1, result);
    }

    /*--------- ResetContacts() --------*/
    @Test
    public void whenResetContacts_withListContactContainsDefaultContacts_returnListContactsWithoutDefaultContacts(){
        Contact contactDefault = new Contact();
        contactDefault.setContactIsDefault(true);
        contacts.add(contactDefault);
        contacts = contactService.resetContacts(contacts);
        boolean result = true;
        for (Contact contact: contacts) {
            if(contact.isContactIsDefault()){
                result = false;
                break;
            }
        }
        assertTrue(result);
    }

    /*--------- UpdateWifikey() --------*/
    @Test
    public void whenUpdateWifikey_withValidContactId_returnTotalRowEffectedIs1() {
        int result = contactService.updateWifiKey("abc@2013", 13);
        assertEquals(1, result);
    }

    @Test(expected = InvalidParamException.class)
    public void whenUpdateWifikey_withInvalidContactId_returnInvalidParamException() {
        contactService.updateWifiKey("abc@2013", 100);
    }

    /*--------- delete() --------*/
    @Test
    public void whenDelete_withContactIdIsValid() {
        Contact contact = createContactDefault();
        contactService.delete(contact.getContactId());
    }

    @Test(expected = EmptyResultDataAccessException.class)
    public void whenDelete_withContactIdIsInvalid_thenThrowEmptyResultDataAccessException(){
        Contact contact = createContactDefault();
        contact.setContactId(0);
        contactService.delete(contact.getContactId());
    }

    /*--------- unSetCustomer() --------*/
    @Test
    public void whenUnSetCustomer_withValidContactId_thenReturnTotalRowEffectedIs1 () {
        assertNotEquals(0, contactService.unSetCustomer(contact.getContactId()));
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenUnSetCustomer_withInValidContactId_thenThrowPCMEntityNotFoundException () {
        contact.setContactId(0);
        contactService.unSetCustomer(contact.getContactId());
    }

    /*--------- updateCustomerId() --------*/
    @Test
    public void whenUpdateCustomerId_withValidParam_thenReturnTotalRowEffectedIs1() {
        Customer customer = new Customer();
        customer.setCustomerId(11);
        contact.setCustomer(customer);
        assertEquals(1, contactService.updateCustomerId(contact.getContactId(), contact.getCustomer().getCustomerId(), contact.getContactIsRepresentative()));
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenUpdateCustomerId_withInvalidContactId_thenThrowPCMEntityNotFoundException() {
        Customer customer = new Customer();
        customer.setCustomerId(11);
        contact.setCustomer(customer);
        contact.setContactId(0);
        contactService.updateCustomerId(contact.getContactId(), contact.getCustomer().getCustomerId(), contact.getContactIsRepresentative());
    }

    /*--------- findByContactIdIn()--------*/
    @Test
    public void whenFindByContactIdIn_withValidContactIdList_thenReturnListContact(){
        List<Integer> contactId = new ArrayList<>();
        contactId.add(new Integer(1));
        contactId.add(new Integer(2));
        when(contactRepositoryMock.findByContactIdIn(contactId)).thenReturn(contacts);

        assertEquals(contacts.size(), contactServiceMock.findByContactIdIn(contactId).size());
    }
}
