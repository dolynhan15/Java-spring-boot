package com.axonactive.pcm.service;

import com.axonactive.pcm.PcmApplication;
import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.entity.Position;
import com.axonactive.pcm.enums.Gender;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.transaction.Transactional;

import static junit.framework.TestCase.assertNotNull;



@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = PcmApplication.class)
@TestPropertySource("classpath:application-test.properties")
@Transactional
public class ContactPositionServiceImplTest {
    @Autowired
    public ContactPositionService contactPositionService;
    @Autowired
    public static Contact contact = new Contact();
    public Contact data() {
        contact.setContactId(10);
        contact.setContactFirstName("Hoang");
        contact.setContactLastName("Ta");
        Position p = new Position();
        p.setPositionTitle("ABC");
        contact.setContactPosition(p);
        contact.setContactGender(Gender.MALE);
        contact.setContactEmail("hoangta@gmail.com");
        return contact;
    }
    @Test
    public void WhenSavePositionWithContact_withContact_returnContactWithNewPosition() {
        data();
        assertNotNull(contactPositionService.savePositionWithContact(contact));
    }
}
