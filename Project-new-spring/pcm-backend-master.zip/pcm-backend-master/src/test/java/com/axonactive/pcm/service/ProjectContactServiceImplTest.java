package com.axonactive.pcm.service;

import com.axonactive.pcm.PcmApplication;
import com.axonactive.pcm.entity.*;
import com.axonactive.pcm.enums.Gender;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.repository.ContactRepository;
import com.axonactive.pcm.service.impl.ContactServiceImpl;
import com.axonactive.pcm.service.impl.ProjectContactServiceImpl;
import com.axonactive.pcm.service.impl.ProjectServiceImpl;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.transaction.Transactional;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = PcmApplication.class)
@TestPropertySource("classpath:application-test.properties")
@Transactional
public class ProjectContactServiceImplTest {
    @Autowired
    public ProjectService projectService;

    @Autowired
    public PositionService positionService;

    @Autowired
    public ContactService contactService;

    @Autowired
    public ContactRepository contactRepository;

    @Autowired
    public ProjectContactService projectContactService;

    @Autowired
    public CustomerService customerService;

    @InjectMocks
    private ProjectContactServiceImpl projectContactServiceMock;

    @Mock
    private ProjectServiceImpl projectServiceMock;

    @Mock
    private ContactServiceImpl contactServiceMock;



    private Contact createContactDefault(){
        Contact contactDefault = new Contact();
        contactDefault.setContactId(30);
        contactDefault.setContactFirstName("Default");
        contactDefault.setContactLastName("Detault");
        Position p = positionService.readPositionByPositionTitle("CEO");
        contactDefault.setContactPosition(p);
        contactDefault.setContactGender(Gender.MALE);
        contactDefault.setContactEmail("default@gmail.com");
        contactDefault.setContactNotes("");
        contactDefault.setContactIsDefault(true);
        contactDefault.setCustomer(customerService.readCustomerById(19));
        return contactDefault;
    }

    private List<Project> createProjectList(){
        List<Project> projectList = new ArrayList<>();
        projectList.add(projectService.findByProjectId(13));
        projectList.add(projectService.findByProjectId(14));
        return projectList;
    }

    /*-------- deleteContactDefaultInProject() ---------*/
    @Test
    public void whenDeleteContactDefaultInProject_withProjectHaveDefaultContact_thenReturnProjectWithNoDefaultContact() {
        //setup old project
        Project project = projectContactService.readProjectById(11);
        Contact defaultContact = createContactDefault();
        defaultContact = contactService.saveContact(defaultContact);
        project.setContact(defaultContact);

        Project newProject = new Project();
        newProject.setProjectId(11);
        newProject.setContact(contactRepository.findOne(17));

        newProject = projectContactService.deleteContactDefaultInProject(newProject);

        assertNull(contactRepository.findOne(defaultContact.getContactId()));
        assertEquals(17, newProject.getContact().getContactId());
    }

    @Test
    public void whenDeleteContactDefaultInProject_withProjectContactNotChange_thenReturnTheSameProjectContact() {
        Project project = projectContactService.readProjectById(11);

        Project newProject = projectContactService.deleteContactDefaultInProject(project);

        assertEquals(project.getContact().getContactId(), newProject.getContact().getContactId());
    }

    /*-------- createContactDefault() ---------*/
    @Test
    public void whenCreateContactDefault_withContactIdIs0_thenReturnContactDefault() {
        Project project = new Project();
        Contact defaultContact = createContactDefault();
        defaultContact.setContactId(0);
        project.setContact(defaultContact);

        Contact newContact = projectContactService.createContactDefault(project);

        assertTrue(newContact.isContactIsDefault());
    }

    @Test
    public void whenCreateContactDefault_withContactIdNotEquals0_thenReturnTheSameContact() {
        Project project = projectContactService.readProjectById(11);

        Contact newContact = projectContactService.createContactDefault(project);

        assertEquals(project.getContact().getContactId(), newContact.getContactId());
    }

    /*--------readProjects()----------*/
    @Test
    public void whenReadProjects_withDefaultParam_thenReturnListProject() {
        List<Project> projectList = createProjectList();

        List<Integer> listContactId = new ArrayList<>();
        listContactId.add(new Integer(13));
        listContactId.add(new Integer(14));

        List<Contact> contactList = new ArrayList<>();
        contactList.add(contactService.readContactById(13));
        contactList.add(contactService.readContactById(14));

        //Test for first element in @projectList
        projectList.get(0).setListPOs("[13,14]");
        projectList.get(0).setListContactId(listContactId);
        when(projectServiceMock.findAllByOrderByProjectIdDesc()).thenReturn(projectList);
        when(contactServiceMock.findByContactIdIn(projectList.get(0).getListContactId())).thenReturn(contactList);
        List<Project> resultList = projectContactServiceMock.readProjects();

        assertEquals(projectList.get(0).getListContactId().size(), resultList.get(0).getListContactPOs().size());

        Assert.assertNotNull(resultList);
    }

    /*--------readProjectById(projectId)----------*/
    @Test
    public void whenGetProjectDetail_withProjectIdIsValidAndListContactIdIsEmpty_thenReturnProjectObject(){
        int projectId = 11;
        Project result = projectContactService.readProjectById(projectId);
        Assert.assertNotNull(result);
    }

    @Test
    public void whenGetProjectDetail_withProjectIdIsValidAndListContactIdIsNotEmpty_thenReturnProjectObject(){
        int projectId = 11;
        Project project = projectService.findByProjectId(projectId);
        List<Integer> listContactId = new ArrayList<>();
        listContactId.add(new Integer(13));
        listContactId.add(new Integer(14));
        project.setListPOs("[13,14]");
        project.setListContactId(listContactId);

        Project result = projectContactService.readProjectById(projectId);
        Assert.assertNotNull(result);
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenGetProjectDetail_withProjectIdOutOfRange_thenThrowCustomerNotFoundException() {
        projectContactService.readProjectById(10000);
    }

    @Test(expected = InvalidParamException.class)
    public void whenGetProjectDetail_withProjectIdIsInvalid_thenInvalidParamException() {
        projectContactService.readProjectById(-2);
    }

    /*--------- deleteContact() --------*/
    @Test(expected = InvalidParamException.class)
    public void  whenDeleteContact_withInValidContactId_thenThrowInvalidParamException() {
        int contactId = 10000;
        projectContactService.deleteContactById(contactId);
    }

    @Test(expected = InvalidParamException.class)
    public void  whenDeleteContact_withValidContactIdAndContactBelongProjects_thenThrowInvalidParamException() {
        int contactId = 16;
        projectContactService.deleteContactById(contactId);
    }

    @Test
    public void  whenDeleteContact_withValidContactIdAndContactHasVisitHistories_thenDeleteContactSuccessfully() {
        int contactId = 23;
        projectContactService.deleteContactById(contactId);
    }

    @Test
    public void  whenDeleteContact_withValidContactId_thenDeleteContactSuccessfully() {
        int contactId = 24;
        projectContactService.deleteContactById(contactId);
    }

}
