package com.axonactive.pcm.service;

import com.axonactive.pcm.PcmApplication;
import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.entity.Customer;
import com.axonactive.pcm.entity.Project;
import com.axonactive.pcm.entity.Team;
import com.axonactive.pcm.enums.Status;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.repository.ProjectRepository;
import com.axonactive.pcm.repository.TeamRepository;
import com.axonactive.pcm.service.impl.ProjectServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.transaction.Transactional;
import java.util.Date;
import java.util.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = PcmApplication.class)
@TestPropertySource("classpath:application-test.properties")
@Transactional
public class ProjectServiceImplTest {
    @Autowired
    public ProjectService projectService;

    @Autowired
    public ProjectContactService projectContactService;

    @Autowired
    public ProjectTeamService projectTeamService;

    @Autowired
    public ContactService contactService;

    @Autowired
    public TeamService teamService;

    @Autowired
    public CustomerService customerService;

    @Autowired
    public TeamRepository teamRepository;

    @InjectMocks
    private ProjectServiceImpl projectServiceMock;

    @Mock
    private ProjectRepository projectRepositoryMock;

    public Project project;
    private static String tooLongString = "saaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaassssssssssssssssssssssssssssssssssssssssssssssssss";
    private static String tooLongText = "saaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaassssssssssssssssssssssssssssssssssssssssssssssssss";

    @Before
    public void data(){
        project = new Project();
        project.setProjectName("PCM");
        Contact contact = new Contact();
        contact = contactService.readContactById(11);
        project.setContact(contact);
        List<Team> teams = new ArrayList<>();
        Team team1 = new Team();
        team1 = teamService.readTeamById(431);
        Team team2 = new Team();
        team2 = teamService.readTeamById(432);
        teams.add(team1);
        teams.add(team2);
        project.setTeams(teams);
        project.setProjectDescription("This is project about Product Customer Management");
        project.setProjectNotes("");
        project.setProjectStatus(Status.ACTIVE);
        try {
            SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
            project.setProjectStartDate(df.parse("03/16/2018"));
            project.setProjectEndDate(df.parse("03/16/2019"));
        }catch (ParseException p) {
        }
    }

    private List<Project> createProjectList(){
        List<Project> projectList = new ArrayList<>();
        projectList.add(projectService.findByProjectId(12));
        projectList.add(projectService.findByProjectId(13));
        return projectList;
    }

    /*--------- Validate() -----------*/
    @Test(expected = InvalidParamException.class)
    public void whenValidate_withEmptyProjectName_thenThrowInvalidParamException () {
        project.setProjectName("");
        projectService.validate(project);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withCustomerIsNull_thenThrowInvalidParamException () {
        project.setProjectName(null);
        projectService.validate(project);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withProjectNameTooLong_thenThrowInvalidParamException () {
        project.setProjectName(tooLongString);
        projectService.validate(project);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withProjectNameIsNull_thenThrowInvalidParamException () {
        project.getContact().setCustomer(null);
        projectService.validate(project);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withProjectDescriptionTooLong_thenThrowInvalidParamException () {
        project.setProjectDescription(tooLongText);
        projectService.validate(project);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withProjectNotesTooLong_thenThrowInvalidParamException () {
        project.setProjectNotes(tooLongText);
        projectService.validate(project);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withStatusInactiveAndProjectEnddateIsNull_thenThrowInvalidParamException () {
        project.setProjectStatus(Status.INACTIVE);
        project.setProjectEndDate(null);
        projectService.validate(project);
    }

    @Test(expected = InvalidParamException.class)
    public void whenValidate_withEnddateBeforeStartdate_thenThrowInvalidParamException () {
        project.setProjectStartDate(new Date(100000));
        project.setProjectEndDate(new Date(10000));
        projectService.validate(project);
    }

    /*--------- SaveProject() -----------*/
    @Test
    public void whenSaveProject_withValidParam_ReturnNewProject(){
        Customer customer = new Customer();
        customer = customerService.readCustomerById(11);
        project.getContact().setCustomer(customer);
        assertNotNull(projectService.saveProject(project));
    }

    @Test
    public void whenSaveProject_withInvalidContact_ReturnNewProject(){
        Customer customer = new Customer();
        customer = customerService.readCustomerById(11);
        project.getContact().setCustomer(customer);
        assertNotNull(project);
    }

    @Test(expected = InvalidParamException.class)
    public void whenSaveProject_withInvalidProjectName_ReturnInvalidParamException(){
        project.setProjectName("");
        projectService.saveProject(project);
    }

    @Test(expected = InvalidParamException.class)
    public void whenSaveProject_withInvalidCustomer_ReturnInvalidParamException(){
        Contact contact1 = new Contact();
        project.setContact(contact1);
        projectService.saveProject(project);
    }

    @Test(expected = InvalidParamException.class)
    public void whenSaveProject_withProjectNameIsTooLong_ReturnInvalidParamException(){
        project.setProjectName(tooLongString);
        projectService.saveProject(project);
    }
    @Test(expected = InvalidParamException.class)
    public void whenSaveProject_withStartDateNotBeforeEndDate_ReturnInvalidParamException(){
        try {
            SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
            project.setProjectEndDate(df.parse("03/16/2017"));
        }catch (ParseException p) {
        }
        projectService.saveProject(project);
    }

    /*--------readProjectById(projectId)----------*/
    @Test
    public void whenGetProjectDetail_withProjectIdIsValid_thenReturnProjectObject(){
        int projectId = 11;
        Project result = projectContactService.readProjectById(projectId);
        assertNotNull(result);
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenGetProjectDetail_withProjectIdOutOfRange_thenThrowCustomerNotFoundException() {
        projectContactService.readProjectById(10000);
    }

    @Test(expected = InvalidParamException.class)
    public void whenGetProjectDetail_withProjectIdIsInvalid_thenInvalidParamException() {
        projectContactService.readProjectById(-2);
    }

    /*--------UpdateNetworkInfrastructureId()----------*/
    @Test
    public void whenUpdateNetworkInfrastructureId_withValidParams_thenReturnTotalRowEffectedIs1() {
        int result = projectService.updateNetworkInfrastructureId(10, 11);
        assertEquals(1, result);
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenUpdateNetworkInfrastructureId_withInvalidProjectId_thenThrowPCMEntityNotFoundException() {
        projectService.updateNetworkInfrastructureId(10, 1000);
    }

    /*--------updateContactId()----------*/
    @Test
    public void whenUpdateContactId_withValidProjectId_thenReturnTotalRowsEffectsIs1() {
        assertEquals(1, projectService.updateContactId(19, 15));
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenUpdateContactId_withInvalidProjectId_thenThrowPCMEntityNotFoundException() {
        projectService.updateContactId(9, 100);
    }

    /*--------readProjectsByContactId()----------*/
    @Test
    public void whenReadProjectByContactId_withValidContactId_thenReturnListProjects() {
        List<Project> projects = projectService.readProjectsByContactId(13);
        assertNotEquals(0, projects.size());
    }

    /*--------findAllByOrderByProjectIdDesc()----------*/
    @Test
    public void whenFindAllByOrderByProjectIdDesc_withDataExist_thenReturnProjectList(){
        List<Project> projectList = createProjectList();
        when(projectRepositoryMock.findAllByOrderByProjectIdDesc()).thenReturn(projectList);

        assertEquals(projectList.size(), projectServiceMock.findAllByOrderByProjectIdDesc().size());
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenFindAllByOrderByProjectIdDesc_withDataNotExist_thenThrowPCMEntityNotFoundException(){
        when(projectRepositoryMock.findAllByOrderByProjectIdDesc()).thenReturn(new ArrayList<>());
        projectServiceMock.findAllByOrderByProjectIdDesc();
    }

    /*--------findByTeamNameAndNotHasTeam()----------*/
    @Test
    public void whenFindByTeamNameAndNotHasTeam_withDataExist_thenReturnProjectList(){
        List<Project> projectList = createProjectList();
        when(projectRepositoryMock.findByTeamNameAndNotHasTeam("Flamingo")).thenReturn(projectList);

        assertEquals(projectList.size(), projectServiceMock.findByTeamNameAndNotHasTeam("Flamingo").size());
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenfindByTeamNameAndNotHasTeam_withDataNotExist_thenThrowPCMEntityNotFoundException(){
        when(projectRepositoryMock.findByTeamNameAndNotHasTeam("Flamingo")).thenReturn(new ArrayList<>());
        projectServiceMock.findByTeamNameAndNotHasTeam("Flamingo");
    }

    /*--------findAllByTeamName()----------*/
    @Test
    public void whenFindAllByTeamName_withDataExist_thenReturnProjectList(){
        List<Project> projectList = createProjectList();
        when(projectRepositoryMock.findAllByTeamName("Flamingo")).thenReturn(projectList);

        assertEquals(projectList.size(), projectServiceMock.findAllByTeamName("Flamingo").size());
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenFindAllByTeamName_withDataNotExist_thenReturnProjectList(){
        when(projectRepositoryMock.findAllByTeamName("Flamingo")).thenReturn(new ArrayList<>());
        projectServiceMock.findAllByTeamName("Flamingo");
    }
}
