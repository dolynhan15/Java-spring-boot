package com.axonactive.pcm.service;

import com.axonactive.pcm.PcmApplication;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.repository.TechnologyRepository;
import com.axonactive.pcm.service.impl.TechnologyServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.transaction.Transactional;

import java.util.ArrayList;

import static junit.framework.TestCase.assertNotNull;
import static org.mockito.Mockito.*;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = PcmApplication.class)
@TestPropertySource("classpath:application-test.properties")
@Transactional
public class TechnologyServiceImplTest {
    @Autowired
    public TechnologyService technologyService;

    @InjectMocks
    private TechnologyServiceImpl technologyServiceMock;

    @Mock
    private TechnologyRepository technologyRepositoryMock;

    @Test
    public void whenGetTechnologies_withDataExist_ReturnListTechnology(){
        assertNotNull(technologyService.getTechnologies());
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenGetTechnologies_withDataNotExist_thenThrowPCMEntityNotFoundException(){
        when(technologyRepositoryMock.findAll()).thenReturn(new ArrayList<>());
        technologyServiceMock.getTechnologies();
    }
}
