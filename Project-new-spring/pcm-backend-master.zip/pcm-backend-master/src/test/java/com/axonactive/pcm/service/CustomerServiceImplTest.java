package com.axonactive.pcm.service;

import com.axonactive.pcm.PcmApplication;
import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.entity.Customer;
import com.axonactive.pcm.enums.Status;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.repository.CustomerRepository;
import com.axonactive.pcm.service.impl.CustomerServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.persistence.EntityNotFoundException;
import javax.transaction.Transactional;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = PcmApplication.class)
@TestPropertySource("classpath:application-test.properties")
@Transactional
public class CustomerServiceImplTest {
    @Autowired
    private CustomerService customerService;
    @Autowired
    private ContactService contactService;

    @InjectMocks
    private CustomerServiceImpl customerServiceMock;

    @Mock
    private CustomerRepository customerRepositoryMock;

    private static Customer customer;
    private static List<Contact> contacts = new ArrayList<>();
    private static String tooLongString = "saaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaassssssssssssssssssssssssssssssssssssssssssssssssss";
    private static String tooLongText = "saaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasssssssssssssssssssssssssssssssssssssssssssssssssssaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaassssssssssssssssssssssssssssssssssssssssssssssssss";


    public static Customer data() {
        customer = new Customer();
        customer.setCustomerName("Hoang Long");
        customer.setCustomerWebsite("www.hoanglong.org");
        customer.setCustomerAddress("193 Nguyen Luong Bang");
        customer.setStatus(Status.ACTIVE);
        try {
            String startDateString = "06/27/2007";
            SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
            customer.setCustomerStartDate(df.parse(startDateString));
        } catch (ParseException p) {
        }
        customer.setContacts(null);
        customer.setCustomerLogo("");
        customer.setCustomerNotes("This is Company Hoang Long");
        return customer;
    }

    public List<Contact> getContacts() {
        Contact contact = new Contact();
        contact = contactService.readContactById(14);
        contacts.add(contact);
        return contacts;
    }

    /*--------- readCustomerById(SaveCustomer)--------*/
    @Test
    public void whenReadCustomerById_withCustomerIdIsValid_thenReturnGetDetailCustomerSuccess() {
        int customerId = 11;
        Customer result = customerService.readCustomerById(customerId);
        assertNotNull(result);
    }

    @Test(expected = EntityNotFoundException.class)
    public void whenReadCustomerById_withCustomerIdOutOfRange_thenThrowCustomerNotFoundException() {
        customerService.readCustomerById(10000);
    }

    @Test(expected = InvalidParamException.class)
    public void whenReadCustomerById_withCustomerIdNegative_thenThrowInvalidParamException() {
        customerService.readCustomerById(-1);
    }

    /*--------- readCustomers(SaveCustomer)--------*/
    @Test
    public void whenReadCustomers_withDataExist_thenReturnGetListCustomerSuccess() {
        List<Customer> result = customerService.readCustomers();
        assertNotNull(result);
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenReadCustomers_withDataNotExist_thenThrowPCMEntityNotFoundException() {
        when(customerRepositoryMock.findAllByOrderByCustomerIdDesc()).thenReturn(new ArrayList<>());
        customerServiceMock.readCustomers();
    }

    /*--------- SaveCustomer--------*/
    @Test
    public void whenSaveCustomer_withValidCustomer_thenReturnSameCustomer() {
        data();
        getContacts();
        customer.setContacts(contacts);
        assertNotNull(customerService.saveCustomer(customer));
    }

    @Test
    public void whenSaveCustomer_withContactsNull_thenReturnSameCustomer() {
        customer = data();
        customer.setCustomerId(2);
        assertNotNull(customerService.saveCustomer(customer));
    }

    @Test(expected = InvalidParamException.class)
    public void whenSaveCustomer_withInValidCustomerName_thenReturnInvalidParamException() {
        customer = data();
        customer.setCustomerName("");
        customerService.saveCustomer(customer);
    }

    @Test(expected = InvalidParamException.class)
    public void whenSaveCustomer_withTooLongCustomerName_thenReturnInvalidParamException() {
        customer = data();
        customer.setCustomerName(tooLongString);
        customerService.saveCustomer(customer);
    }

    @Test(expected = InvalidParamException.class)
    public void whenSaveCustomer_withTooLongCustomerWebsite_thenReturnInvalidParamException() {
        customer = data();
        customer.setCustomerWebsite(tooLongString);
        customerService.saveCustomer(customer);
    }

    @Test(expected = InvalidParamException.class)
    public void whenSaveCustomer_withTooLongCustomerAddress_thenReturnInvalidParamException() {
        customer = data();
        customer.setCustomerAddress(tooLongText);
        customerService.saveCustomer(customer);
    }

    @Test(expected = InvalidParamException.class)
    public void whenSaveCustomer_withTooLongNotes_thenReturnInvalidParamException() {
        customer = data();
        customer.setCustomerNotes(tooLongText);
        customerService.saveCustomer(customer);
    }


    @Test(expected = InvalidParamException.class)
    public void whenSaveCustomer_withInValidCustomerStartDate_thenReturnInvalidParamException() {
        customer = data();
        customer.setCustomerStartDate(null);
        customerService.saveCustomer(customer);
    }

    @Test(expected = InvalidParamException.class)
    public void whenSaveCustomer_withStatusIsINACTIVEandEndateIsNull_thenReturnInvalidParamException() {
        customer = data();
        customer.setStatus(Status.INACTIVE);
        customer.setCustomerEndDate(null);
        customerService.saveCustomer(customer);
    }

    @Test(expected = InvalidParamException.class)
    public void whenSaveCustomer_withStatusIsINACTIVEandStartDateNotBeforeEnddate_thenReturnInvalidParamException() {
        customer = data();
        customer.setStatus(Status.INACTIVE);
        try {
            String startDateString = "06/26/2007";
            SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
            customer.setCustomerEndDate(df.parse(startDateString));
        } catch (ParseException p) {
        }
        customerService.saveCustomer(customer);
    }

    /*--------- readCustomersAllContact()--------*/
    @Test
    public void whenReadCustomersAllContact_withHaveDataInTheDatabase_thenReturnCustomerList() {
        assertNotNull(customerService.readCustomersAllContact());
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenReadCustomersAllContact_withDataNotExist_thenThrowPCMEntityNotFoundException() {
        when(customerRepositoryMock.findAll()).thenReturn(new ArrayList<>());
        customerServiceMock.readCustomersAllContact();
    }
}
