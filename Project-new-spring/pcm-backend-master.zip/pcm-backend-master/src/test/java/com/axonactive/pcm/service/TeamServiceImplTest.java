package com.axonactive.pcm.service;

import com.axonactive.pcm.PcmApplication;
import com.axonactive.pcm.entity.Team;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.repository.TeamRepository;
import com.axonactive.pcm.service.impl.TeamServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = PcmApplication.class)
@TestPropertySource("classpath:application-test.properties")
@Transactional
public class TeamServiceImplTest {
    @Autowired
    public TeamService teamService;

    @Autowired
    public TeamRepository teamRepository;

    @InjectMocks
    public TeamServiceImpl teamServiceImplMock;

    @Mock
    public TeamRepository teamRepositoryMock;

    private List<Team> teams;
    private Team team;

    public void createTeam(){
        team = new Team();
        team.setTeamName("Team Test");
    }

    @Before
    public void createListTeam(){
        teams = new ArrayList<>();
        teams.add(teamRepository.findByTeamId(431));
        teams.add(teamRepository.findByTeamId(432));
        teams.add(teamRepository.findByTeamId(433));
        teams.add(teamRepository.findByTeamId(434));
    }

    /*---------readTeamByContactId()----------*/
    @Test
    public void whenReadTeamsByContactId_withValidContactId_thenReturnListTeam(){
        when(teamRepositoryMock.getTeamsByContactId(1)).thenReturn(teams);
        assertEquals(teams.size(), teamServiceImplMock.readTeamsByContactId(1).size());
    }

    @Test(expected = InvalidParamException.class)
    public void whenReadTeamsByContactId_withNegativeContactId_thenThrowInvalidParamException(){
        teamServiceImplMock.readTeamsByContactId(-1);
    }

    /*---------readTeamsByProjectId()----------*/
    @Test
    public void whenReadTeamsByProjectId_withValidProjectId_thenReturnListTeam(){
        when(teamRepositoryMock.getTeamsByProjectId(1)).thenReturn(teams);
        assertEquals(teams.size(), teamServiceImplMock.readTeamsByProjectId(1).size());
    }

    @Test(expected = InvalidParamException.class)
    public void whenReadTeamsByProjectId_withNegativeProjectId_thenThrowInvalidParamException(){
        teamServiceImplMock.readTeamsByProjectId(-1);
    }

    /*---------readTeamByCustomerId()----------*/
    @Test
    public void whenReadTeamByCustomerId_withCustomerIdValid_returnListTeam() {
        assertNotNull(teamService.readTeamByCustomerId(10));
    }

    @Test(expected = InvalidParamException.class)
    public void whenReadTeamByCustomerId_withCustomerIdinvalid_thenThrowInvalidParamException() {
        teamService.readTeamByCustomerId(-1);
    }

    /*---------readTeamById()----------*/
    @Test
    public void whenReadTeamById_withTeamIdValid_thenReturnListTeam() {
        assertNotNull(teamService.readTeamById(432));
    }

    @Test(expected = InvalidParamException.class)
    public void whenreadActiveTeamById_withTeamIdNegative_thenThrowInvalidParamException() {
        teamService.readTeamById(-1);
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenreadActiveTeamById_withTeamIdNotExist_thenThrowPCMEntityNotFoundException() {
        teamService.readTeamById(200);
    }

    /*---------readActiveTeamListDTOs()----------*/
    @Test
    public void whenReadActiveTeamListDTO_withDataExist_thenReturnListTeam() {
        assertNotNull(teamService.readActiveTeamListDTOs());
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenReadActiveTeamListDTO_withDataNotExist_thenThrowPCMEntityNotFoundException() {
        when(teamRepositoryMock.findAll()).thenReturn(new ArrayList<>());
        teamServiceImplMock.readActiveTeamListDTOs();
    }

    /*---------readTeams()----------*/
    @Test
    public void whenReadTeams_withDataExist_thenReturnListTeam() {
        assertNotNull(teamService.readTeams());
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenReadTeams_withDataNotExist_thenThrowPCMEntityNotFoundException() {
        when(teamRepositoryMock.findAll()).thenReturn(new ArrayList<>());
        teamServiceImplMock.readTeams();
    }

    /*---------saveAllTeam()----------*/
    @Test
    public void whenSaveAllTeam_withValidTeamList_thenReturnListTeam() {
        assertNotNull(teamService.saveAllTeam(teams));
    }

    /*---------saveTeam()----------*/
    @Test
    public void whenSaveTeam_withvalidTeam_thenReturnListTeam() {
        createTeam();
        assertNotNull(teamService.saveTeam(team));
    }

    /*---------updateTeam()----------*/
    @Test
    public void whenUpdateTeam_withvalidParams_thenReturnTotalRowEffectNotEquals0() {
        assertNotEquals(0, teamService.updateTeam("Branch name", "department name", "team email", 4, "team leader name", "team members", "team name", "team notes", 34));
    }

    /*---------getTeamIdByTeamName()----------*/
    @Test
    public void whenGetTeamIdByTeamName_withTeamNameIsExist_thenReturnTeamId() {
        Team team = teamRepository.findByTeamId(435);
        assertEquals(435, teamService.getTeamIdByTeamName(team.getTeamName()));
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenGetTeamIdByTeamName_withTeamNameIsNotExist_thenThrowPCMEntityNotFoundException() {
        teamService.getTeamIdByTeamName("Test Team Flamingo");
    }

    /*---------deleteTeam()----------*/
    @Test
    public void whenDeteleTeam_withExistTeamId_thenReturnTrue() {
        createTeam();
        team = teamRepository.save(team);
        assertTrue(teamService.deleteTeam(team.getTeamId()));
    }

    /*---------updateStatusTeam()----------*/
//    @Test
//    public void whenUpdateStatusTeam_withValidParams_thenReturnTotalRowEffectsNotEquals0(){
//        assertNotEquals(0, teamService.updateStatusTeam(Status.ACTIVE.ordinal(), 6));
//    }
//
//    @Test
//    public void whenUpdateStatusTeam_withTeamHrIdNotExist_thenReturnTotalRowEffectsEquals0(){
//        assertEquals(0, teamService.updateStatusTeam(Status.ACTIVE.ordinal(), 50));
//    }
}
