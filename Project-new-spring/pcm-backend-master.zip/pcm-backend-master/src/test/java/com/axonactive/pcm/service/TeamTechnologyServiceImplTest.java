package com.axonactive.pcm.service;

import com.axonactive.pcm.PcmApplication;
import com.axonactive.pcm.entity.Team;
import com.axonactive.pcm.entity.Technology;
import com.axonactive.pcm.enums.Status;
import com.axonactive.pcm.repository.TeamRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

import static junit.framework.TestCase.assertNotNull;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = PcmApplication.class)
@TestPropertySource("classpath:application-test.properties")
@Transactional
public class TeamTechnologyServiceImplTest {
    @Autowired
    public TeamTechnologyService teamTechnologyService;

    @Autowired
    public TeamRepository teamRepository;

    private Team team;
    private List<Technology> technologies;

    @Before
    public void createTeamWithTechnologies(){
        team = new Team();
        team.setTeamName("Test Team");
        technologies = new ArrayList<>();

        Technology technology = new Technology();
        technology.setId(30);
        technology.setName("JAVA");
        Technology technology1 = new Technology();
        technology1.setId(31);
        technology1.setName("ANGULAR");
        Technology technology2 = new Technology();
        technology2.setName("TEST TECNOLOGY");

        technologies.add(technology);
        technologies.add(technology1);
        technologies.add(technology2);
        team.setTechnologies(technologies);
    }

    @Test
    public void whenSaveProjectWithNewTechnology_withValidTeam_thenReturnNotNull(){
        team = teamTechnologyService.saveTeamWithNewTechnology(team);
        assertNotNull(team);
    }
}
