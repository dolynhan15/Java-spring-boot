package com.axonactive.pcm.service;

import com.axonactive.pcm.PcmApplication;
import com.axonactive.pcm.entity.Team;
import com.axonactive.pcm.repository.TeamRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.transaction.Transactional;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = PcmApplication.class)
@TestPropertySource("classpath:application-test.properties")
@Transactional
public class TeamDataTransferServiceImplTest {
    @Autowired
    public TeamDataTransferService teamDataTransferService;

    @Autowired
    public TeamRepository teamRepository;

    @Autowired
    public TeamHRService teamHRService;

    /*-------teamHRToTeam()--------*/
    @Test
    public void whenTeamHRToTeam_withHaveTeamInDB_thenReturnTeams() {
        List<Team> teams = teamDataTransferService.teamHRToTeam();

        assertNotEquals(0, teams.size());
    }

    /*-------saveAllTeam()--------*/
    @Test
    public void whenSaveAllTeam_withTeamsFromHr_thenReturnTeamListNotNull(){
        assertNotNull(teamDataTransferService.saveAllTeam());
    }
}
