package com.axonactive.pcm.service;

import com.axonactive.pcm.PcmApplication;
import com.axonactive.pcm.entity.Contact;
import com.axonactive.pcm.entity.Project;
import com.axonactive.pcm.entity.Team;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.repository.TeamRepository;
import com.axonactive.pcm.service.impl.*;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.transaction.Transactional;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = PcmApplication.class)
@TestPropertySource("classpath:application-test.properties")
@Transactional
public class ProjectTeamServiceImplTest {
    @Autowired
    private ProjectTeamService projectTeamService;

    @Autowired
    private TeamRepository teamRepository;

    @Autowired
    private ProjectService projectService;

    @Autowired
    public ContactService contactService;

    @InjectMocks
    private ProjectTeamServiceImpl projectTeamServiceMock;

    @Mock
    private ProjectServiceImpl projectServiceMock;

    @Mock
    private ContactServiceImpl contactServiceMock;

    @Mock
    private TeamServiceImpl teamServiceMock;

    private List<Project> createProjectList(){
        List<Project> projectList = new ArrayList<>();
        projectList.add(projectService.findByProjectId(13));
        projectList.add(projectService.findByProjectId(14));
        return projectList;
    }

    /*--------readProjectsByTeamName()----------*/
    @Test
    public void whenReadProjectsByTeamName_withExistTeamNameAndExistProjects_thenReturnProjectList() {
        List<Project> projectList = createProjectList();

        List<Integer> listContactId = new ArrayList<>();
        listContactId.add(new Integer(13));
        listContactId.add(new Integer(14));

        List<Contact> contactList = new ArrayList<>();
        contactList.add(contactService.readContactById(13));
        contactList.add(contactService.readContactById(14));

        //Test for first element in @projectList
        projectList.get(0).setListPOs("[13,14]");
        projectList.get(0).setListContactId(listContactId);
        when(teamServiceMock.getTeamIdByTeamName("Flamingo")).thenReturn(431);
        when(projectServiceMock.findAllByTeamName("Flamingo")).thenReturn(projectList);
        when(contactServiceMock.findByContactIdIn(projectList.get(0).getListContactId())).thenReturn(contactList);
        List<Project> resultList = projectTeamServiceMock.readProjectsByTeamName("Flamingo");

        assertEquals(projectList.get(0).getListContactId().size(), resultList.get(0).getListContactPOs().size());

        Assert.assertNotNull(resultList);
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenReadProjectsByTeamName_withNotExistTeamName_thenReturnProjectList() {
        projectTeamService.readProjectsByTeamName("team name 1231");
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenReadProjectsByTeamName_withExistTeamNameAndNotExistProjects_thenReturnProjectList() {
        //Create new team with no projects
        Team team = new Team();
        team.setTeamName("Team test");
        teamRepository.save(team);

        projectTeamService.readProjectsByTeamName("Team test");
    }

    /*--------readProjectsByTeamAndNotHasTeam()----------*/
    @Test
    public void whenReadProjectsByTeamAndNotHasTeam_thenReturnListProject(){
        List<Project> projectList = createProjectList();

        List<Integer> listContactId = new ArrayList<>();
        listContactId.add(new Integer(13));
        listContactId.add(new Integer(14));

        List<Contact> contactList = new ArrayList<>();
        contactList.add(contactService.readContactById(13));
        contactList.add(contactService.readContactById(14));

        //Test for first element in @projectList
        projectList.get(0).setListPOs("[13,14]");
        projectList.get(0).setListContactId(listContactId);
        when(teamServiceMock.getTeamIdByTeamName("Flamingo")).thenReturn(431);
        when(projectServiceMock.findByTeamNameAndNotHasTeam("Flamingo")).thenReturn(projectList);
        when(contactServiceMock.findByContactIdIn(projectList.get(0).getListContactId())).thenReturn(contactList);
        List<Project> resultList = projectTeamServiceMock.readProjectsByTeamAndNotHasTeam("Flamingo");

        assertEquals(projectList.get(0).getListContactId().size(), resultList.get(0).getListContactPOs().size());

        Assert.assertNotNull(resultList);
    }
}
