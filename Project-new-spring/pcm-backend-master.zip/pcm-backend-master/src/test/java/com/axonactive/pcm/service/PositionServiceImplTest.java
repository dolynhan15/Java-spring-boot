package com.axonactive.pcm.service;

import com.axonactive.pcm.PcmApplication;
import com.axonactive.pcm.entity.Position;
import com.axonactive.pcm.exception.InvalidParamException;
import com.axonactive.pcm.exception.PCMEntityNotFoundException;
import com.axonactive.pcm.repository.PositionRepository;
import com.axonactive.pcm.service.impl.PositionServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.transaction.Transactional;

import java.util.ArrayList;

import static junit.framework.TestCase.assertNotNull;
import static org.mockito.Mockito.*;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = PcmApplication.class)
@TestPropertySource("classpath:application-test.properties")
@Transactional
public class PositionServiceImplTest {
    @Autowired
    private PositionService positionService;

    @InjectMocks
    private PositionServiceImpl positionServiceMock;

    @Mock
    private PositionRepository positionRepositoryMock;

    /*-----------readPositions()--------------*/
    @Test
    public void whenReadPositions_withDataExist_returnSamePositionList() {
        assertNotNull(positionService.readPositions());
    }

    @Test(expected = PCMEntityNotFoundException.class)
    public void whenReadPositions_withDataNotExist_thenThrowPCMEntityNotFoundException() {
        when(positionRepositoryMock.findAll()).thenReturn(new ArrayList<>());
        positionServiceMock.readPositions();
    }

    /*-----------readPositionByTitle()--------------*/
    @Test
    public void whenReadPositionByTitle_withParamPositionTitle_returnPosition() {
        assertNotNull(positionService.readPositionByPositionTitle("CEO"));
    }

    /*-----------savePosition()--------------*/
    @Test
    public void whenSavePosition_withPosition_returnPosition() {
        Position p = new Position();
        p.setPositionTitle("COO");
        assertNotNull(positionService.savePosition(p));
    }
    @Test(expected = InvalidParamException.class)
    public void whenSavePosition_withPositionTitleIsEmpty_returnInvalidParamException() {
        Position p = new Position();
        p.setPositionTitle("");
        assertNotNull(positionService.savePosition(p));
    }
    @Test(expected = InvalidParamException.class)
    public void whenSavePosition_withPositionTitleTooLong_returnInvalidParamException() {
        Position p = new Position();
        p.setPositionTitle("saaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaassssssssssssssssssssssssssssssssssssssssssssssssss");
        assertNotNull(positionService.savePosition(p));
    }
}
